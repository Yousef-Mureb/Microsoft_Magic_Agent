"""Ingestion from the Azure Retail Prices API: exact case-sensitive filters, pagination through
`NextPageLink`, retries with backoff, and a store whose every row carries its provenance. The API
is played back from recorded items; only the test marked `live` reaches prices.azure.com."""

from __future__ import annotations

from urllib.parse import parse_qs, unquote, urlsplit

import httpx
import pytest

from ms_agent.pricing.ingest import (
    API_VERSION,
    BASE_URL,
    IngestError,
    RetailPricesClient,
    build_filter,
    ingest,
    ingest_scope,
    query_url,
)
from ms_agent.pricing.store import SqlPriceStore
from tests.pricing_data import FETCHED_AT, items_where, loaded_store

D4S_FILTER = "serviceName eq 'Virtual Machines' and armRegionName eq 'uaenorth' and armSkuName eq 'Standard_D4s_v5'"
D4S = items_where(armSkuName="Standard_D4s_v5")


def paged(items: list[dict], size: int, filter_text: str) -> dict[str, dict]:
    """The recorded items as the API pages them: absolute `NextPageLink`s with a `$skip`, null on the last."""
    pages: dict[str, dict] = {}
    chunks = [items[start:start + size] for start in range(0, len(items), size)] or [[]]
    for number, chunk in enumerate(chunks):
        link = None if number == len(chunks) - 1 else \
            f"https://prices.azure.com:443/api/retail/prices?api-version={API_VERSION}" \
            f"&$filter={filter_text.replace(' ', '%20')}&$skip={(number + 1) * size}"
        pages[str(number * size)] = {"BillingCurrency": "USD", "CustomerEntityId": "Default",
                                     "CustomerEntityType": "Retail", "Items": chunk, "NextPageLink": link,
                                     "Count": len(chunk)}
    return pages


def client_for(pages: dict[str, dict], sent: list[httpx.Request], *, failures: list[httpx.Response] | None = None,
               sleeps: list[float] | None = None, **options) -> RetailPricesClient:
    """A client whose API is the given pages, after the given failures."""
    waiting = list(failures or [])

    def answer(request: httpx.Request) -> httpx.Response:
        sent.append(request)
        if waiting:
            return waiting.pop(0)
        skip = parse_qs(urlsplit(str(request.url)).query).get("$skip", ["0"])[0]
        return httpx.Response(200, json=pages[skip])

    sleeps = sleeps if sleeps is not None else []
    return RetailPricesClient(httpx.Client(transport=httpx.MockTransport(answer)), sleep=sleeps.append, **options)


def test_the_filter_is_built_exactly_in_the_apis_case() -> None:
    built = build_filter({"serviceName": "Virtual Machines", "armRegionName": "uaenorth",
                          "armSkuName": "Standard_D4s_v5"})
    assert built == D4S_FILTER
    assert build_filter({"productName": "Bob's Disks"}) == "productName eq 'Bob''s Disks'"
    assert build_filter({"serviceFamily": "Compute", "armRegionName": "uaenorth"}) == \
        "serviceFamily eq 'Compute' and armRegionName eq 'uaenorth'"


def test_the_filter_goes_on_the_wire_unchanged_with_the_api_version() -> None:
    sent: list[httpx.Request] = []
    client_for(paged(D4S, 100, D4S_FILTER), sent).items(D4S_FILTER)
    query = parse_qs(urlsplit(str(sent[0].url)).query)
    assert str(sent[0].url).startswith(BASE_URL + "?")
    assert query["api-version"] == ["2023-01-01-preview"]
    assert query["$filter"] == [D4S_FILTER]
    assert "currencyCode" not in query


def test_pagination_follows_next_page_link_through_three_pages() -> None:
    assert len(D4S) == 7
    pages = paged(D4S, 3, D4S_FILTER)
    assert len(pages) == 3 and pages["6"]["NextPageLink"] is None
    sent: list[httpx.Request] = []
    items = client_for(pages, sent).items(D4S_FILTER)
    assert len(sent) == 3
    assert items == D4S
    assert sent[1].url == httpx.URL(pages["0"]["NextPageLink"])  # httpx drops the default :443
    assert sent[2].url == httpx.URL(pages["3"]["NextPageLink"])


def test_a_next_page_link_seen_twice_stops_the_run() -> None:
    pages = paged(D4S, 3, D4S_FILTER)
    pages["3"]["NextPageLink"] = pages["0"]["NextPageLink"]
    with pytest.raises(IngestError, match="same NextPageLink"):
        client_for(pages, []).items(D4S_FILTER)


def test_throttling_and_server_errors_are_retried_with_backoff() -> None:
    sent: list[httpx.Request] = []
    sleeps: list[float] = []
    failures = [httpx.Response(429, headers={"retry-after": "2"}), httpx.Response(503)]
    items = client_for(paged(D4S, 100, D4S_FILTER), sent, failures=failures, sleeps=sleeps).items(D4S_FILTER)
    assert items == D4S and len(sent) == 3
    assert sleeps == [2.0, 2.0]  # Retry-After first, then 1 s doubled for the second attempt


def test_a_client_error_is_not_retried_and_retries_end() -> None:
    sent: list[httpx.Request] = []
    with pytest.raises(IngestError, match="HTTP 400"):
        client_for({}, sent, failures=[httpx.Response(400)]).items(D4S_FILTER)
    assert len(sent) == 1
    with pytest.raises(IngestError, match="HTTP 503"):
        client_for({}, [], failures=[httpx.Response(503)] * 3, retries=2).items(D4S_FILTER)


def test_another_currency_is_asked_by_currency_code() -> None:
    sent: list[httpx.Request] = []
    client_for(paged(D4S, 100, D4S_FILTER), sent).items(D4S_FILTER, "aed")
    assert parse_qs(urlsplit(str(sent[0].url)).query)["currencyCode"] == ["'AED'"]
    assert "currencyCode=%27AED%27" in query_url(D4S_FILTER, "AED")


def test_every_stored_meter_carries_source_effective_date_and_fetched_at() -> None:
    store = loaded_store()
    meters = store.find()
    assert len(meters) == store.count() > 100
    for meter in meters:
        assert meter.source_url.startswith(BASE_URL + "?api-version=2023-01-01-preview&$filter=")
        assert meter.effective_start_date.endswith("Z") and meter.fetched_at == FETCHED_AT
        assert unquote(meter.source_url).endswith(f"meterId eq '{meter.meter_id}' and armRegionName eq "
                                                  f"'{meter.arm_region_name}' and priceType eq '{meter.type}'")


def test_reservation_and_savings_plan_fields_are_kept() -> None:
    store = loaded_store()
    d4 = {"arm_sku_name": "Standard_D4s_v5", "arm_region_name": "uaenorth"}
    linux = next(meter for meter in store.find(type="Consumption", **d4)
                 if not meter.product_name.endswith("Windows") and "Spot" not in meter.sku_name
                 and "Low Priority" not in meter.sku_name)
    assert linux.savings_plan_for("1 Year").retail_price == 0.1770725
    assert linux.savings_plan_for("3 Years").retail_price == 0.1217535
    terms = {meter.reservation_term: meter.retail_price for meter in store.find(type="Reservation", **d4)}
    assert terms == {"1 Year": 1272.0, "3 Years": 2444.0}


def test_a_scope_is_replaced_whole_and_other_scopes_are_kept() -> None:
    store = SqlPriceStore("sqlite://")
    scope = {"serviceName": "Virtual Machines", "armRegionName": "uaenorth", "armSkuName": "Standard_D4s_v5"}
    other = items_where(armSkuName="Standard_E8s_v5")
    store.replace(other, scope={"arm_sku_name": "Standard_E8s_v5"}, currency="USD", fetched_at=FETCHED_AT,
                  source_url_of=lambda item: "x")
    assert ingest_scope(store, client_for(paged(D4S, 3, D4S_FILTER), []), scope) == 7
    assert ingest_scope(store, client_for(paged(D4S[:2], 3, D4S_FILTER), []), scope) == 2
    assert len(store.find(arm_sku_name="Standard_D4s_v5")) == 2
    assert len(store.find(arm_sku_name="Standard_E8s_v5")) == len(other)
    assert store.find(arm_sku_name="Standard_D4s_v5", currency="AED") == []


def test_a_failed_scope_is_reported_and_keeps_its_prices(tmp_path) -> None:
    store = loaded_store(f"sqlite:///{tmp_path / 'prices.sqlite3'}")
    before = store.count()
    report = ingest(store, client_for({}, [], failures=[httpx.Response(500)] * 10, retries=1),
                    regions=["uaenorth"], families=["Compute"], currencies=["USD"])
    assert not report.ok and "USD/uaenorth/Compute" in report.failed
    assert store.count() == before


@pytest.mark.live
def test_live_ingestion_of_d4s_v5_in_uae_north(capsys) -> None:
    """Brief, verification 2: fetch the real meters and print the four prices."""
    from ms_agent.pricing.lookup import price_for

    store = SqlPriceStore("sqlite://")
    scope = {"serviceName": "Virtual Machines", "armRegionName": "uaenorth", "armSkuName": "Standard_D4s_v5"}
    stored = ingest_scope(store, RetailPricesClient(), scope)
    assert stored > 0
    lines = []
    for os_name, model in (("linux", "payg"), ("windows", "payg"), ("linux", "ri_1y"), ("linux", "sp_1y")):
        price = price_for(store, "Standard_D4s_v5", "uaenorth", os_name, model)
        assert price.source_url and price.effective_start_date and price.fetched_at
        lines.append(f"{os_name:8} {model:6} {price.value} {price.currency} per {price.unit}  "
                     f"(effective {price.effective_start_date}, fetched {price.fetched_at})")
    with capsys.disabled():
        print(f"\n{stored} meters stored for Standard_D4s_v5 in uaenorth")
        print("\n".join(lines))
