"""Microsoft's architecture icons: every name we use resolves to a file, every file is the original
(SHA-256 as read from Microsoft's zip), and nothing else is in the folders."""

from __future__ import annotations

import hashlib
import json

from ms_agent.diagram.icons import ICON_DIR, ICONS, icon_path, icon_svg

ORIGINALS = json.loads((ICON_DIR / "originals.json").read_text(encoding="utf-8"))["files"]
REQUIRED = {"vm", "vmss", "disk", "vnet", "subnet", "nsg", "app_gateway", "load_balancer", "front_door",
            "api_management", "container_apps", "app_service", "aks", "sql_db", "sql_mi", "postgres", "storage",
            "key_vault", "log_analytics", "monitor", "defender", "bastion", "backup_vault", "recovery_vault",
            "vpn_gateway", "expressroute", "firewall", "entra_id", "openai", "foundry", "ai_search", "iot_hub",
            "digital_twins"}


def test_every_name_the_brief_lists_is_mapped_and_resolves_to_a_file() -> None:
    assert REQUIRED <= set(ICONS)
    for name in ICONS:
        assert icon_path(name).is_file(), name
        assert icon_svg(name).lstrip().startswith(("<svg", "<?xml")), name


def test_no_icon_is_modified() -> None:
    for relative, original in ORIGINALS.items():
        data = (ICON_DIR / relative).read_bytes()
        assert hashlib.sha256(data).hexdigest() == original["sha256"], relative
        assert original["path_in_zip"].endswith("/" + relative.split("/", 1)[1])


def test_the_folders_hold_only_the_mapped_originals() -> None:
    on_disk = {path.relative_to(ICON_DIR).as_posix() for path in ICON_DIR.rglob("*.svg")}
    assert on_disk == set(ORIGINALS) == set(ICONS.values())
    assert (ICON_DIR / "SOURCE.md").is_file()


def test_the_icons_hold_nothing_that_runs_or_fetches() -> None:
    for name in ICONS:
        text = icon_svg(name).lower()
        assert "<script" not in text and "<image" not in text and "href=\"http" not in text, name
