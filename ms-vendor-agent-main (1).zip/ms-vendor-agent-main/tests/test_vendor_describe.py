"""`vendor_describe`: the profile MAGIC's operator check reads."""

from __future__ import annotations

from datetime import UTC, datetime

from ms_agent.skills import REGISTRY


def test_the_profile_names_the_vendor_and_the_contract(rest) -> None:
    result = rest("vendor_describe", {})["result"]
    assert result["name"] == "Microsoft vendor agent" and result["vendor"] == "Microsoft"
    assert "vendor-agent/1" in result["contract_versions"] and result["contract"] == "vendor-agent/1"
    assert result["summary"] and result["advisory"] and result["maintained_by"]
    assert result["region"] == "MEA"
    assert result["endorsed_by_vendor"] is False
    assert result["request_retention_days"] == 0


def test_the_profile_has_product_lines_skills_version_and_data_date(rest) -> None:
    result = rest("vendor_describe", {})["result"]
    assert "Azure" in result["product_lines"] and "Microsoft 365 Copilot" in result["product_lines"]
    assert [skill["id"] for skill in result["skills"]] == list(REGISTRY)
    assert result["agent_version"] == "0.1.0-test"
    assert result["data_date"] == datetime.now(tz=UTC).date().isoformat()
    assert result["knowledge"][0]["domain"] == "learn.microsoft.com"


def test_the_profile_is_given_with_an_empty_request_and_echoes_the_number(rest) -> None:
    envelope = rest("vendor_describe", {"request_id": "check-1"})
    assert envelope["status"] == "complete" and envelope["request_id"] == "check-1"
    assert envelope["usage"] is None


def test_the_profile_needs_no_model_or_retriever() -> None:
    from tests.conftest import make_client

    client = make_client(None, None)
    response = client.post("/a2a/microsoft/rest", json={"skill": "vendor_describe", "request": {}},
                           headers={"x-api-key": "test-key-1"})
    assert response.json()["status"] == "complete"
