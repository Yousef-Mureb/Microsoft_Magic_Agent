"""`design_figure` and the drawing: deterministic SVG from the design data, Microsoft's icons inlined unchanged
with unique ids, nothing MAGIC's `safe_svg` refuses, zones and DR drawn, a real PNG, both stored as links."""

from __future__ import annotations

import re
import struct
import xml.etree.ElementTree as ElementTree
from typing import Any

import pytest
from fastapi.testclient import TestClient

from ms_agent.diagram.icons import icon_svg
from ms_agent.diagram.model import Component, FigureDesign, zones_label
from ms_agent.diagram.png import render_png
from ms_agent.diagram.svg import SVG_NS, render
from ms_agent.files import LocalFileStore
from ms_agent.main import create_app
from ms_agent.skills.base import Services
from tests.conftest import KEY, PUBLIC_URL, settings_for_tests
from tests.magic_safe_svg import safe_svg
from tests.pricing_data import loaded_store
from tests.test_operator_check import FORBIDDEN_KEY

PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
DESIGN = FigureDesign(region="uaenorth", region_name="UAE North", availability="with_dr", zones=3,
                      dr_region="uaecentral", dr_region_name="UAE Central", components=[
    Component(kind="users", name="Users", detail="over the internet", placement="outside"),
    Component(kind="app_gateway", name="Application Gateway WAF v2", detail="zone-redundant", placement="front"),
    Component(kind="vm", name="API workers", size="D4as_v7", count=2, zones=[1, 2], placement="app", web=True),
    Component(kind="vm", name="Processing workers", size="D8as_v7", count=3, zones=[1, 2, 3], placement="app"),
    Component(kind="bastion", name="Azure Bastion", detail="Basic", placement="management"),
    Component(kind="key_vault", name="Key Vault", detail="Standard", placement="shared"),
    Component(kind="entra_id", name="Microsoft Entra ID", placement="shared"),
    Component(kind="site_recovery", name="Azure Site Recovery", detail="5 VMs replicated", placement="dr"),
])
SVG = render(DESIGN)
WORKLOADS = [{"name": "API workers", "vcpu": 4, "memory_gb": 16, "os": "linux", "count": 2},
             {"name": "Processing workers", "vcpu": 8, "memory_gb": 32, "os": "linux", "count": 2}]


def tag(node: ElementTree.Element) -> str:
    return node.tag.rsplit("}", 1)[-1]


def test_the_drawing_is_deterministic_and_passes_magics_safe_svg() -> None:
    assert render(DESIGN) == SVG
    assert safe_svg(SVG.encode("utf-8")) == SVG
    lowered = SVG.lower()
    assert "<script" not in lowered and "<image" not in lowered and "<style" not in lowered
    assert not re.search(r"(href|src)=\"(?!#)", SVG)


def test_every_icon_is_inlined_whole_with_unique_ids() -> None:
    root = ElementTree.fromstring(SVG)
    ids = [node.attrib["id"] for node in root.iter() if "id" in node.attrib]
    assert len(ids) == len(set(ids))
    referenced = set(re.findall(r"url\(#([^)]+)\)", SVG))
    assert referenced <= set(ids)
    icons = [node for node in root if tag(node) == "svg"]
    assert len(icons) >= 12  # subscription, VNet, subnets and every node
    original = ElementTree.fromstring(icon_svg("app_gateway"))
    copies = [node for node in icons if len(list(node.iter())) == len(list(original.iter()))
              and [tag(one) for one in node.iter()] == [tag(one) for one in original.iter()]]
    assert copies, "the Application Gateway icon is in the drawing"
    for mine, theirs in zip(copies[0].iter(), original.iter(), strict=True):
        if mine is copies[0]:
            continue  # the root: only its position and size are set
        unprefixed = {name: re.sub(r"(url\(#|^#?)i\d+-", r"\1", value)
                      if (name == "id" or "url(#" in value or name.endswith("href")) else value
                      for name, value in mine.attrib.items()}
        assert unprefixed == theirs.attrib
        assert (mine.text or "").strip() == (theirs.text or "").strip()


def test_zones_subnets_shared_services_and_dr_are_drawn() -> None:
    texts = [node.text for node in ElementTree.fromstring(SVG).iter(f"{{{SVG_NS}}}text")]
    for expected in ("Azure subscription · UAE North (uaenorth)", "Virtual network", "Front-end subnet",
                     "Application subnet", "AzureBastionSubnet", "Availability zone 1", "Availability zone 2",
                     "Availability zone 3", "Shared services",
                     "Disaster recovery region · UAE Central (uaecentral)", "Microsoft Entra ID"):
        assert expected in texts, expected
    assert texts.count("API workers") == 2 and texts.count("Processing workers") == 3  # one node per zone
    assert texts.count("1 × D4as_v7") == 2 and texts.count("1 × D8as_v7") == 3
    assert SVG.count('marker-end="url(#arrow)"') >= 3  # users -> gateway, gateway -> the two API workers


def test_zone_labels() -> None:
    assert zones_label([1, 2]) == "zones 1–2" and zones_label([1, 2, 3]) == "zones 1–3"
    assert zones_label([2]) == "zone 2" and zones_label([1, 3]) == "zones 1, 3" and zones_label([]) == ""


def test_the_png_is_a_png_twice_the_svgs_size() -> None:
    png = render_png(SVG)
    assert png.startswith(PNG_SIGNATURE)
    width, height = struct.unpack(">II", png[16:24])
    svg_width = float(ElementTree.fromstring(SVG).attrib["width"])
    assert width == round(svg_width * 2) and height > 400


@pytest.fixture
def client(tmp_path) -> TestClient:
    settings = settings_for_tests()
    services = Services(settings=settings, prices=loaded_store(), files=LocalFileStore(tmp_path), version="test")
    return TestClient(create_app(settings=settings, services=services))


def ask(client: TestClient, skill: str, request: dict[str, Any]) -> dict[str, Any]:
    response = client.post("/a2a/microsoft/rest", json={"skill": skill, "request": request},
                           headers={"x-api-key": KEY})
    assert response.status_code == 200
    return response.json()


def keys_of(value: Any) -> list[str]:
    if isinstance(value, dict):
        return [*value] + [key for inner in value.values() for key in keys_of(inner)]
    if isinstance(value, list):
        return [key for inner in value for key in keys_of(inner)]
    return []


def test_design_figure_from_a_request_returns_svg_and_png_links(client: TestClient) -> None:
    envelope = ask(client, "design_figure", {"workloads": WORKLOADS, "region": "uaenorth",
                                             "availability": "zone_redundant"})
    assert envelope["status"] == "complete"
    assert [one["media_type"] for one in envelope["files"]] == ["image/svg+xml", "image/png"]
    assert all(one["url"].startswith(PUBLIC_URL + "/files/") for one in envelope["files"])
    result = envelope["result"]
    assert result["caption"].startswith("Azure architecture in UAE North, across availability zones: 4 virtual")
    assert {"icon": "vm", "service": "API workers"}.items() <= result["legend"][1].items()
    svg = client.get(envelope["files"][0]["url"].removeprefix(PUBLIC_URL), headers={"x-api-key": KEY})
    assert svg.headers["content-type"] == "image/svg+xml" and safe_svg(svg.content) is not None


def test_design_propose_returns_the_design_and_the_diagram_and_figure_takes_it_back(client: TestClient) -> None:
    proposed = ask(client, "design_propose", {"workloads": WORKLOADS, "region": "uaenorth",
                                              "availability": "zone_redundant"})
    media = [one["media_type"] for one in proposed["files"]]
    assert media == ["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "image/svg+xml",
                     "image/png"]
    design = proposed["result"]["design"]
    assert not [key for key in keys_of(design) if FORBIDDEN_KEY.search(key)]  # MAGIC can send it back
    assert proposed["result"]["diagram"]["svg"] == proposed["files"][1]["url"]
    drawn = ask(client, "design_figure", {"design": design})
    assert drawn["status"] == "complete" and drawn["result"]["design"] == design


def test_design_figure_needs_one_source(client: TestClient) -> None:
    assert ask(client, "design_figure", {})["refusal"]["code"] == "bad_request"
    both = {"workloads": WORKLOADS, "design": DESIGN.model_dump()}
    assert ask(client, "design_figure", both)["refusal"]["code"] == "bad_request"
    unknown = DESIGN.model_dump() | {"components": [{"kind": "vm", "name": "x", "placement": "nowhere"}]}
    assert ask(client, "design_figure", {"design": unknown})["refusal"]["code"] == "bad_request"
