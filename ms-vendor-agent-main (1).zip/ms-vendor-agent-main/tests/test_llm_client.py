"""The request the Azure OpenAI client puts on the wire: no sampling parameters, and a token
limit only as `max_completion_tokens`. Reasoning models such as `gpt-6.1-sol` answer HTTP 400 to
`temperature`, `top_p` and `max_tokens`. Without a key, a managed identity's bearer token."""

from __future__ import annotations

import json
import tomllib
from pathlib import Path
from types import SimpleNamespace

import httpx

from ms_agent.llm.client import FORBIDDEN_CHAT_PARAMETERS, AzureOpenAIClient, managed_identity_token_provider
from ms_agent.main import build_services
from tests.conftest import make_client, settings_for_tests

COMPLETION = {
    "id": "chatcmpl-1", "object": "chat.completion", "created": 0, "model": "gpt-6.1-sol",
    "choices": [{"index": 0, "finish_reason": "stop",
                 "message": {"role": "assistant", "content": '{"answer": "E3 or E5.", "citations": []}'}}],
    "usage": {"prompt_tokens": 11, "completion_tokens": 7, "total_tokens": 18},
}


def client_capturing(sent: list[dict], **options) -> AzureOpenAIClient:
    def answer(request: httpx.Request) -> httpx.Response:
        sent.append({"path": request.url.path, "body": json.loads(request.content)})
        return httpx.Response(200, json=COMPLETION)

    return AzureOpenAIClient(endpoint="https://example.openai.azure.com", api_key="test-only",
                             api_version="2024-10-21", chat_deployment="gpt-6.1-sol",
                             http_client=httpx.AsyncClient(transport=httpx.MockTransport(answer)), **options)


async def test_the_chat_request_carries_no_temperature_and_no_max_tokens() -> None:
    sent: list[dict] = []
    completion = await client_capturing(sent).complete_json("system words", "user words")
    assert len(sent) == 1
    body = sent[0]["body"]
    assert sent[0]["path"].endswith("/deployments/gpt-6.1-sol/chat/completions")
    assert "temperature" not in body
    assert "max_tokens" not in body
    assert "top_p" not in body
    assert "max_completion_tokens" not in body
    assert body["messages"] == [{"role": "system", "content": "system words"},
                                {"role": "user", "content": "user words"}]
    assert completion.text.startswith('{"answer"') and completion.prompt_tokens == 11


async def test_a_token_limit_goes_in_max_completion_tokens_only() -> None:
    sent: list[dict] = []
    await client_capturing(sent, max_completion_tokens=2000).complete_json("s", "u")
    body = sent[0]["body"]
    assert body["max_completion_tokens"] == 2000
    assert not FORBIDDEN_CHAT_PARAMETERS & body.keys()


def test_the_limit_is_read_from_the_environment_settings() -> None:
    settings = settings_for_tests(azure_openai_endpoint="https://example.openai.azure.com",
                                  azure_openai_api_key="test-only", azure_openai_chat_deployment="gpt-6.1-sol",
                                  azure_openai_max_completion_tokens=1500)
    client = AzureOpenAIClient.from_settings(settings)
    assert client is not None and client._max_completion_tokens == 1500


def test_healthz_and_the_card_report_the_version_in_pyproject() -> None:
    expected = tomllib.loads((Path(__file__).resolve().parents[1] / "pyproject.toml").read_text())["project"]["version"]
    assert expected == "0.3.0"
    settings = settings_for_tests()
    services = build_services(settings)
    assert services.version == expected
    client = make_client(services.retriever, None, settings=settings, version=services.version)
    assert client.get("/healthz").json()["version"] == expected
    assert client.get("/.well-known/agent-card.json").json()["version"] == expected


async def test_without_a_key_the_managed_identity_token_is_sent() -> None:
    sent: list[httpx.Request] = []

    def answer(request: httpx.Request) -> httpx.Response:
        sent.append(request)
        return httpx.Response(200, json=COMPLETION)

    client = AzureOpenAIClient(endpoint="https://example.openai.azure.com", token_provider=lambda: "identity-token",
                               api_version="2024-10-21", chat_deployment="gpt-6.1-sol",
                               http_client=httpx.AsyncClient(transport=httpx.MockTransport(answer)))
    await client.complete_json("s", "u")
    assert sent[0].headers["authorization"] == "Bearer identity-token"
    assert "api-key" not in sent[0].headers
    assert not FORBIDDEN_CHAT_PARAMETERS & json.loads(sent[0].content).keys()


def test_an_empty_key_uses_default_azure_credential_with_the_client_id(monkeypatch) -> None:
    import azure.identity

    made: list[dict] = []

    class Credential:
        def __init__(self, **options) -> None:
            made.append(options)

        def get_token(self, *scopes, **options):
            made.append({"scopes": scopes})
            return SimpleNamespace(token="t", expires_on=2**31)

    monkeypatch.setattr(azure.identity, "DefaultAzureCredential", Credential)
    settings = settings_for_tests(azure_openai_endpoint="https://example.openai.azure.com", azure_openai_api_key="",
                                  azure_openai_chat_deployment="gpt-6.1-sol", azure_client_id="client-id-1")
    assert settings.model_configured
    assert AzureOpenAIClient.from_settings(settings) is not None
    assert made == [{"managed_identity_client_id": "client-id-1"}]
    provider = managed_identity_token_provider("client-id-1")
    assert provider() == "t" and made[-1] == {"scopes": ("https://cognitiveservices.azure.com/.default",)}
