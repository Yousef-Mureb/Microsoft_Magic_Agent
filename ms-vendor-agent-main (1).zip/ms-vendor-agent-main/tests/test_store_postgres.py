"""The price store on PostgreSQL: the driver is installed, so a `postgresql+psycopg://` URL builds an engine.
No database is reached here; the tests keep SQLite. An unreachable store does not stop the agent."""

from __future__ import annotations

from sqlalchemy import create_engine

from ms_agent.main import open_price_store
from tests.conftest import settings_for_tests


def test_a_postgresql_psycopg_url_builds_an_engine_without_connecting() -> None:
    engine = create_engine("postgresql+psycopg://agent:not-a-secret@db.example.test:5432/prices")
    assert (engine.dialect.name, engine.dialect.driver) == ("postgresql", "psycopg")


def test_an_unreachable_postgresql_store_leaves_the_agent_running_without_prices() -> None:
    settings = settings_for_tests(
        ms_agent_price_db_url="postgresql+psycopg://agent:x@127.0.0.1:1/prices?connect_timeout=2")
    assert open_price_store(settings) is None
