"""Complete designs: the front door by traffic, the baseline services priced from exact meters with provenance
and stated quantities, a missing meter named, the backup bands, the workbook formulas over the new lines, and
the diagram drawing them."""

from __future__ import annotations

import io
import re
from decimal import Decimal
from typing import Any

import pytest
from fastapi.testclient import TestClient
from openpyxl import load_workbook

from ms_agent.files import LocalFileStore
from ms_agent.main import create_app
from ms_agent.skills.base import Services
from tests.conftest import KEY, settings_for_tests
from tests.pricing_data import loaded_store
from tests.xlsx_formulas import Evaluator

API = {"name": "API workers", "vcpu": 4, "memory_gb": 16, "os": "linux", "count": 2, "traffic": "http"}
WORKERS = {"name": "Processing workers", "vcpu": 8, "memory_gb": 32, "os": "linux", "count": 2}
REQUEST = {"workloads": [API, WORKERS], "region": "uaenorth", "availability": "zone_redundant",
           "pricing_models": ["payg"]}


def client_for(tmp_path, store: Any = None) -> TestClient:
    settings = settings_for_tests()
    services = Services(settings=settings, prices=store or loaded_store(), files=LocalFileStore(tmp_path),
                        version="test")
    return TestClient(create_app(settings=settings, services=services))


def propose(client: TestClient, request: dict[str, Any]) -> dict[str, Any]:
    response = client.post("/a2a/microsoft/rest", json={"skill": "design_propose", "request": request},
                           headers={"x-api-key": KEY})
    assert response.status_code == 200
    return response.json()


def lines_of(result: dict[str, Any]) -> dict[tuple[str, str], dict[str, Any]]:
    return {(line["service"], line["sku"]): line for line in result["lines"]}


def payg(line: dict[str, Any]) -> float:
    return line["by_model"]["payg"]["monthly"]


def test_http_workloads_get_application_gateway_waf_v2_not_a_load_balancer(tmp_path) -> None:
    envelope = propose(client_for(tmp_path), REQUEST)
    result, lines = envelope["result"], lines_of(envelope["result"])
    assert payg(lines[("Application Gateway", "WAF v2")]) == 346.75  # 0.475 × 730
    units = lines[("Application Gateway", "WAF v2 capacity units")]
    assert units["quantity"] == 2 and payg(units) == 27.74  # 0.019 × 730 × 2, the pilot default
    assert not any(service == "Load Balancer" for service, _ in lines)
    gateway = next(item for item in result["solution"]["network"] if item["kind"] == "app_gateway")
    assert gateway["placement"] == "front" and gateway["priced"] is True
    assert [one["entry"] for one in result["solution"]["compute"]] == ["app_gateway", ""]
    assert any(caveat.startswith("The HTTP workloads are published through Application Gateway WAF v2") and
               "has no Web Application Firewall" in caveat for caveat in result["caveats"])


def test_third_party_apis_get_api_management_and_tcp_a_standard_load_balancer(tmp_path) -> None:
    client = client_for(tmp_path)
    lines = lines_of(propose(client, REQUEST | {"third_party_apis": True})["result"])
    assert payg(lines[("API Management", "Standard v2")]) == 700.0  # 0.9589 × 730 = 699.997
    assert ("Application Gateway", "WAF v2") not in lines
    tcp = REQUEST | {"workloads": [API | {"traffic": "tcp"}, WORKERS]}
    lines = lines_of(propose(client, tcp)["result"])
    rules = lines[("Load Balancer", "Standard")]
    assert payg(rules) == 18.25 and rules["by_model"]["payg"]["sources"][0]["url"].count("Global") == 1
    assert payg(lines[("Load Balancer", "Standard data processed")]) == 0.5  # 100 GB × 0.005


def test_the_baseline_is_priced_line_by_line_with_provenance_and_stated_quantities(tmp_path) -> None:
    result = propose(client_for(tmp_path), REQUEST)["result"]
    lines = lines_of(result)
    expected = {  # four VMs; recorded UAE North prices
        ("Managed Disks", "P10 LRS"): None,  # the OS disks, one line per workload
        ("Key Vault", "Standard operations"): 0.4,  # 0.0396 × 10 (100,000 operations)
        ("Log Analytics", "Analytics Logs ingestion"): 200.13,  # 60.83 GB × 3.29 = 200.1307, the paid tier
        ("Azure Bastion", "Basic"): 138.7,  # 0.19 × 730
        ("Backup", "GRS storage"): 45.39,  # 768 GB × 0.0591 = 45.3888 (1.5 × 4 × 128 GiB)
    }
    for key, monthly in expected.items():
        assert key in lines, key
        if monthly is not None:
            assert payg(lines[key]) == monthly, key
    assert lines[("Log Analytics", "Analytics Logs ingestion")]["quantity"] == 60.83
    defender = [line for line in result["lines"] if line["service"] == "Microsoft Defender for Cloud"]
    assert [payg(line) for line in defender] == [29.2, 29.2]  # 0.02 × 730 × 2, per workload
    backups = [line for line in result["lines"] if line["sku"] == "Azure VM protected instance"]
    assert [(line["quantity"], payg(line)) for line in backups] == [(2, 20.0), (2, 20.0)]
    for line in result["lines"]:
        price = line["by_model"]["payg"]
        assert price is not None, line["description"]
        assert price["source_url"].startswith("https://prices.azure.com/") and price["effective_start_date"]
        assert price["fetched_at"] and price["currency"] == "USD"
    for words in ("Key Vault Standard: 100,000 operations", "0.5 GB of logs a day per VM",
                  "2 capacity units every hour (request input gateway_capacity_units; default 2, for a pilot)",
                  "one protected-instance unit per started 500 GB", "OS disk"):
        assert any(words in text for text in result["assumptions"]), words
    roles = {role: [item["kind"] for item in items] for role, items in result["solution"].items()}
    assert {"key_vault", "defender", "entra_id"} <= set(roles["security"])
    assert roles["monitoring"] == ["log_analytics"] and roles["backup"] == ["recovery_vault"]
    assert result["gaps"] == []


def test_backup_counts_one_unit_per_started_500_gb(tmp_path) -> None:
    big = API | {"disks": [{"type": "premium_ssd", "size_gb": 1000}]}  # P30, 1024 GiB, plus the 128 GiB OS disk
    result = propose(client_for(tmp_path), REQUEST | {"workloads": [big]})["result"]
    backup = next(line for line in result["lines"] if line["sku"] == "Azure VM protected instance")
    assert backup["quantity"] == 6 and "3 protected-instance unit(s) each" in backup["description"]  # 2 VMs × 3


def test_a_missing_meter_is_named_not_vague(tmp_path) -> None:
    store = loaded_store()
    store.replace([], scope={"arm_region_name": "uaenorth", "service_name": "Azure Bastion"}, currency="USD",
                  fetched_at="x", source_url_of=lambda item: "")
    envelope = propose(client_for(tmp_path, store), REQUEST)
    gap = next(gap for gap in envelope["result"]["gaps"] if "Basic Gateway" in gap)
    assert gap == ("Not priced: No meter 'Basic Gateway' (service 'Azure Bastion', product 'Azure Bastion', SKU "
                   "'Basic') in uaenorth in the price store.")
    assert envelope["status"] == "partial" and "matching" not in gap
    assert [one["code"] for one in envelope["warnings"]].count("price_missing") >= 1


def test_the_workbook_formulas_give_the_totals_with_the_new_lines(tmp_path) -> None:
    client = client_for(tmp_path)
    envelope = propose(client, REQUEST)
    url = envelope["result"]["workbook"]["url"]
    data = client.get(url[url.index("/files/"):], headers={"x-api-key": KEY}).content
    workbook = load_workbook(io.BytesIO(data))
    lines = workbook["Lines"]
    services = [row[1] for row in lines.iter_rows(min_row=2, values_only=True)]
    assert {"Application Gateway", "Key Vault", "Log Analytics", "Azure Bastion", "Backup"} <= set(services)
    evaluate = Evaluator(workbook)
    for column, row in zip("BCDEF", envelope["result"]["totals"], strict=True):
        assert evaluate.cell("Summary", f"{column}5") == Decimal(repr(row["monthly"])), row["pricing_model"]
    assumptions = [row[1] for row in workbook["Assumptions"].iter_rows(min_row=2, values_only=True)]
    assert any("Log Analytics: 0.5 GB" in text for text in assumptions)


def test_the_diagram_draws_the_complete_design(tmp_path) -> None:
    client = client_for(tmp_path)
    envelope = propose(client, REQUEST | {"availability": "with_dr", "connectivity": "vpn"})
    svg_url = envelope["result"]["diagram"]["svg"]
    svg = client.get(svg_url[svg_url.index("/files/"):], headers={"x-api-key": KEY}).text
    texts = " ".join(re.findall(r">([^<>]+)</text>", svg))  # a long name is drawn on two lines
    for name in ("Application Gateway WAF v2", "Key Vault", "Log Analytics", "Defender for Cloud", "Azure Bastion",
                 "Recovery Services vault", "Microsoft Entra ID", "Azure Site Recovery", "Azure VPN Gateway",
                 "Customer network", "AzureBastionSubnet", "Disaster recovery region · UAE Central (uaecentral)"):
        assert name in texts, name
    assert any(gap.startswith("Drawn, not priced: Azure VPN Gateway") for gap in envelope["result"]["gaps"])


@pytest.mark.parametrize("environment", ["production", "dev_test"])
def test_b_series_follows_the_environment_in_designs(tmp_path, environment: str) -> None:
    small = {"name": "jump", "vcpu": 2, "memory_gb": 4, "count": 1, "environment": environment}
    envelope = propose(client_for(tmp_path), {"workloads": [small], "families": ["B"]})
    if environment == "dev_test":
        assert envelope["result"]["workloads"][0]["size"]["family"] == "B"
    else:
        assert envelope["refusal"]["code"] == "no_size" and "dev_test" in envelope["refusal"]["message"]


def test_gateway_capacity_units_are_a_request_input_stated_on_the_line_and_the_assumptions(tmp_path) -> None:
    client = client_for(tmp_path)
    result = propose(client, REQUEST | {"gateway_capacity_units": 20})["result"]
    units = lines_of(result)[("Application Gateway", "WAF v2 capacity units")]
    assert units["quantity"] == 20 and payg(units) == 277.4  # 0.019 × 730 × 20
    assert "20 every hour, assumed (request input gateway_capacity_units; default 2" in units["description"]
    assert any("plus 20 capacity units every hour (request input gateway_capacity_units" in text
               for text in result["assumptions"])
    assert propose(client, REQUEST | {"gateway_capacity_units": -1})["refusal"]["code"] == "bad_request"


@pytest.mark.parametrize(("connectivity", "service"), [("vpn", "Azure VPN Gateway"),
                                                       ("expressroute", "Azure ExpressRoute")])
def test_a_private_connection_is_listed_by_name_as_drawn_not_priced(tmp_path, connectivity: str,
                                                                    service: str) -> None:
    client = client_for(tmp_path)
    result = propose(client, REQUEST | {"connectivity": connectivity})["result"]
    assert result["not_priced"] == [{"service": service, "status": "drawn, not priced",
                                     "item": result["not_priced"][0]["item"]}]
    assert any(gap.startswith(f"Drawn, not priced: {service}") for gap in result["gaps"])
    assert not any(line["service"] == service for line in result["lines"])  # in no total
    url = result["workbook"]["url"]
    workbook = load_workbook(io.BytesIO(client.get(url[url.index("/files/"):], headers={"x-api-key": KEY}).content))
    summary = [row[0] for row in workbook["Summary"].iter_rows(values_only=True) if row[0]]
    assert "Drawn, not priced" in summary
    assert any(str(text).startswith(f"{service}: ") and "drawn, not priced" in str(text) for text in summary)
    assumptions = [row[1] for row in workbook["Assumptions"].iter_rows(min_row=2, values_only=True)]
    expected = f"Drawn, not priced: {service} ({result['not_priced'][0]['item']}); the estimate leaves it out."
    assert expected in assumptions
