"""Recorded Retail Prices API items (tests/fixtures/retail_uaenorth.json, made by
scripts/record_price_fixtures.py) and a price store loaded with them. No network."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ms_agent.pricing.ingest import source_url_of
from ms_agent.pricing.store import SqlPriceStore

FIXTURES = Path(__file__).resolve().parent / "fixtures"
RECORDED = json.loads((FIXTURES / "retail_uaenorth.json").read_text(encoding="utf-8"))
ITEMS: list[dict[str, Any]] = RECORDED["Items"]
FETCHED_AT = "2026-10-26T02:00:00Z"


def items_where(**equals: Any) -> list[dict[str, Any]]:
    return [item for item in ITEMS if all(item.get(key) == value for key, value in equals.items())]


def item(**equals: Any) -> dict[str, Any]:
    found = items_where(**equals)
    assert len(found) == 1, (equals, len(found))
    return found[0]


SERVICES: list[dict[str, Any]] = json.loads((FIXTURES / "retail_services.json").read_text(encoding="utf-8"))["Items"]


def loaded_store(url: str = "sqlite://") -> SqlPriceStore:
    """A store holding every recorded item, as one ingestion would leave it: step 2's UAE North VM and disk
    meters, and step 3's baseline services, Load Balancer (Global) and UAE Central."""
    store = SqlPriceStore(url)
    store.replace(ITEMS, scope={"arm_region_name": "uaenorth"}, currency="USD", fetched_at=FETCHED_AT,
                  source_url_of=source_url_of)
    groups: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for one in SERVICES:
        groups.setdefault((one["armRegionName"], one["serviceName"]), []).append(one)
    for (region, service), items in groups.items():
        store.replace(items, scope={"arm_region_name": region, "service_name": service}, currency="USD",
                      fetched_at=FETCHED_AT, source_url_of=source_url_of)
    return store
