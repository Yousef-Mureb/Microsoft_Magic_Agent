"""The vendor logo: SVG at /logo.svg and inline as `logo_svg`, the way MAGIC keeps logos (`safe_svg`); the PNG
still at /logo.png. Both public on the card's host, both in the image."""

from __future__ import annotations

import hashlib
from pathlib import Path
from urllib.parse import urlsplit

import pytest

from ms_agent.skills.vendor_describe import LOGO_SVG, PNG_LOGO_FILE, SVG_LOGO_FILE
from tests.conftest import KEY, PUBLIC_URL, make_client
from tests.magic_safe_svg import safe_svg

ROOT = Path(__file__).resolve().parents[1]
PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
SVG = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23 23"><rect x="1" y="1" width="10" height="10" '
       'fill="#F25022"/><rect x="12" y="1" width="10" height="10" fill="#7FBA00"/><rect x="1" y="12" width="10" '
       'height="10" fill="#00A4EF"/><rect x="12" y="12" width="10" height="10" fill="#FFB900"/></svg>')


def described() -> dict:
    return make_client().post("/a2a/microsoft/rest", json={"skill": "vendor_describe", "request": {}},
                              headers={"x-api-key": KEY}).json()["result"]


def test_the_svg_file_holds_exactly_the_given_logo() -> None:
    assert SVG_LOGO_FILE.read_bytes() == SVG.encode("utf-8")


def test_the_svg_logo_is_served_without_a_key() -> None:
    response = make_client().get("/logo.svg")
    assert response.status_code == 200
    assert response.headers["content-type"] == "image/svg+xml"
    assert response.content == SVG_LOGO_FILE.read_bytes()
    assert "x-api-key" not in response.request.headers


def test_the_png_logo_is_still_served_without_a_key() -> None:
    response = make_client().get("/logo.png")
    assert response.status_code == 200 and response.headers["content-type"] == "image/png"
    assert response.content == PNG_LOGO_FILE.read_bytes() and response.content.startswith(PNG_SIGNATURE)


def test_vendor_describe_gives_the_svg_inline_and_its_url_on_the_cards_host() -> None:
    result = described()
    assert result["logo_svg"] == SVG_LOGO_FILE.read_bytes().decode("utf-8") == LOGO_SVG
    assert result["logo_url"] == PUBLIC_URL + "/logo.svg"
    card = make_client().get("/.well-known/agent-card.json").json()
    endpoint = next(one["url"] for one in card["supportedInterfaces"] if one["protocolBinding"] == "JSONRPC")
    assert urlsplit(result["logo_url"]).netloc == urlsplit(endpoint).netloc


def test_our_svg_passes_magics_safe_svg_unchanged() -> None:
    """Both ways MAGIC reads it: `logo_svg` inline, and the bytes fetched from `logo_url`."""
    assert safe_svg(described()["logo_svg"].encode("utf-8")) == SVG
    assert safe_svg(make_client().get("/logo.svg").content) == SVG
    assert safe_svg(PNG_LOGO_FILE.read_bytes()) is None  # why the PNG alone was not enough


@pytest.mark.parametrize("picture", [  # MAGIC's own cases (test_vendors.py), to show the copy behaves as MAGIC's
    '<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>',
    '<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)"/>',
    '<svg xmlns="http://www.w3.org/2000/svg"><image href="https://x.test/a.png"/></svg>',
    '<svg xmlns="http://www.w3.org/2000/svg"><rect style="fill:url(https://x.test/a)"/></svg>',
    '<html/>',
])
def test_the_copied_safe_svg_refuses_what_magic_refuses(picture: str) -> None:
    assert safe_svg(picture.encode()) is None


def test_both_files_are_in_the_image_and_the_png_is_unchanged() -> None:
    assert SVG_LOGO_FILE.parent == PNG_LOGO_FILE.parent == ROOT / "src" / "ms_agent" / "static"
    data = PNG_LOGO_FILE.read_bytes()
    assert hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest() == "a3d5d7f894dd5edcb4f5ade01378a83a668d61c9"
    dockerfile = (ROOT / "Dockerfile").read_text(encoding="utf-8")
    assert "COPY src/ ./src/" in dockerfile and "COPY --from=build --chown=agent:agent /app/src /app/src" in dockerfile
