"""A small evaluator of the formulas the estimate workbook uses, so the tests can check that the
formulas themselves (not only the values cached next to them) give the Python totals. It knows
numbers, cell references (with a sheet), ranges in SUM, ROUND (half away from zero, as Excel), the
four operations and parentheses; anything else fails the test."""

from __future__ import annotations

import re
from decimal import ROUND_HALF_UP, Decimal
from typing import Any

from openpyxl.utils import column_index_from_string, get_column_letter
from openpyxl.workbook import Workbook

TOKEN = re.compile(r"\s*(?:(?P<number>\d+(?:\.\d+)?)|(?P<ref>(?:[A-Za-z]+!)?\$?[A-Z]+\$?\d+(?::\$?[A-Z]+\$?\d+)?)"
                   r"|(?P<name>[A-Z]+)(?=\()|(?P<op>[-+*/(),]))")


class Evaluator:
    def __init__(self, workbook: Workbook) -> None:
        self.workbook = workbook

    def cell(self, sheet: str, coordinate: str) -> Any:
        value = self.workbook[sheet][coordinate.replace("$", "")].value
        if isinstance(value, str) and value.startswith("="):
            return self.formula(sheet, value[1:])
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return Decimal(repr(value))
        return value

    def formula(self, sheet: str, text: str) -> Decimal:
        tokens = [(kind, value) for match in TOKEN.finditer(text) for kind, value in match.groupdict().items()
                  if value is not None]
        assert "".join(value for _, value in tokens) == text.replace(" ", ""), f"unknown syntax in {text!r}"
        saved = (getattr(self, "tokens", []), getattr(self, "at", 0), getattr(self, "sheet", sheet))
        self.tokens, self.at, self.sheet = tokens, 0, sheet
        value = self._expression()
        assert self.at == len(tokens), f"trailing tokens in {text!r}"
        self.tokens, self.at, self.sheet = saved  # a formula may be evaluated inside another
        return value

    def _peek(self) -> tuple[str, str] | None:
        return self.tokens[self.at] if self.at < len(self.tokens) else None

    def _take(self, expected: str | None = None) -> tuple[str, str]:
        token = self.tokens[self.at]
        assert expected is None or token[1] == expected, (token, expected)
        self.at += 1
        return token

    def _expression(self) -> Decimal:
        value = self._term()
        while (token := self._peek()) and token[1] in "+-":
            self._take()
            value = value + self._term() if token[1] == "+" else value - self._term()
        return value

    def _term(self) -> Decimal:
        value = self._factor()
        while (token := self._peek()) and token[1] in "*/":
            self._take()
            value = value * self._factor() if token[1] == "*" else value / self._factor()
        return value

    def _factor(self) -> Decimal:
        kind, value = self._take()
        if kind == "number":
            return Decimal(value)
        if value == "-":
            return -self._factor()
        if value == "(":
            inner = self._expression()
            self._take(")")
            return inner
        if kind == "name":
            return self._function(value)
        if kind == "ref":
            assert ":" not in value, "a range outside SUM"
            sheet, coordinate = self._split(value)
            found = self.cell(sheet, coordinate)
            assert isinstance(found, Decimal), f"{value} is not a number: {found!r}"
            return found
        raise AssertionError(f"unexpected {value!r}")

    def _split(self, ref: str) -> tuple[str, str]:
        return tuple(ref.split("!")) if "!" in ref else (self.sheet, ref)  # type: ignore[return-value]

    def _function(self, name: str) -> Decimal:
        self._take("(")
        if name == "SUM":
            kind, ref = self._take()
            assert kind == "ref" and ":" in ref
            self._take(")")
            sheet, cells = self._split(ref)
            first, last = cells.replace("$", "").split(":")
            start_column, start_row = re.match(r"([A-Z]+)(\d+)", first).groups()  # type: ignore[union-attr]
            end_column, end_row = re.match(r"([A-Z]+)(\d+)", last).groups()  # type: ignore[union-attr]
            total = Decimal("0")
            for column in range(column_index_from_string(start_column), column_index_from_string(end_column) + 1):
                for row in range(int(start_row), int(end_row) + 1):
                    found = self.cell(sheet, f"{get_column_letter(column)}{row}")
                    if isinstance(found, Decimal):  # text such as "n/a" is skipped, as Excel does
                        total += found
            return total
        if name == "ROUND":
            value = self._expression()
            self._take(",")
            digits = int(self._expression())
            self._take(")")
            return value.quantize(Decimal(1).scaleb(-digits), rounding=ROUND_HALF_UP)
        raise AssertionError(f"unknown function {name}")
