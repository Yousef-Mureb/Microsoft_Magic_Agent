"""The golden run's scoring: per-fact verdicts, judge errors counted apart from missing facts, the
model judge used also against a running agent, and the JSON that keeps the evidence."""

from __future__ import annotations

import json
from argparse import Namespace

import httpx
from evaluations import run_golden
from evaluations.run_golden import JUDGE_ERROR, MISSING, PRESENT, Golden, KeywordJudge, ModelJudge, score, table

from ms_agent.llm.client import FORBIDDEN_CHAT_PARAMETERS, AzureOpenAIClient, Completion

GOLDEN = Golden(id="t-01", domain="azure", question="Does UAE North have availability zones?",
                expected_facts=["UAE North has three availability zones", "Zones are physically separate"],
                must_not_say=["UAE North has no availability zones"],
                sources=[{"url": "https://learn.microsoft.com/azure/reliability/regions-list"}])
ENVELOPE = {"status": "complete", "usage": {"seconds": 1.5},
            "result": {"answer": "UAE North has three availability zones.",
                       "citations": [{"url": "https://learn.microsoft.com/en-us/azure/reliability/regions-list",
                                      "title": "Regions", "quote": "UAE North has three availability zones."}],
                       "passage_urls": ["https://learn.microsoft.com/en-us/azure/reliability/regions-list"]}}


class ScriptedModel:
    def __init__(self, *answers) -> None:
        self.answers = list(answers)

    async def complete_json(self, system: str, user: str) -> Completion:
        answer = self.answers.pop(0)
        if isinstance(answer, Exception):
            raise answer
        return Completion(text=answer)


async def test_each_fact_gets_a_verdict_and_judge_errors_are_counted_apart() -> None:
    judge = ModelJudge(ScriptedModel('{"states": true}', RuntimeError("HTTP 429"), "not json"))
    found = await score(GOLDEN, ENVELOPE, judge)
    assert [one.verdict for one in found.facts] == [PRESENT, JUDGE_ERROR]
    assert "HTTP 429" in found.facts[1].error
    assert [one.verdict for one in found.forbidden] == [JUDGE_ERROR]
    assert found.facts_present == 1 and found.judge_errors == 2 and found.forbidden_said == 0
    assert not found.passed
    assert "facts 1/2 (missing 0, judge errors 2)" in table([found])


async def test_the_score_keeps_answer_citations_and_retrieved_urls() -> None:
    found = await score(GOLDEN, ENVELOPE, KeywordJudge())
    assert found.answer == "UAE North has three availability zones."
    assert found.citations[0]["quote"] == "UAE North has three availability zones."
    assert found.passage_urls == ENVELOPE["result"]["passage_urls"]
    assert found.facts[0].verdict == PRESENT and found.facts[1].verdict == MISSING


async def test_the_json_holds_the_evidence_per_question(tmp_path, monkeypatch) -> None:
    class Asker:
        def __init__(self, *args) -> None: ...

        async def ask(self, golden):
            return ENVELOPE

    questions = tmp_path / "q.yaml"
    questions.write_text(json.dumps([GOLDEN.model_dump()]), encoding="utf-8")
    monkeypatch.setattr(run_golden, "HttpAsker", Asker)
    out = tmp_path / "scores.json"
    arguments = Namespace(questions=str(questions), only=None, limit=0, judge="keyword", url="http://agent",
                          key="k", fake=False, json=str(out))
    await run_golden.run(arguments)
    row = json.loads(out.read_text(encoding="utf-8"))[0]
    assert row["answer"] and row["citations"] and row["passage_urls"]
    assert [fact["verdict"] for fact in row["facts"]] == [PRESENT, MISSING]
    assert set(row["facts"][0]) == {"statement", "verdict", "error"}


async def test_the_model_judge_is_used_with_url_too(monkeypatch) -> None:
    used = []
    monkeypatch.setattr(run_golden, "model_judge", lambda fake: used.append(fake) or KeywordJudge())

    class Asker:
        def __init__(self, *args) -> None: ...

        async def ask(self, golden):
            return ENVELOPE

    monkeypatch.setattr(run_golden, "HttpAsker", Asker)
    monkeypatch.setattr(run_golden, "load", lambda path: [GOLDEN])
    await run_golden.run(Namespace(questions="x", only=None, limit=0, judge="model", url="http://agent", key="k",
                                   fake=False, json=None))
    assert used == [False]


async def test_the_judge_sends_no_sampling_parameters() -> None:
    sent: list[dict] = []

    def answer(request: httpx.Request) -> httpx.Response:
        sent.append(json.loads(request.content))
        return httpx.Response(200, json={"id": "c", "object": "chat.completion", "created": 0, "model": "m",
                                         "choices": [{"index": 0, "finish_reason": "stop", "message": {
                                             "role": "assistant", "content": '{"states": true}'}}]})

    model = AzureOpenAIClient(endpoint="https://example.openai.azure.com", api_key="test-only",
                              api_version="2024-10-21", chat_deployment="gpt-6.1-sol",
                              http_client=httpx.AsyncClient(transport=httpx.MockTransport(answer)))
    verdict = await ModelJudge(model).judge("UAE North has three zones.", "UAE North has zones")
    assert verdict.verdict == PRESENT
    assert not FORBIDDEN_CHAT_PARAMETERS & sent[0].keys()
