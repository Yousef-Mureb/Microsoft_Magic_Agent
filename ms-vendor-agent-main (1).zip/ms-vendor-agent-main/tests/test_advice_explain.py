"""`advice_explain` with a fake retriever and a fake model: an answer carries citations and usage, and
an answer without a citation that points at a retrieved page is refused."""

from __future__ import annotations

import json

from ms_agent.knowledge.learn_mcp import LearnMcpError
from ms_agent.knowledge.retriever import Passage, canonical
from tests.conftest import COPILOT_TEXT, COPILOT_TITLE, COPILOT_URL, KEY, QUOTE, FakeModel, FakeRetriever, make_client

QUESTION = "Which Microsoft 365 plans are required before a customer can buy Microsoft 365 Copilot?"


def ask(retriever, model, request: dict | None = None) -> dict:
    client = make_client(retriever, model)
    body = {"skill": "advice_explain", "request": request or {"question": QUESTION, "request_id": "r-1"}}
    response = client.post("/a2a/microsoft/rest", json=body, headers={"x-api-key": KEY})
    assert response.status_code == 200
    return response.json()


def test_an_answer_carries_answer_citations_and_usage() -> None:
    retriever, model = FakeRetriever(), FakeModel()
    envelope = ask(retriever, model)
    assert envelope["status"] == "complete" and envelope["request_id"] == "r-1"
    result = envelope["result"]
    assert result["answer"] == "Microsoft 365 E3 or E5 is required."
    assert result["citations"] == [{"url": COPILOT_URL, "title": COPILOT_TITLE, "quote": QUOTE}]
    assert result["passages_considered"] == 1
    assert result["passage_urls"] == [COPILOT_URL]
    usage = envelope["usage"]
    assert usage["prompt_tokens"] == 120 and usage["completion_tokens"] == 40 and usage["seconds"] >= 0
    assert envelope["warnings"] == []


def test_the_model_sees_the_question_and_the_passages_only() -> None:
    retriever, model = FakeRetriever(), FakeModel()
    ask(retriever, model, {"question": QUESTION, "part": {"sku": "Microsoft 365 E3"}})
    assert retriever.questions == [QUESTION]
    system, user = model.calls[0]
    assert "Answer only from the numbered passages" in system
    assert QUESTION in user and COPILOT_URL in user and COPILOT_TEXT in user
    assert '"sku": "Microsoft 365 E3"' in user


def test_no_citation_is_an_error_not_an_answer() -> None:
    envelope = ask(FakeRetriever(), FakeModel(answer="E3 or E5.", citations=[]))
    assert envelope["status"] == "failed"
    assert envelope["refusal"]["code"] == "no_citation"
    assert envelope["result"] is None
    assert envelope["usage"]["prompt_tokens"] == 120


def test_a_citation_to_a_page_that_was_not_retrieved_is_dropped() -> None:
    foreign = [{"url": "https://example.com/made-up", "title": "Made up", "quote": "x"}]
    envelope = ask(FakeRetriever(), FakeModel(citations=foreign))
    assert envelope["status"] == "failed" and envelope["refusal"]["code"] == "no_citation"
    mixed = foreign + [{"url": COPILOT_URL, "title": COPILOT_TITLE, "quote": QUOTE}]
    envelope = ask(FakeRetriever(), FakeModel(citations=mixed))
    assert envelope["status"] == "complete"
    assert [one["url"] for one in envelope["result"]["citations"]] == [COPILOT_URL]
    assert [one["code"] for one in envelope["warnings"]] == ["citation_dropped"]


def test_the_same_page_in_another_spelling_still_counts() -> None:
    spelled = "https://LEARN.microsoft.com/microsoft-365/copilot/copilot-license-options/#microsoft-copilot-licenses"
    assert canonical(spelled) == canonical(COPILOT_URL)
    envelope = ask(FakeRetriever(), FakeModel(citations=[{"url": spelled, "title": "", "quote": QUOTE}]))
    assert envelope["status"] == "complete"
    assert envelope["result"]["citations"][0] == {"url": COPILOT_URL, "title": COPILOT_TITLE, "quote": QUOTE}


def test_a_quote_that_is_not_in_the_passage_is_replaced_and_warned() -> None:
    invented = [{"url": COPILOT_URL, "title": COPILOT_TITLE, "quote": "Copilot is free with every plan."}]
    envelope = ask(FakeRetriever(), FakeModel(citations=invented))
    assert envelope["status"] == "complete"
    assert envelope["result"]["citations"][0]["quote"] == COPILOT_TEXT[:300].strip()
    assert [one["code"] for one in envelope["warnings"]] == ["quote_not_verbatim"]


def test_without_passages_the_question_is_refused_before_the_model() -> None:
    model = FakeModel()
    envelope = ask(FakeRetriever(passages=[]), model)
    assert envelope["refusal"]["code"] == "no_sources"
    assert model.calls == []


def test_when_learn_cannot_be_reached_the_refusal_says_so() -> None:
    envelope = ask(FakeRetriever(failure=LearnMcpError("The Learn server answered HTTP 503.")), FakeModel())
    assert envelope["refusal"]["code"] == "sources_unavailable"
    assert "503" in envelope["refusal"]["message"]


def test_without_a_model_the_skill_refuses_with_a_clear_code() -> None:
    envelope = ask(FakeRetriever(), None)
    assert envelope["refusal"]["code"] == "model_not_configured"


def test_a_model_answer_that_is_not_the_expected_json_is_refused() -> None:
    envelope = ask(FakeRetriever(), FakeModel(text="E3 or E5, trust me."))
    assert envelope["refusal"]["code"] == "bad_model_output"
    envelope = ask(FakeRetriever(), FakeModel(text=json.dumps({"citations": []})))
    assert envelope["refusal"]["code"] == "bad_model_output"


def test_the_question_is_validated_against_the_card_schema() -> None:
    envelope = ask(FakeRetriever(), FakeModel(), {"question": "hi"})
    assert envelope["refusal"]["code"] == "bad_request" and "question" in envelope["refusal"]["message"]
    envelope = ask(FakeRetriever(), FakeModel(), {"question": QUESTION, "customer": "Acme"})
    assert envelope["refusal"]["code"] == "bad_request"


def test_several_passages_are_numbered_for_the_model() -> None:
    passages = [Passage(url=COPILOT_URL, title=COPILOT_TITLE, text=COPILOT_TEXT),
                Passage(url="https://learn.microsoft.com/azure/reliability/regions-list", title="Azure regions list",
                        text="UAE North has three availability zones.")]
    model = FakeModel()
    ask(FakeRetriever(passages=passages), model)
    user = model.calls[0][1]
    assert "[1] title: " + COPILOT_TITLE in user and "[2] title: Azure regions list" in user


def test_the_same_page_cited_three_times_is_one_citation() -> None:
    """The live agent cited one page three times; the answer names each page once."""
    spelled = COPILOT_URL.replace("https://learn", "https://LEARN") + "#prerequisites"
    citations = [{"url": COPILOT_URL, "title": COPILOT_TITLE, "quote": "not in the passage"},
                 {"url": spelled, "title": "", "quote": QUOTE},
                 {"url": COPILOT_URL + "/", "title": COPILOT_TITLE, "quote": "Microsoft 365 Business Premium"}]
    second = Passage(url=COPILOT_URL, title=COPILOT_TITLE, text="A second passage of the same page.")
    envelope = ask(FakeRetriever(passages=[*FakeRetriever().passages, second]), FakeModel(citations=citations))
    assert envelope["status"] == "complete"
    assert envelope["result"]["citations"] == [{"url": COPILOT_URL, "title": COPILOT_TITLE, "quote": QUOTE}]
    assert envelope["result"]["passage_urls"] == [COPILOT_URL]
    assert envelope["warnings"] == []


def test_the_prompt_asks_for_completeness_before_brevity() -> None:
    model = FakeModel()
    ask(FakeRetriever(), model)
    system = model.calls[0][0]
    assert "every condition, prerequisite, limit and exception" in system
    assert "Every claim needs a citation" in system and "Cite each page once" in system
