"""Fakes and fixtures: a retriever that returns fixed passages, a model that returns fixed JSON,
and the application built on them. No network, no Azure."""

from __future__ import annotations

import json
from collections.abc import Callable
from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient

from ms_agent.knowledge.retriever import Passage
from ms_agent.llm.client import Completion
from ms_agent.main import create_app
from ms_agent.settings import Settings
from ms_agent.skills.base import Services

KEY = "test-key-1"
PUBLIC_URL = "https://ms-agent.test"
COPILOT_URL = "https://learn.microsoft.com/en-us/microsoft-365/copilot/copilot-license-options"
COPILOT_TITLE = "License options for Microsoft Copilot"
COPILOT_TEXT = ("The following plans are eligible prerequisite licenses for Microsoft 365 Copilot: Microsoft 365 E3, "
                "Microsoft 365 E5, Office 365 E3, Office 365 E5, Microsoft 365 Business Standard and Microsoft 365 "
                "Business Premium. After you purchase licenses, assign the licenses to users in the Microsoft 365 "
                "admin center.")
PASSAGES = [Passage(url=COPILOT_URL, title=COPILOT_TITLE, text=COPILOT_TEXT)]
QUOTE = "Microsoft 365 E3, Microsoft 365 E5, Office 365 E3, Office 365 E5"


class FakeRetriever:
    def __init__(self, passages: list[Passage] | None = None, failure: Exception | None = None) -> None:
        self.passages = PASSAGES if passages is None else passages
        self.failure = failure
        self.questions: list[str] = []

    async def retrieve(self, question: str, *, limit: int = 8) -> list[Passage]:
        self.questions.append(question)
        if self.failure is not None:
            raise self.failure
        return list(self.passages)[:limit]


class FakeModel:
    """Answers with the given text, or with JSON built from `answer` and `citations`."""

    def __init__(self, text: str | None = None, *, answer: str = "Microsoft 365 E3 or E5 is required.",
                 citations: list[dict[str, Any]] | None = None, prompt_tokens: int = 120,
                 completion_tokens: int = 40) -> None:
        if text is None:
            if citations is None:
                citations = [{"url": COPILOT_URL, "title": COPILOT_TITLE, "quote": QUOTE}]
            text = json.dumps({"answer": answer, "citations": citations})
        self.text = text
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens
        self.calls: list[tuple[str, str]] = []

    async def complete_json(self, system: str, user: str) -> Completion:
        self.calls.append((system, user))
        return Completion(text=self.text, prompt_tokens=self.prompt_tokens, completion_tokens=self.completion_tokens)


def settings_for_tests(**overrides: Any) -> Settings:
    values: dict[str, Any] = {"ms_agent_api_keys": KEY, "ms_agent_public_url": PUBLIC_URL,
                              "ms_agent_price_db_url": "sqlite://",
                              # The small VM catalog the recorded prices cover, not the real 1,092 sizes.
                              "ms_agent_data_dir": Path(__file__).resolve().parent / "fixtures"}
    values.update(overrides)
    return Settings(_env_file=None, **values)


def make_client(retriever: Any = None, model: Any = None, *, settings: Settings | None = None,
                version: str = "0.1.0-test", prices: Any = None) -> TestClient:
    settings = settings or settings_for_tests()
    services = Services(settings=settings, retriever=retriever, model=model, version=version, prices=prices)
    return TestClient(create_app(settings=settings, services=services))


@pytest.fixture
def retriever() -> FakeRetriever:
    return FakeRetriever()


@pytest.fixture
def model() -> FakeModel:
    return FakeModel()


@pytest.fixture
def client(retriever: FakeRetriever, model: FakeModel) -> TestClient:
    return make_client(retriever, model)


@pytest.fixture
def headers() -> dict[str, str]:
    return {"x-api-key": KEY}


@pytest.fixture
def rest(client: TestClient, headers: dict[str, str]) -> Callable[..., dict[str, Any]]:
    """Call the HTTP+JSON binding and return the envelope."""

    def call(skill: str, request: dict[str, Any] | None = None) -> dict[str, Any]:
        response = client.post("/a2a/microsoft/rest", json={"skill": skill, "request": request or {}}, headers=headers)
        assert response.status_code == 200, response.text
        return response.json()

    return call


def rpc_body(method: str, params: dict[str, Any], identifier: str = "req-1") -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": identifier, "method": method, "params": params}


def send_message(skill: str, request: dict[str, Any] | None = None, *, context_id: str | None = None,
                 as_text: bool = False) -> dict[str, Any]:
    """The `SendMessage` body exactly as MAGIC's authority sends it."""
    data = {"skill": skill, "request": request or {}}
    part = {"text": json.dumps(data)} if as_text else {"data": data}
    message: dict[str, Any] = {"messageId": "m-1", "role": "ROLE_USER", "parts": [part], "metadata": {"skill": skill}}
    if context_id:
        message["contextId"] = context_id
    return rpc_body("SendMessage", {"message": message, "configuration": {"acceptedOutputModes": ["application/json"]}})
