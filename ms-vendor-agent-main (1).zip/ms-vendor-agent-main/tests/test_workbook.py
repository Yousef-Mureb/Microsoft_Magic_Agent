"""The estimate workbook: it opens, has the five sheets, its totals are formulas that evaluate to the
Python estimate's totals, editing a quantity moves the totals, and a reader that does not calculate
still finds the values."""

from __future__ import annotations

import io
from decimal import Decimal

from openpyxl import load_workbook

from ms_agent.estimate_workbook import SHEETS, build_workbook
from ms_agent.pricing.vm_catalog import load
from ms_agent.sizing.workloads import DiskSpec, WorkloadSpec, size_workloads
from tests.pricing_data import FIXTURES, loaded_store
from tests.xlsx_formulas import Evaluator

SIZING = size_workloads(loaded_store(), load("uaenorth", FIXTURES), [
    WorkloadSpec("web servers", 4, 16, "linux", 6),
    WorkloadSpec("SQL servers", 8, 64, "windows", 2, 730, (DiskSpec("premium_ssd", 500, 2),)),
    WorkloadSpec("burst", 2, 4, "linux", 1, 300),
], region="uaenorth", headline="sp_3y", ahb=False, families=["D", "E", "F", "B"])
ESTIMATE = SIZING.estimate
DATA = build_workbook(ESTIMATE, SIZING.workloads, made_by="tests")


def opened(**options):
    return load_workbook(io.BytesIO(DATA), **options)


def test_the_workbook_opens_with_the_five_sheets() -> None:
    assert opened().sheetnames == list(SHEETS) == ["Summary", "Lines", "Assumptions", "Sources", "Disclaimer"]


def test_summary_totals_are_formulas_that_evaluate_to_the_python_totals() -> None:
    workbook = opened()
    summary, evaluate = workbook["Summary"], Evaluator(workbook)
    assert ESTIMATE.models == ["payg", "ri_1y", "ri_3y", "sp_1y", "sp_3y", "ahb"]
    assert [summary.cell(row=4, column=column).value for column in range(2, 8)] == \
        ["PAYG", "1y RI", "3y RI", "1y SP", "3y SP", "AHB"]
    for column, model in enumerate(ESTIMATE.models, start=2):
        monthly, yearly = summary.cell(row=5, column=column), summary.cell(row=6, column=column)
        assert str(monthly.value).startswith("=SUM(Lines!") and str(yearly.value).startswith("=SUM(Lines!")
        assert evaluate.cell("Summary", monthly.coordinate) == ESTIMATE.total(model), model
        assert evaluate.cell("Summary", yearly.coordinate) == ESTIMATE.total(model) * 12, model
    assert summary["B11"].value == "=F5" and evaluate.cell("Summary", "B11") == ESTIMATE.total("sp_3y")


def test_every_line_figure_is_a_formula_over_quantity_and_hours() -> None:
    workbook = opened()
    lines, evaluate = workbook["Lines"], Evaluator(workbook)
    for row, line in enumerate(ESTIMATE.lines, start=2):
        for index, model in enumerate(ESTIMATE.models):
            monthly = lines.cell(row=row, column=8 + index * 4 + 2)
            if line.prices[model] is None:
                assert monthly.value == "n/a"
                continue
            assert str(monthly.value).startswith("=ROUND(")
            assert evaluate.cell("Lines", monthly.coordinate) == line.monthly(model)


def test_editing_a_quantity_or_the_hours_moves_the_totals() -> None:
    workbook = opened()
    lines = workbook["Lines"]
    assert lines["A2"].value == "web servers" and lines["F2"].value == 6
    before = Evaluator(workbook).cell("Summary", "B5")
    lines["F2"] = 12
    after = Evaluator(workbook).cell("Summary", "B5")
    assert after - before == ESTIMATE.lines[0].monthly("payg")
    lines["G2"] = 365
    assert Evaluator(workbook).cell("Summary", "B5") == before  # twice the machines for half the hours


def test_a_reader_that_does_not_calculate_finds_the_values() -> None:
    values = opened(data_only=True)
    for column, model in enumerate(ESTIMATE.models, start=2):
        assert Decimal(repr(values["Summary"].cell(row=5, column=column).value)) == ESTIMATE.total(model)
    assert values["Lines"]["J2"].value == float(ESTIMATE.lines[0].monthly("payg"))


def test_assumptions_sources_and_disclaimer() -> None:
    workbook = opened()
    disclaimer = [row[1] for row in workbook["Disclaimer"].iter_rows(min_row=2, values_only=True)]
    assert disclaimer[0] == f"List prices, not your agreement price; fetched on {ESTIMATE.fetched_at[:10]}."
    assert ESTIMATE.fetched_at.startswith("2026-10-26")
    assert "not CSP, EA or MCA agreement prices" in disclaimer[1]
    assumptions = [row[1] for row in workbook["Assumptions"].iter_rows(min_row=2, values_only=True)]
    assert assumptions == ESTIMATE.assumptions and any("az vm list-skus" in text for text in assumptions)
    sources = list(workbook["Sources"].iter_rows(min_row=2, values_only=True))
    assert len(sources) == len(ESTIMATE.sources()) > 5
    for meter, _product, _type, field, effective, fetched, url in sources:
        assert meter and field and effective.endswith("Z") and fetched and url.startswith("https://prices.azure.com/")
    summary = workbook["Summary"]
    assert summary["A15"].value == "web servers" and summary["B15"].value == "Standard_D4as_v5"
