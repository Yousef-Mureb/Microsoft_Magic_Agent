"""MAGIC's `safe_svg`, copied unchanged from magic3-platform/modules/tools/services/authority/src/vendors.py
(file last changed 20 October 2026, commit ac47ab154; copied 27 October 2026), with its limit MAX_LOGO. The
platform's code is not imported: this repository must test on its own. If MAGIC changes it, copy it again."""

from __future__ import annotations

import xml.etree.ElementTree as ElementTree

MAX_LOGO = 64 * 1024


def safe_svg(data: bytes) -> str | None:
    """The logo as text when it is a plain SVG picture: no script, no event
    handler, no foreign object, nothing fetched from elsewhere. It is shown only
    as an image, which runs nothing either; the check keeps a stored logo plain."""
    if not data or len(data) > MAX_LOGO:
        return None
    try:
        text = data.decode("utf-8")
        root = ElementTree.fromstring(text)
    except (UnicodeDecodeError, ElementTree.ParseError):
        return None
    if "<!DOCTYPE" in text.upper() or "<!ENTITY" in text.upper():
        return None
    if not root.tag.endswith("svg"):
        return None
    for node in root.iter():
        tag = node.tag.rsplit("}", 1)[-1].lower()
        if tag in ("script", "foreignobject", "iframe", "embed", "object", "use", "image", "a"):
            return None
        for attribute, value in node.attrib.items():
            name = attribute.rsplit("}", 1)[-1].lower()
            if name.startswith("on"):
                return None
            if name == "href" and not str(value).startswith("#"):
                return None
            if "url(" in str(value).lower() and "url(#" not in str(value).lower():
                return None
        if tag == "style" and node.text and ("@import" in node.text or "url(" in node.text.replace("url(#", "")):
            return None
    return text
