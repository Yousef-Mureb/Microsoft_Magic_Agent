"""Forum answers are never evidence: no passage, no citation, no caveat from `learn.microsoft.com/answers/`."""

from __future__ import annotations

import json

import pytest

from ms_agent.knowledge.learn_mcp import LearnMcpClient
from ms_agent.knowledge.retriever import LearnRetriever, Passage
from ms_agent.knowledge.sources import allowed_source, forum
from ms_agent.skills.advice_explain import SYSTEM
from tests.conftest import KEY, FakeModel, FakeRetriever, make_client

DOC = Passage(url="https://learn.microsoft.com/en-us/azure/reliability/regions-list", title="Azure regions list",
              text="UAE North has three availability zones.")
FORUM = Passage(url="https://learn.microsoft.com/en-us/answers/questions/123456/uae-north-zones",
                title="Does UAE North have zones? - Microsoft Q&A", text="Someone says UAE North has no zones.")
QUESTION = "How many availability zones does UAE North have?"


@pytest.mark.parametrize(("url", "allowed"), [
    ("https://learn.microsoft.com/en-us/azure/reliability/regions-list", True),
    ("https://learn.microsoft.com/azure/virtual-machines/sizes", True),
    ("https://learn.microsoft.com/en-us/answers/questions/123/x", False),
    ("https://learn.microsoft.com/answers/tags/133/azure-virtual-machines", False),
    ("https://LEARN.microsoft.com/en-us/answers", False),
    ("https://azure.microsoft.com/en-us/pricing/details/backup/", True),
    ("https://www.microsoft.com/licensing/terms/productoffering/MicrosoftAzure/EAEAS", True),
    ("https://www.microsoft.com/en-us/licensing/product-licensing/windows-server", True),
    ("https://www.microsoft.com/en-us/microsoft-365/business", True),
    ("https://news.microsoft.com/source/emea/2026/08/region", True),
    ("https://techcommunity.microsoft.com/blog/x", False),
    ("https://stackoverflow.com/questions/1", False),
])
def test_what_may_be_evidence(url: str, allowed: bool) -> None:
    assert allowed_source(url) is allowed
    assert forum(url) == ("/answers" in url.lower() and "learn.microsoft.com" in url.lower())


def ask(retriever, model) -> dict:
    response = make_client(retriever, model).post("/a2a/microsoft/rest", headers={"x-api-key": KEY},
                                                  json={"skill": "advice_explain", "request": {"question": QUESTION}})
    return response.json()


def test_no_citation_url_contains_answers() -> None:
    model = FakeModel(citations=[{"url": FORUM.url, "title": FORUM.title, "quote": FORUM.text},
                                 {"url": DOC.url, "title": DOC.title, "quote": DOC.text}])
    envelope = ask(FakeRetriever(passages=[FORUM, DOC]), model)
    assert envelope["status"] == "complete"
    citations = [one["url"] for one in envelope["result"]["citations"]]
    assert citations == [DOC.url] and not any("/answers/" in url for url in citations)
    assert envelope["result"]["passage_urls"] == [DOC.url]
    assert FORUM.url not in model.calls[0][1] and FORUM.text not in model.calls[0][1]  # the model never saw it


def test_a_question_with_only_forum_passages_is_refused() -> None:
    model = FakeModel()
    envelope = ask(FakeRetriever(passages=[FORUM]), model)
    assert envelope["refusal"]["code"] == "no_sources" and model.calls == []


def test_the_prompt_prefers_the_newer_of_two_conflicting_sources() -> None:
    assert "prefer the newer one" in SYSTEM and "say in \"answer\" that the sources differ" in SYSTEM


async def test_the_learn_retriever_skips_forum_results_before_counting() -> None:
    results = [{"title": "Q&A", "content": "forum text", "contentUrl": FORUM.url}] * 3 + \
              [{"title": DOC.title, "content": DOC.text, "contentUrl": DOC.url}]

    class Client(LearnMcpClient):
        async def search(self, query: str):
            return results

    passages = await LearnRetriever(Client("https://learn.microsoft.com/api/mcp")).retrieve(QUESTION, limit=1)
    assert [passage.url for passage in passages] == [DOC.url]


@pytest.mark.parametrize(("forum_url", "warning"), [
    ("https://learn.microsoft.com/en-us/answers/tags/azure-virtual-machines", "caveat_dropped"),
    # A forum URL with a number is already refused by the number guard, which replaces the model's words.
    (FORUM.url, "narrative_replaced"),
])
def test_a_design_caveat_citing_a_forum_page_is_not_used(tmp_path, forum_url: str, warning: str) -> None:
    from fastapi.testclient import TestClient

    from ms_agent.files import LocalFileStore
    from ms_agent.main import create_app
    from ms_agent.skills.base import Services
    from tests.conftest import settings_for_tests
    from tests.pricing_data import loaded_store

    text = json.dumps({"summary": "The workers run in UAE North.",
                       "caveats": [f"See {forum_url} for zones.", "Prices are list prices."]})
    settings = settings_for_tests()
    services = Services(settings=settings, prices=loaded_store(), files=LocalFileStore(tmp_path),
                        model=FakeModel(text=text), version="test")
    client = TestClient(create_app(settings=settings, services=services))
    request = {"workloads": [{"name": "workers", "vcpu": 4, "memory_gb": 16, "count": 2}]}
    envelope = client.post("/a2a/microsoft/rest", json={"skill": "design_propose", "request": request},
                           headers={"x-api-key": KEY}).json()
    assert not any("/answers" in caveat for caveat in envelope["result"]["caveats"])
    assert warning in [one["code"] for one in envelope["warnings"]]
