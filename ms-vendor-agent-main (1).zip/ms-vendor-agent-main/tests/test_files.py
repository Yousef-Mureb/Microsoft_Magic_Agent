"""The file store and the `/files/<id>` route: 24 hours, the client key, the agent's own host."""

from __future__ import annotations

import base64
from datetime import UTC, datetime, timedelta
from types import SimpleNamespace
from urllib.parse import parse_qs, urlsplit

from azure.core.exceptions import ResourceNotFoundError
from azure.storage.blob import UserDelegationKey
from fastapi.testclient import TestClient

from ms_agent.files import BlobFileStore, LocalFileStore
from ms_agent.main import create_app
from ms_agent.skills.base import Services
from tests.conftest import KEY, PUBLIC_URL, settings_for_tests

NOW = datetime(2026, 10, 26, 8, 0, tzinfo=UTC)


class Clock:
    def __init__(self) -> None:
        self.now = NOW

    def __call__(self) -> datetime:
        return self.now


def test_a_local_file_is_kept_24_hours_then_gone(tmp_path) -> None:
    clock = Clock()
    store = LocalFileStore(tmp_path, clock=clock)
    stored = store.put("azure estimate/uaenorth.xlsx", "application/x-test", b"PK-data")
    assert stored.name == "azure estimate-uaenorth.xlsx" and stored.expires_at == "2026-10-27T08:00:00Z"
    assert store.get(stored.id) == (b"PK-data", stored)
    assert store.get("../../etc/passwd") is None and store.get("x" * 20) is None
    clock.now = NOW + timedelta(hours=24)
    assert store.get(stored.id) is None
    store.put("next.xlsx", "application/x-test", b"2")
    assert not (tmp_path / f"{stored.id}.bin").exists()  # swept when the next file came


class FakeBlob:
    def __init__(self, blobs: dict, name: str) -> None:
        self.blobs, self.name = blobs, name
        self.url = f"https://account.blob.core.windows.net/estimates/{name}"

    def upload_blob(self, data, overwrite, metadata, content_settings) -> None:
        self.blobs[self.name] = (data, metadata, content_settings)

    def get_blob_properties(self):
        if self.name not in self.blobs:
            raise ResourceNotFoundError("missing")
        _, metadata, content_settings = self.blobs[self.name]
        return SimpleNamespace(metadata=metadata, content_settings=content_settings)

    def download_blob(self):
        return SimpleNamespace(readall=lambda: self.blobs[self.name][0])


class FakeService:
    account_name = "account"

    def __init__(self) -> None:
        self.blobs: dict = {}

    def get_container_client(self, container):
        return SimpleNamespace(get_blob_client=lambda name: FakeBlob(self.blobs, name))

    def get_user_delegation_key(self, key_start_time, key_expiry_time):
        key = UserDelegationKey()
        key.signed_oid, key.signed_tid, key.signed_service, key.signed_version = "oid", "tid", "b", "2025-01-05"
        key.signed_start, key.signed_expiry = "2026-10-26T07:55:00Z", "2026-10-27T08:00:00Z"
        key.value = base64.b64encode(b"k" * 32).decode()
        return key


def test_a_blob_file_has_a_24_hour_read_only_sas_and_expires() -> None:
    clock, service = Clock(), FakeService()
    store = BlobFileStore(service, "estimates", clock=clock)
    stored = store.put("estimate.xlsx", "application/x-test", b"PK-blob")
    data, metadata, content = service.blobs[stored.id]
    assert data == b"PK-blob" and metadata == {"name": "estimate.xlsx", "expires_at": "2026-10-27T08:00:00Z"}
    assert content.content_type == "application/x-test"
    query = parse_qs(urlsplit(stored.direct_url).query)
    assert stored.direct_url.startswith(f"https://account.blob.core.windows.net/estimates/{stored.id}?")
    assert query["sp"] == ["r"] and query["se"] == ["2026-10-27T08:00:00Z"] and query["sig"]
    assert store.get(stored.id)[0] == b"PK-blob"
    assert store.get("y" * 32) is None
    clock.now = NOW + timedelta(days=1, seconds=1)
    assert store.get(stored.id) is None


def test_the_route_serves_a_file_with_the_key_only(tmp_path) -> None:
    settings = settings_for_tests()
    files = LocalFileStore(tmp_path)
    client = TestClient(create_app(settings=settings, services=Services(settings=settings, files=files)))
    stored = files.put("estimate.xlsx", "application/x-test", b"PK-route")
    link = Services(settings=settings).file_link(stored)
    assert link["url"] == f"{PUBLIC_URL}/files/{stored.id}"  # on the card's own host, where MAGIC fetches
    path = urlsplit(link["url"]).path
    assert client.get(path).status_code == 401
    response = client.get(path, headers={"x-api-key": KEY})
    assert response.status_code == 200 and response.content == b"PK-route"
    assert response.headers["content-disposition"] == 'attachment; filename="estimate.xlsx"'
    assert client.get("/files/" + "z" * 32, headers={"x-api-key": KEY}).status_code == 404
