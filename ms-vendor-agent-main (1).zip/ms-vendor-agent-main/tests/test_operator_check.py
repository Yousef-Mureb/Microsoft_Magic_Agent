"""MAGIC's operator check, reproduced from its client (`magic3-platform/modules/tools/services/authority/src/
vendors.py`: `Vendors.check`, `A2aAgent.card`, `A2aAgent.tools`, `A2aAgent.call`, `_a2a_result`, `profile_of`,
`outgoing`), run against this agent in process. The platform's code is not imported: this repository must test
on its own, so the steps are copied as they are written there (read on 26 October 2026).

Also the rule every input schema must follow: MAGIC refuses to send a field whose name contains a forbidden
word, at any depth (`FORBIDDEN_KEY`)."""

from __future__ import annotations

import re
import time
import uuid
from typing import Any
from urllib.parse import urlsplit

from fastapi.testclient import TestClient

from tests.conftest import KEY, PUBLIC_URL, make_client
from tests.magic_safe_svg import MAX_LOGO, safe_svg

# Copied from vendors.py.
CARD_PATH = "/.well-known/agent-card.json"
SCHEMAS_EXTENSION = "urn:magic:vendor-agent:1"
CONTRACT = "vendor-agent/1"
CHECK_SECONDS = 30.0
ACTION = re.compile(r"[a-z][a-z0-9_]{0,63}")
MAX_ACTIONS = 32

FORBIDDEN_KEY = re.compile(r"customer|client|company|organi[sz]ation|contact|e_?mail|phone|price|discount|margin"
                           r"|deal|person|people", re.IGNORECASE)


class Agent:
    """MAGIC's A2A agent, as far as the check uses it, over the test client."""

    def __init__(self, client: TestClient, key: str) -> None:
        self.client, self.key = client, key
        self.endpoint: str | None = None

    def _headers(self) -> dict[str, str]:
        return {"x-api-key": self.key, "authorization": f"Bearer {self.key}", "a2a-version": "1.0"}

    def card(self) -> dict[str, Any]:
        answer = self.client.get(CARD_PATH)  # no key is sent for the card
        assert answer.status_code == 200
        card = answer.json()
        assert isinstance(card.get("skills"), list), "the card has no skills list"
        for interface in card.get("supportedInterfaces") or []:
            if interface.get("protocolBinding") == "JSONRPC" and interface.get("protocolVersion") == "1.0":
                assert urlsplit(interface["url"]).netloc == urlsplit(PUBLIC_URL).netloc, "endpoint on another host"
                self.endpoint = interface["url"]
        assert self.endpoint, "no JSON-RPC 1.0 interface"
        return card

    def tools(self) -> list[dict[str, Any]]:
        card = self.card()
        schemas: dict[str, Any] = {}
        for extension in (card.get("capabilities") or {}).get("extensions") or []:
            if isinstance(extension, dict) and extension.get("uri") == SCHEMAS_EXTENSION:
                schemas = (extension.get("params") or {}).get("schemas") or {}
        return [{"name": skill["id"], "description": skill.get("description") or "",
                 "inputSchema": schemas.get(skill["id"])} for skill in card["skills"]]

    def call(self, skill: str, request: dict[str, Any]) -> tuple[int, dict[str, Any] | None]:
        params = {"message": {"messageId": uuid.uuid4().hex, "role": "ROLE_USER",
                              "parts": [{"data": {"skill": skill, "request": request}}], "metadata": {"skill": skill}},
                  "configuration": {"acceptedOutputModes": ["application/json"]}}
        body = {"jsonrpc": "2.0", "id": uuid.uuid4().hex, "method": "SendMessage", "params": params}
        answer = self.client.post(urlsplit(self.endpoint).path, json=body, headers=self._headers())
        if answer.status_code in (401, 403):
            return answer.status_code, None
        result = answer.json()["result"]
        task = result.get("task") if isinstance(result.get("task"), dict) else result
        envelope = next(artifact["parts"][0]["data"] for artifact in task["artifacts"] if artifact["name"] == "result")
        return answer.status_code, {"structuredContent": envelope}


def operator_check(client: TestClient, key: str) -> dict[str, tuple[bool, str]]:
    """The named checks and their outcome, in MAGIC's words."""
    checks: dict[str, tuple[bool, str]] = {}
    agent = Agent(client, key)
    started = time.monotonic()
    tools = agent.tools()
    checks["Answers at the address"] = (True, "The agent answered.")
    checks["Speaks A2A"] = (True, f"It offers {len(tools)} actions.")
    names = {tool["name"] for tool in tools}
    if "vendor_describe" not in names:
        checks["Describes itself"] = (False, "The agent has no action vendor_describe.")
        return checks
    status, described_call = agent.call("vendor_describe", {})
    if described_call is None:
        checks["Accepts the key"] = (False, f"HTTP {status}")
        return checks
    checks["Accepts the key"] = (True, "The key was accepted.")
    took = time.monotonic() - started
    structured = described_call["structuredContent"]
    described = structured.get("result") if isinstance(structured.get("result"), dict) else structured
    if not described.get("name") and not described.get("vendor"):
        checks["Describes itself"] = (False, "vendor_describe gave no name.")
        return checks
    checks["Describes itself"] = (True, f"{described.get('name')}, data of {described.get('data_date')}.")
    versions = described.get("contract_versions") or [described.get("contract")]
    checks["Speaks vendor-agent/1"] = (CONTRACT in versions, "")
    checks["Designs a solution"] = ("design_propose" in names, "")
    checks["Answers in time"] = (took <= CHECK_SECONDS, f"It described itself in {took:.1f} s.")
    checks["Sends its logo"] = logo_check(agent, described)
    return checks


def fetched_logo(agent: Agent, url: str) -> bytes:
    """`A2aAgent.fetch`: only from the agent's own host, with the key, at most MAX_LOGO."""
    assert urlsplit(url).netloc == urlsplit(agent.endpoint).netloc, "MAGIC refuses a file on another host"
    answer = agent.client.get(urlsplit(url).path, headers=agent._headers() | {"accept": "*/*"})
    assert answer.status_code == 200
    return answer.content[:MAX_LOGO + 1]


def logo_check(agent: Agent, described: dict[str, Any]) -> tuple[bool, str]:
    """MAGIC's optional check, in its order: `logo_svg` inline; else `logo_url` (or `logo`) fetched from the
    agent's own host. Either is kept only when MAGIC's `safe_svg` (copied unchanged) accepts it."""
    logo = None
    given = described.get("logo_svg")
    if isinstance(given, str):
        logo = safe_svg(given.encode("utf-8"))
    elif isinstance(described.get("logo_url") or described.get("logo"), str):
        logo = safe_svg(fetched_logo(agent, described.get("logo_url") or described.get("logo")))
    return (True, "The logo is a plain SVG picture.") if logo else \
        (False, "The agent sends no logo MAGIC can show; its name is shown instead.")


def test_the_operator_check_passes() -> None:
    checks = operator_check(make_client(), KEY)
    required = ["Answers at the address", "Speaks A2A", "Accepts the key", "Describes itself",
                "Speaks vendor-agent/1", "Designs a solution", "Answers in time"]
    assert list(checks) == required + ["Sends its logo"]
    failed = {name: message for name, (ok, message) in checks.items() if not ok}
    assert failed == {}  # every check, the optional logo too


def test_the_logo_is_kept_inline_and_from_its_url_but_not_as_png() -> None:
    """MAGIC keeps a logo only when it is a plain SVG: `logo_svg` inline passes, `logo_url` (/logo.svg) alone
    passes, and the PNG alone, as in 0.2.2, does not."""
    client = make_client()
    agent = Agent(client, KEY)
    agent.card()
    described = agent.call("vendor_describe", {})[1]["structuredContent"]["result"]
    kept = (True, "The logo is a plain SVG picture.")
    assert logo_check(agent, described) == kept
    assert logo_check(agent, {"logo_url": described["logo_url"]}) == kept
    assert logo_check(agent, {"logo_url": PUBLIC_URL + "/logo.png"})[0] is False


def test_a_wrong_key_fails_the_check_as_key_refused() -> None:
    checks = operator_check(make_client(), "not-the-key")
    assert checks["Accepts the key"] == (False, "HTTP 401")


def test_the_profile_magic_shows_fits_its_limits() -> None:
    agent = Agent(make_client(), KEY)
    agent.card()
    _, described_call = agent.call("vendor_describe", {})
    described = described_call["structuredContent"]["result"]
    assert len(described["summary"]) <= 160 and len(described["advisory"]) <= 300
    assert 1 <= len(described["can"]) <= 4 and all(len(line) <= 120 for line in described["can"])


def test_every_action_name_and_schema_is_one_magic_accepts() -> None:
    tools = Agent(make_client(), KEY).tools()
    assert len(tools) <= MAX_ACTIONS
    for tool in tools:
        assert ACTION.fullmatch(tool["name"]), tool["name"]
        assert isinstance(tool["inputSchema"], dict) and tool["inputSchema"].get("type") == "object"


def field_names(schema: Any, at: str = "") -> list[tuple[str, str]]:
    """Every property name in a JSON schema, at any depth: properties, items, anyOf and $defs."""
    found: list[tuple[str, str]] = []
    if isinstance(schema, dict):
        for name, inner in (schema.get("properties") or {}).items():
            found.append((f"{at}.{name}".lstrip("."), name))
            found += field_names(inner, f"{at}.{name}")
        for key in ("items", "additionalProperties"):
            found += field_names(schema.get(key), f"{at}[]")
        for key in ("anyOf", "allOf", "oneOf"):
            for inner in schema.get(key) or []:
                found += field_names(inner, at)
        for name, inner in (schema.get("$defs") or {}).items():
            found += field_names(inner, f"$defs.{name}")
    return found


def test_no_skill_on_the_card_has_a_field_name_magic_refuses_to_send() -> None:
    tools = Agent(make_client(), KEY).tools()
    assert {tool["name"] for tool in tools} >= {"vendor_describe", "design_propose", "advice_explain", "price_get",
                                                "sizing_calc"}
    checked = 0
    for tool in tools:
        for where, name in field_names(tool["inputSchema"]):
            checked += 1
            assert not FORBIDDEN_KEY.search(name), f"{tool['name']}: {where} would be refused by MAGIC"
    assert checked > 30
    assert FORBIDDEN_KEY.search("price_list") and not FORBIDDEN_KEY.search("pricing_models")
