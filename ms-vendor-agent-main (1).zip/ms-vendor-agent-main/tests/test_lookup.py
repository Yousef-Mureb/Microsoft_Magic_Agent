"""Prices by pricing model from the recorded UAE North meters: the right meter and field for each model,
Azure Hybrid Benefit as the Linux meter, the Windows licence as the difference, disks per month, and
provenance on every price."""

from __future__ import annotations

from decimal import Decimal

import pytest

from ms_agent.pricing.lookup import MODELS, PriceNotFound, disk_price, price_for, windows_licence
from ms_agent.pricing.vm_catalog import family_of, generation_of, load
from ms_agent.settings import DATA_DIR
from tests.pricing_data import FETCHED_AT, FIXTURES, item, loaded_store

STORE = loaded_store()
D4 = "Standard_D4s_v5"


def test_pay_as_you_go_reads_the_linux_or_the_windows_consumption_meter() -> None:
    linux = price_for(STORE, D4, "uaenorth", "linux", "payg")
    windows = price_for(STORE, D4, "uaenorth", "windows", "payg")
    assert linux.value == Decimal("0.235") and windows.value == Decimal("0.419")
    assert linux.unit == "1 Hour" and linux.basis == "hourly" and linux.currency == "USD"
    assert linux.sources[0].product_name == "Virtual Machines Dsv5 Series"
    assert windows.sources[0].product_name == "Virtual Machines Dsv5 Series Windows"


def test_spot_low_priority_dev_test_and_cloud_services_meters_are_never_used() -> None:
    for os_name in ("linux", "windows"):
        meter = price_for(STORE, D4, "uaenorth", os_name, "payg").sources[0]
        assert "Spot" not in meter.meter_name and "Low Priority" not in meter.meter_name
        assert meter.type == "Consumption"
    cloud = item(armSkuName="Standard_D4as_v5", productName="Dasv5 Series Cloud Services")
    assert cloud["serviceName"] == "Virtual Machines"
    assert price_for(STORE, "Standard_D4as_v5", "uaenorth", "windows", "payg").sources[0].product_name \
        == "Virtual Machines Dasv5 Series Windows"


def test_azure_hybrid_benefit_equals_the_linux_meter_for_the_same_size_and_region() -> None:
    for size in (D4, "Standard_E8s_v5", "Standard_B4ms"):
        ahb = price_for(STORE, size, "uaenorth", "windows", "ahb")
        linux = price_for(STORE, size, "uaenorth", "linux", "payg")
        assert ahb.value == linux.value and ahb.sources[0].meter_id == linux.sources[0].meter_id
        assert "Azure Hybrid Benefit" in ahb.label and "Linux meter" in ahb.label
    with pytest.raises(PriceNotFound, match="Windows"):
        price_for(STORE, D4, "uaenorth", "linux", "ahb")


def test_reservations_are_read_from_the_reservation_meter_as_a_term_price() -> None:
    one = price_for(STORE, D4, "uaenorth", "linux", "ri_1y")
    three = price_for(STORE, D4, "uaenorth", "linux", "ri_3y")
    assert (one.value, one.unit, one.basis, one.term_months) == (Decimal("1272.0"), "1 Year", "term", 12)
    assert (three.value, three.term_months) == (Decimal("2444.0"), 36)
    assert one.sources[0].type == "Reservation" and one.sources[0].field == "retailPrice"
    with pytest.raises(PriceNotFound, match="1 year reservation"):
        price_for(STORE, "Standard_B4ms", "uaenorth", "linux", "ri_1y")


def test_savings_plans_are_read_from_the_savings_plan_field_of_the_linux_meter() -> None:
    one = price_for(STORE, D4, "uaenorth", "linux", "sp_1y")
    three = price_for(STORE, "Standard_E8s_v5", "uaenorth", "windows", "sp_3y")
    assert one.value == Decimal("0.1770725") and one.basis == "hourly"
    assert one.sources[0].field == "savingsPlan[1 Year].retailPrice"
    assert three.value == Decimal("0.29357") and "Compute only" in three.label
    assert not three.sources[0].product_name.endswith("Windows")


def test_the_windows_licence_is_the_windows_meter_minus_the_linux_meter() -> None:
    licence = windows_licence(STORE, D4, "uaenorth")
    assert licence.value == Decimal("0.184") and licence.basis == "hourly"
    assert [source.product_name for source in licence.sources] == ["Virtual Machines Dsv5 Series Windows",
                                                                  "Virtual Machines Dsv5 Series"]


def test_managed_disks_are_priced_per_month_from_the_disk_meter_not_the_mount() -> None:
    p10 = disk_price(STORE, "premium_ssd", "P10", "uaenorth")
    assert p10.value == Decimal("21.504") and p10.unit == "1/Month" and p10.basis == "monthly"
    assert p10.sources[0].meter_name == "P10 LRS Disk"
    assert disk_price(STORE, "standard_ssd", "E10", "uaenorth").value == Decimal("11.52")
    assert disk_price(STORE, "standard_hdd", "S10", "uaenorth").value == Decimal("7.0656")


def test_every_price_object_has_source_url_effective_start_date_and_fetched_at() -> None:
    prices = [price_for(STORE, D4, "uaenorth", os_name, model)
              for os_name in ("linux", "windows") for model in MODELS if not (model == "ahb" and os_name == "linux")]
    prices += [windows_licence(STORE, D4, "uaenorth"), disk_price(STORE, "premium_ssd", "P30", "uaenorth")]
    for price in prices:
        assert price.source_url.startswith("https://prices.azure.com/api/retail/prices?api-version=")
        assert price.effective_start_date.endswith("Z") and price.fetched_at == FETCHED_AT
        as_dict = price.as_dict()
        assert {"value", "currency", "unit", "source_url", "effective_start_date", "fetched_at"} <= as_dict.keys()
        assert all(source["url"] and source["effective_start_date"] for source in as_dict["sources"])


def test_a_region_or_currency_not_in_the_store_is_not_found() -> None:
    with pytest.raises(PriceNotFound):
        price_for(STORE, D4, "westeurope", "linux", "payg")
    with pytest.raises(PriceNotFound):
        price_for(STORE, D4, "uaenorth", "linux", "payg", currency="AED")


def test_the_real_vm_catalog_of_uae_north_is_read_from_az_output() -> None:
    catalog = load("uaenorth", DATA_DIR)
    assert (catalog.source, catalog.generated, len(catalog.sizes)) == ("az vm list-skus", "2026-10-26", 1092)
    d4 = catalog.get("standard_d4s_v6")
    assert (d4.vcpu, d4.memory_gib, d4.family, d4.generation, d4.premium_disk) == (4, 16.0, "D", 6, True)
    assert d4.quota_family == "StandardDsv6Family"
    assert catalog.newest_generation("D") == 7 and not catalog.current_generation(d4)
    assert catalog.get("Standard_D4ps_v6").arm64 and not d4.arm64
    assert catalog.get("Standard_E8-4s_v5").constrained_cores and not catalog.get("Standard_E8s_v5").constrained_cores
    assert {"B", "D", "E", "F", "M", "L"} <= {size.family for size in catalog.sizes}


def test_the_test_catalog_is_a_small_part_of_the_real_one() -> None:
    small, real = load("uaenorth", FIXTURES), load("uaenorth", DATA_DIR)
    assert len(small.sizes) == 24 and all(real.get(size.name) == size for size in small.sizes)
    assert family_of("Standard_DC4s_v3") == "DC" and family_of("Standard_E8as_v5") == "E"
    assert generation_of("Standard_B4ms") == 1 and generation_of("Standard_E8as_v5") == 5
