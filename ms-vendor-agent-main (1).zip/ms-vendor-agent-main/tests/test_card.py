"""The agent card: valid JSON, both skills with their schemas, the same structure as the Lenovo card."""

from __future__ import annotations

import json
from pathlib import Path

from fastapi.testclient import TestClient

from ms_agent.skills import REGISTRY
from tests.conftest import PUBLIC_URL

LENOVO = json.loads((Path(__file__).resolve().parents[1] / "lenovo-agent-card.json").read_text(encoding="utf-8"))
EXTENSION = "urn:magic:vendor-agent:1"


def schemas_of(card: dict) -> dict:
    extension = next(one for one in card["capabilities"]["extensions"] if one["uri"] == EXTENSION)
    return extension["params"]["schemas"]


def test_the_card_is_served_where_magic_looks_and_where_the_brief_says(client: TestClient) -> None:
    first = client.get("/.well-known/agent-card.json")
    second = client.get("/.well-known/agent.json")
    assert first.status_code == 200 and second.status_code == 200
    assert first.json() == second.json()
    assert "x-api-key" not in first.request.headers


def test_the_card_lists_every_skill_with_its_schema(client: TestClient) -> None:
    card = client.get("/.well-known/agent-card.json").json()
    assert [skill["id"] for skill in card["skills"]] == list(REGISTRY)
    assert {"vendor_describe", "advice_explain", "price_get"} <= set(REGISTRY)
    schemas = schemas_of(card)
    assert set(schemas) == set(REGISTRY)
    advice = schemas["advice_explain"]
    assert advice["required"] == ["question"]
    assert advice["additionalProperties"] is False
    assert advice["properties"]["question"]["minLength"] == 3 and advice["properties"]["question"]["maxLength"] == 1000
    assert set(advice["properties"]) == {"question", "part", "request_id", "role"}
    describe = schemas["vendor_describe"]
    assert set(describe["properties"]) == {"request_id", "role"} and describe["additionalProperties"] is False
    for skill in card["skills"]:
        assert skill["name"] and skill["description"] and skill["tags"] and skill["examples"]
        assert json.loads(skill["examples"][0])["skill"] == skill["id"]


def test_the_jsonrpc_endpoint_is_on_the_cards_own_host(client: TestClient) -> None:
    card = client.get("/.well-known/agent-card.json").json()
    bindings = {one["protocolBinding"]: one for one in card["supportedInterfaces"]}
    assert bindings["JSONRPC"]["url"] == PUBLIC_URL + "/a2a/microsoft"
    assert bindings["JSONRPC"]["protocolVersion"] == "1.0"
    assert bindings["HTTP+JSON"]["url"] == PUBLIC_URL + "/a2a/microsoft/rest"
    assert card["provider"]["url"] == PUBLIC_URL


def test_the_key_scheme_names_x_api_key(client: TestClient) -> None:
    card = client.get("/.well-known/agent-card.json").json()
    scheme = card["securitySchemes"]["apiKey"]["apiKeySecurityScheme"]
    assert scheme["location"] == "header" and scheme["name"] == "x-api-key"
    assert card["securityRequirements"] == [{"schemes": {"apiKey": {}}}]


def test_the_card_has_the_structure_of_the_lenovo_card(client: TestClient) -> None:
    card = client.get("/.well-known/agent-card.json").json()
    assert set(card) == set(LENOVO)
    assert set(card["capabilities"]) == set(LENOVO["capabilities"])
    assert set(card["skills"][0]) == set(LENOVO["skills"][0])
    assert set(card["supportedInterfaces"][0]) == set(LENOVO["supportedInterfaces"][0])
    ours, theirs = card["capabilities"]["extensions"][0], LENOVO["capabilities"]["extensions"][0]
    assert set(ours) == set(theirs) and ours["uri"] == theirs["uri"]
    assert card["defaultInputModes"] == LENOVO["defaultInputModes"]
    assert card["defaultOutputModes"] == LENOVO["defaultOutputModes"]
    assert card["capabilities"]["streaming"] is False


def test_our_advice_explain_schema_matches_lenovos_fields(client: TestClient) -> None:
    ours = schemas_of(client.get("/.well-known/agent-card.json").json())["advice_explain"]
    theirs = schemas_of(LENOVO)["advice_explain"]
    assert set(ours["properties"]) == set(theirs["properties"])
    assert ours["required"] == theirs["required"]
    assert ours["properties"]["request_id"]["anyOf"] == theirs["properties"]["request_id"]["anyOf"]
    assert ours["properties"]["role"]["anyOf"] == theirs["properties"]["role"]["anyOf"]
