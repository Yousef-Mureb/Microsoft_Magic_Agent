"""Sizing and the estimate on the recorded UAE North meters: monthly figures to the cent, the size choice
and its reasons, Windows with and without Azure Hybrid Benefit, disks."""

from __future__ import annotations

from decimal import Decimal

import pytest

from ms_agent.pricing.lookup import disk_price, price_for
from ms_agent.pricing.vm_catalog import VmCatalog, load
from ms_agent.settings import DATA_DIR
from ms_agent.sizing.disks import tier_for
from ms_agent.sizing.estimate import monthly_of
from ms_agent.sizing.vm import NoSize, choose
from ms_agent.sizing.workloads import DiskSpec, WorkloadSpec, size_workloads
from tests.pricing_data import FIXTURES, loaded_store

STORE = loaded_store()
CATALOG = load("uaenorth", FIXTURES)
WEB = WorkloadSpec("web servers", vcpu=4, memory_gb=16, os="linux", count=6)
SQL = WorkloadSpec("SQL servers", vcpu=8, memory_gb=64, os="windows", count=2)


def sized(workloads, *, headline="sp_3y", ahb=True, families=("D", "E", "F", "B")):
    return size_workloads(STORE, CATALOG, list(workloads), region="uaenorth", headline=headline, ahb=ahb,
                          families=list(families))


def test_monthly_is_the_hourly_price_times_hours_times_quantity_to_the_cent() -> None:
    hourly = price_for(STORE, "Standard_D4s_v5", "uaenorth", "linux", "payg")
    assert monthly_of(hourly, Decimal("730"), 6) == Decimal("1029.30")  # 0.235 × 730 × 6
    assert monthly_of(hourly, Decimal("200"), 3) == Decimal("141.00")
    plan = price_for(STORE, "Standard_D4s_v5", "uaenorth", "linux", "sp_3y")
    assert monthly_of(plan, Decimal("730"), 1) == Decimal("88.88")  # 0.1217535 × 730 = 88.880055
    term = price_for(STORE, "Standard_D4s_v5", "uaenorth", "linux", "ri_3y")
    assert monthly_of(term, Decimal("100"), 2) == Decimal("135.78")  # 2444 / 36 × 2, whatever the hours
    disk = disk_price(STORE, "premium_ssd", "P10", "uaenorth")
    assert monthly_of(disk, Decimal("730"), 4) == Decimal("86.02")  # 21.504 × 4 = 86.016


def test_the_verification_workloads_are_sized_and_totalled_by_hand() -> None:
    sizing = sized([WEB, SQL])
    chosen = [one.choice.chosen.size.name for one in sizing.workloads]
    assert chosen == ["Standard_D4as_v5", "Standard_E8as_v5"]
    estimate = sizing.estimate
    assert estimate.models == ["payg", "ri_1y", "ri_3y", "sp_1y", "sp_3y"]  # AHB applied: no separate column
    machines = [line for line in estimate.lines if line.service == "Virtual Machines"]
    assert [line.monthly("sp_3y") for line in machines] == [Decimal("482.85"), Decimal("422.70")]
    disks = [line for line in estimate.lines if line.service == "Managed Disks"]
    assert [(line.sku, line.quantity, line.monthly("sp_3y")) for line in disks] == [
        ("P10 LRS", 6, Decimal("129.02")), ("P15 LRS", 2, Decimal("82.94"))]  # 21.504 × 6, 41.472 × 2: OS disks
    assert all("OS disk" in line.description for line in disks)
    totals = {model: estimate.total(model) for model in estimate.models}
    # Step 2's totals plus the OS disks, 211.96 in every column.
    assert totals == {"payg": Decimal("1958.12"), "ri_1y": Decimal("1289.46"), "ri_3y": Decimal("901.73"),
                      "sp_1y": Decimal("1398.94"), "sp_3y": Decimal("1117.51")}
    assert "Azure Hybrid Benefit" in machines[1].description
    assert any("Azure Hybrid Benefit is applied" in text for text in estimate.assumptions)
    assert any("not CSP, EA or MCA" in text for text in estimate.assumptions)


def test_the_choice_is_the_cheapest_with_three_ranked_alternatives() -> None:
    choice = sized([WEB], families=["D"]).workloads[0].choice
    assert choice.chosen.size.name == "Standard_D4as_v5"
    assert "Cheapest size priced under every pricing model" in choice.chosen.reason
    names = [one.size.name for one in choice.alternatives]
    assert "Standard_D4s_v5" in names and len(names) == 3
    assert all("more than D4as_v5" in one.reason for one in choice.alternatives)
    assert all(one.rank == index for index, one in enumerate(choice.alternatives, start=2))


def test_on_a_tie_the_newest_generation_wins_v7_then_v6_then_v5() -> None:
    real = load("uaenorth", DATA_DIR)
    sizes = tuple(real.get(f"Standard_D4as_v{generation}") for generation in (5, 6, 7))
    catalog = VmCatalog(region="uaenorth", sizes=sizes, source="test", generated="")
    choice = choose(catalog, vcpu=4, memory_gib=16, families=["D"], monthly=lambda size: Decimal("100"),
                    label="Pay-as-you-go", currency="USD")
    assert [choice.chosen.size.generation] + [one.size.generation for one in choice.alternatives] == [7, 6, 5]
    assert "2 other size(s) cost the same; the newest generation is preferred" in choice.chosen.reason
    assert "the same cost as D4as_v7, an older generation" in choice.alternatives[0].reason
    cheaper = choose(catalog, vcpu=4, memory_gib=16, families=["D"], label="Pay-as-you-go", currency="USD",
                     monthly=lambda size: Decimal("90") if size.generation == 5 else Decimal("100"))
    assert cheaper.chosen.size.generation == 5  # the price decides first; the generation only breaks a tie


def test_arm64_and_constrained_core_sizes_are_left_out_with_the_reason() -> None:
    real = load("uaenorth", DATA_DIR)
    sizes = tuple(real.get(name) for name in ("Standard_E8s_v5", "Standard_E8ps_v6", "Standard_E8-4s_v5"))
    catalog = VmCatalog(region="uaenorth", sizes=sizes, source="test", generated="")
    choice = choose(catalog, vcpu=4, memory_gib=32, families=["E"], monthly=lambda size: Decimal("50"),
                    label="Pay-as-you-go", currency="USD")
    assert choice.chosen.size.name == "Standard_E8s_v5" and choice.alternatives == []
    reasons = {one["size"]: one["reason"] for one in choice.excluded}
    assert reasons["Standard_E8ps_v6"].startswith("Arm64")
    assert reasons["Standard_E8-4s_v5"].startswith("constrained cores")


def test_a_size_without_every_price_ranks_after_complete_ones_and_says_why() -> None:
    dev = WorkloadSpec("dev servers", vcpu=4, memory_gb=16, os="linux", count=6, environment="dev_test")
    choice = sized([dev], families=["B", "D"]).workloads[0].choice
    assert choice.chosen.size.family == "D"
    b4 = sized([dev], families=["B"]).workloads[0].choice.chosen
    assert b4.size.name == "Standard_B4ms" and "No 1-year reservation, 3-year reservation price" in b4.reason


def test_b_series_only_for_dev_test() -> None:
    assert sized([WEB], families=["B", "D"]).workloads[0].choice.chosen.size.family == "D"
    with pytest.raises(NoSize, match="only for workloads marked dev_test"):
        sized([WEB], families=["B"])
    excluded_b = [one for one in sized([WEB]).workloads[0].choice.alternatives if one.size.family == "B"]
    assert excluded_b == []


def test_an_os_disk_can_be_given() -> None:
    given = WorkloadSpec("web", 4, 16, "linux", 2, os_disk=DiskSpec("standard_ssd", 64))
    disk = next(line for line in sized([given]).estimate.lines if line.service == "Managed Disks")
    assert (disk.sku, disk.quantity) == ("E6 LRS", 2) and "OS disk" in disk.description


def test_windows_without_ahb_is_compute_plus_licence_with_an_ahb_column() -> None:
    sizing = sized([SQL], ahb=False)
    estimate = sizing.estimate
    assert estimate.models[-1] == "ahb"
    compute, licence, os_disk = estimate.lines
    assert licence.service == "Virtual Machines (Windows Server licence)"
    assert os_disk.monthly("payg") == os_disk.monthly("ahb") == Decimal("82.94")  # P15 × 2
    assert estimate.total("payg") == Decimal("1437.82")  # the Windows meter, 0.928 × 730 × 2, and the OS disks
    assert licence.monthly("sp_3y") == Decimal("537.28")  # 0.368 × 730 × 2, not discounted
    assert compute.monthly("sp_3y") == Decimal("422.70")
    assert estimate.total("ahb") == Decimal("900.54") and licence.monthly("ahb") == Decimal("0.00")
    assert any("compute only" in text for text in estimate.assumptions)


def test_disks_take_the_smallest_tier_that_holds_the_size() -> None:
    assert tier_for("premium_ssd", 500) == ("P20", 512)
    assert tier_for("premium_ssd", 1) == ("P1", 4)
    assert tier_for("standard_hdd", 10) == ("S4", 32)
    with pytest.raises(ValueError):
        tier_for("standard_ssd", 40000)
    sizing = sized([WorkloadSpec("db", 8, 64, "linux", 2, 730, (DiskSpec("premium_ssd", 500, 2),))])
    disk = sizing.estimate.lines[-1]
    assert (disk.sku, disk.quantity, disk.monthly("payg")) == ("P20 LRS", 4, Decimal("319.49"))  # 79.872 × 4
    assert disk.monthly("payg") == disk.monthly("ri_3y")  # disks are billed the same under any commitment


def test_no_size_fits_and_hours_below_always_on() -> None:
    with pytest.raises(NoSize):
        sized([WorkloadSpec("huge", 500, 64)])
    with pytest.raises(NoSize):
        sized([WEB], families=["X"])
    part_time = sized([WorkloadSpec("batch", 4, 16, "linux", 1, 200)], headline="payg").estimate
    assert part_time.lines[0].monthly("payg") == Decimal("42.40")  # 0.212 × 200
    assert part_time.lines[0].monthly("ri_1y") == Decimal("95.50")  # 1146 / 12, paid whatever the hours
