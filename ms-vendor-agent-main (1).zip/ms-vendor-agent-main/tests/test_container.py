"""The Dockerfile, read, since this laptop has no Docker: no BuildKit `--mount` (Azure Container Registry
builds without BuildKit), the data and the job are in the image, and the writable paths are set."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOCKERFILE = (ROOT / "Dockerfile").read_text(encoding="utf-8")
INSTRUCTIONS = [line.strip() for line in DOCKERFILE.splitlines() if line.strip() and not line.strip().startswith("#")]


def test_no_buildkit_mount_or_syntax_line() -> None:
    assert not any("--mount" in line for line in INSTRUCTIONS)
    assert "# syntax=" not in DOCKERFILE


def test_the_image_holds_the_vm_snapshots_and_the_price_job() -> None:
    assert "COPY --chown=agent:agent data/ /app/data/" in INSTRUCTIONS
    assert "COPY --chown=agent:agent jobs/ /app/jobs/" in INSTRUCTIONS
    assert (ROOT / "data" / "vm_sizes_uaenorth.json").is_file() and (ROOT / "jobs" / "refresh_prices.py").is_file()


def test_the_store_and_the_files_go_where_the_agent_user_may_write() -> None:
    assert "MS_AGENT_PRICE_DB_URL=sqlite:////tmp/prices.sqlite3" in DOCKERFILE
    assert "MS_AGENT_FILES_DIR=/tmp/ms-agent-files" in DOCKERFILE
    assert "USER agent" in INSTRUCTIONS


def test_the_image_has_a_font_for_the_png_diagrams() -> None:
    assert any(line.startswith("RUN apt-get update && apt-get install --yes --no-install-recommends fonts-dejavu-core")
               for line in INSTRUCTIONS)
