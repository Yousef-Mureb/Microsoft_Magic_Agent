"""`design_propose`: roles, sizes and totals from the sizing code, the model's words only for the summary and
caveats, guarded against numbers that are not in the design."""

from __future__ import annotations

import json
from typing import Any

from fastapi.testclient import TestClient

from ms_agent.files import LocalFileStore
from ms_agent.llm.client import Completion
from ms_agent.main import create_app
from ms_agent.regions import REGION_PAIRS_URL, REGIONS_LIST_URL
from ms_agent.skills.base import Services
from ms_agent.skills.design_propose import SYSTEM, numbers_in
from tests.conftest import KEY, PUBLIC_URL, FakeModel, send_message, settings_for_tests
from tests.pricing_data import loaded_store

STORE = loaded_store()
WORKLOADS = [{"name": "web servers", "vcpu": 4, "memory_gb": 16, "os": "linux", "count": 6},
             {"name": "SQL servers", "vcpu": 8, "memory_gb": 64, "os": "windows", "count": 2}]
REQUEST = {"workloads": WORKLOADS, "region": "uaenorth", "availability": "zone_redundant",
           "pricing_models": ["sp_3y"], "ahb": True, "request_id": "deal-7"}
SUMMARY = ("Six D4as_v5 web servers and two E8as_v5 SQL servers run in uaenorth across availability zones 1, 2 and "
           "3. The 3-year savings plan total is 1967.17 USD a month at Microsoft list prices.")


class FailingModel:
    async def complete_json(self, system: str, user: str) -> Completion:
        raise RuntimeError("HTTP 400")


def client_with(model: Any, tmp_path) -> TestClient:
    settings = settings_for_tests()
    services = Services(settings=settings, prices=STORE, files=LocalFileStore(tmp_path), model=model, version="test")
    return TestClient(create_app(settings=settings, services=services))


def narrative(summary: str = SUMMARY, caveats: list[str] | None = None) -> FakeModel:
    return FakeModel(text=json.dumps({"summary": summary, "caveats": caveats or ["Prices are list prices."]}))


def ask(client: TestClient, request: dict[str, Any]) -> dict[str, Any]:
    response = client.post("/a2a/microsoft/rest", json={"skill": "design_propose", "request": request},
                           headers={"x-api-key": KEY})
    assert response.status_code == 200
    return response.json()


def test_over_json_rpc_as_magic_sends_it_with_zone_redundancy(tmp_path) -> None:
    model = narrative()
    client = client_with(model, tmp_path)
    response = client.post("/a2a/microsoft", json=send_message("design_propose", REQUEST), headers={"x-api-key": KEY})
    task = response.json()["result"]["task"]
    assert task["status"]["state"] == "TASK_STATE_COMPLETED"
    artifacts = {artifact["name"]: artifact for artifact in task["artifacts"]}
    envelope = artifacts["result"]["parts"][0]["data"]
    assert envelope["status"] == "complete" and envelope["request_id"] == "deal-7"
    result = envelope["result"]
    assert result["summary"] == SUMMARY and result["caveats"][0] == "Prices are list prices."
    assert result["caveats"][1].startswith("Availability zones and region pairs are from Microsoft Learn")
    assert set(result["solution"]) == {"compute", "storage", "network", "security", "monitoring", "backup", "dr"}
    compute = result["solution"]["compute"]
    assert [(one["size"], one["count"], one["zones"]) for one in compute] == [
        ("Standard_D4as_v5", 6, "across availability zones 1, 2 and 3"),
        ("Standard_E8as_v5", 2, "across availability zones 1, 2 and 3")]
    # Internal traffic only: no front door; the baseline is there and priced, so nothing is a gap.
    network = {item["service"] for item in result["solution"]["network"]}
    assert network == {"Azure Virtual Network", "Azure Bastion"}
    assert result["headline"]["monthly"] == 1967.17 and len(result["totals"]) == 5
    assert result["gaps"] == []
    assert result["workbook"]["url"].startswith(PUBLIC_URL + "/files/")
    assert artifacts["files"]["parts"][0]["url"] == result["workbook"]["url"]
    assert envelope["usage"]["prompt_tokens"] == 120
    system, user = model.calls[0]
    assert system == SYSTEM and json.loads(user)["headline"]["monthly"] == 1967.17


def test_a_summary_with_an_invented_number_is_replaced_by_the_plain_one(tmp_path) -> None:
    invented = narrative(SUMMARY.replace("1967.17", "799.00"))
    envelope = ask(client_with(invented, tmp_path), REQUEST)
    result = envelope["result"]
    assert "799" not in result["summary"] and "1967.17 USD a month" in result["summary"]
    warning = next(one for one in envelope["warnings"] if one["code"] == "narrative_replaced")
    assert "799" in warning["message"]
    assert numbers_in("1,746.10 and D4as_v5") == {"1746.1", "4", "5"}


def test_without_a_model_or_when_it_fails_the_design_stands(tmp_path) -> None:
    for model in (None, FailingModel(), FakeModel(text="not json")):
        envelope = ask(client_with(model, tmp_path), REQUEST)
        assert envelope["status"] == "complete"
        assert envelope["result"]["summary"].startswith("Azure infrastructure in uaenorth, spread across availability")
        codes = [one["code"] for one in envelope["warnings"]]
        assert ("narrative_not_written" in codes) or ("narrative_replaced" in codes)
        assert envelope["result"]["caveats"][0].startswith("Microsoft retail list prices")


def test_zone_redundancy_raises_a_single_machine_to_two(tmp_path) -> None:
    request = REQUEST | {"workloads": [WORKLOADS[0] | {"count": 1}]}
    envelope = ask(client_with(None, tmp_path), request)
    assert envelope["result"]["solution"]["compute"][0]["count"] == 2
    assert "count_raised_for_zones" in [one["code"] for one in envelope["warnings"]]
    assert any("raised to two" in caveat for caveat in envelope["result"]["caveats"])
    single = ask(client_with(None, tmp_path), request | {"availability": "single_zone"})
    assert single["result"]["solution"]["compute"][0]["count"] == 1
    assert single["result"]["solution"]["compute"][0]["zones_used"] == []


def test_with_the_region_pair_as_disaster_recovery_region(tmp_path) -> None:
    envelope = ask(client_with(None, tmp_path), REQUEST | {"availability": "with_dr"})
    result = envelope["result"]
    assert result["dr_region"] == "uaecentral" and envelope["status"] == "complete"
    recovery, machines = result["solution"]["dr"][0], result["solution"]["dr"][1:]
    assert recovery["service"] == "Azure Site Recovery" and recovery["priced"] is True
    assert [one["size"] for one in machines] == ["Standard_D4as_v5", "Standard_E8as_v5"]  # UAE Central prices both
    lines = {(line["service"], line["sku"]): line for line in result["lines"]}
    asr = lines[("Azure Site Recovery", "VM replicated to Azure")]
    assert asr["region"] == "uaecentral" and asr["quantity"] == 8
    assert asr["by_model"]["payg"]["monthly"] == 200.0  # 25.0 × 8
    assert asr["by_model"]["payg"]["sources"][0]["url"].endswith("armRegionName%20eq%20%27uaecentral%27%20and%20"
                                                                 "priceType%20eq%20%27Consumption%27")
    replica = lines[("Managed Disks", "P10 LRS replica")]
    assert replica["region"] == "uaecentral" and replica["by_model"]["payg"]["value"] == 27.9552
    restricted = [one for one in result["caveats"] if "UAE Central is a restricted-access" in one]
    assert restricted and REGIONS_LIST_URL in restricted[0]


def test_a_recovery_machine_the_dr_region_does_not_price_is_replaced_by_the_nearest_it_does() -> None:
    from ms_agent.pricing.vm_catalog import load
    from ms_agent.sizing.workloads import WorkloadSpec, size_workloads
    from ms_agent.skills.design_propose import recovery_machines
    from tests.pricing_data import FIXTURES

    store = loaded_store()
    store.replace([], scope={"arm_region_name": "uaecentral", "arm_sku_name": "Standard_D4as_v5"}, currency="USD",
                  fetched_at="x", source_url_of=lambda item: "")
    sizing = size_workloads(store, load("uaenorth", FIXTURES), [WorkloadSpec("API workers", 4, 16, "linux", 2)],
                            region="uaenorth", headline="payg", ahb=False, families=["D"])
    assert sizing.workloads[0].choice.chosen.size.name == "Standard_D4as_v5"
    machines, problem = recovery_machines(store, sizing, "uaecentral", "USD")
    assert problem is None and machines[0]["substituted"] and machines[0]["size"] != "Standard_D4as_v5"
    assert machines[0]["size"].startswith("Standard_D") and "has no list price for D4as_v5" in machines[0]["note"]


def test_the_design_cites_the_region_facts_it_rests_on(tmp_path) -> None:
    model = narrative("The workers run in UAE North with a disaster recovery region.")
    result = ask(client_with(model, tmp_path), REQUEST | {"availability": "with_dr"})["result"]
    facts = result["region_facts"]
    assert facts["regions"]["uaenorth"]["availability_zones"] == 3
    assert facts["regions"]["uaecentral"]["restricted_access"] is True
    assert [source["url"] for source in facts["sources"]] == [REGIONS_LIST_URL, REGION_PAIRS_URL]
    assert result["solution"]["compute"][0]["zones_source"] == REGIONS_LIST_URL
    # The model wrote the caveats, and the code's cited region caveats are still there.
    assert result["caveats"][0] == "Prices are list prices."
    assert any(caveat.startswith("Availability zones and region pairs are from Microsoft Learn") for caveat in
               result["caveats"])


def test_zone_redundancy_in_a_region_without_zones_says_so(tmp_path) -> None:
    from ms_agent.regions import load_regions
    from ms_agent.settings import DATA_DIR
    from ms_agent.skills.design_propose import DesignProposeRequest, _zones, region_caveats

    facts = load_regions(DATA_DIR)
    assert _zones(facts.get("uaecentral"), "zone_redundant") == "one zone: the region has no availability zones"
    request = DesignProposeRequest.model_validate(REQUEST | {"region": "uaecentral"})
    assert any("UAE Central has no availability zones" in one for one in region_caveats(facts, request, None))
