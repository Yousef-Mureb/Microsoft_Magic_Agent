# Azure regions list

Azure provides the most extensive global footprint of any cloud provider and is rapidly opening new regions. This article contains a list of all regions in the Azure public cloud, their paired region status, physical location, geography, and [availability zone](availability-zones-overview) support.

Note

Even when a region provides availability zones, some services might not support them in that region. To learn about region support for availability zone-enabled services, refer to the [Azure service reliability guides](overview-reliability-guidance).

## Azure regions list

# [All](#tab/all)
| Region | Availability zones | Paired region | Physical location | Geography | Programmatic name |
| --- | --- | --- | --- | --- | --- |
| Australia Central | N/A | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Australia Central 2 | Canberra | Australia | australiacentral |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Australia Central 2 | N/A | Australia Central | Canberra | Australia | australiacentral2 |
| Australia East | 3 | Australia Southeast | New South Wales | Australia | australiaeast |
| Australia Southeast | N/A | Australia East | Victoria | Australia | australiasoutheast |
| Austria East | 3 | N/A | Vienna | Austria | austriaeast |
| Belgium Central | 3 | N/A | Brussels | Belgium | belgiumcentral |
| Brazil South | 3 | South Central US | Sao Paulo State | Brazil | brazilsouth |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Brazil Southeast | N/A | Brazil South | Rio | Brazil | brazilsoutheast |
| Canada Central | 3 | Canada East | Toronto | Canada | canadacentral |
| Canada East | N/A | Canada Central | Quebec | Canada | canadaeast |
| Central India | 3 | South India | Pune | India | centralindia |
| Central US | 3 | East US 2 | Iowa | United States | centralus |
| Chile Central | 3 | N/A | Santiago | Chile | chilecentral |
| Denmark East | 3 | N/A | Copenhagen | Denmark | denmarkeast |
| East Asia | 3 | Southeast Asia | Hong Kong | Asia Pacific | eastasia |
| East US | 3 | West US | Virginia | United States | eastus |
| East US 2 | 4 ![Icon that shows that availability zone support in this region is coming soon.](media/icon-region-coming-soon.svg) | Central US | Virginia | United States | eastus2 |
| France Central | 3 | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) France South | Paris | France | francecentral |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) France South | N/A | France Central | Marseille | France | francesouth |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Germany North | N/A | Germany West Central | Berlin | Germany | germanynorth |
| Germany West Central | 3 | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Germany North | Frankfurt | Germany | germanywestcentral |
| India South Central | 3 | Central India | Hyderabad | India | indiasouthcentral |
| Indonesia Central | 3 | N/A | Jakarta | Indonesia | indonesiacentral |
| Israel Central | 3 | N/A | Israel | Israel | israelcentral |
| Italy North | 3 | N/A | Milan | Italy | italynorth |
| Japan East | 3 | Japan West | Tokyo, Saitama | Japan | japaneast |
| Japan West | 3 | Japan East | Osaka | Japan | japanwest |
| Korea Central | 3 | Korea South | Seoul | Korea | koreacentral |
| Korea South | N/A | Korea Central | Busan | Korea | koreasouth |
| Malaysia West | 3 | N/A | Kuala Lumpur | Malaysia | malaysiawest |
| Mexico Central | 3 | N/A | Querétaro State | Mexico | mexicocentral |
| New Zealand North | 3 | N/A | Auckland | New Zealand | newzealandnorth |
| North Central US | 3 ![Icon that shows that availability zone support in this region is coming soon.](media/icon-region-coming-soon.svg) | South Central US | Illinois | United States | northcentralus |
| North Europe | 3 | West Europe | Ireland | Europe | northeurope |
| Norway East | 3 | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Norway West | Norway | Norway | norwayeast |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Norway West | N/A | Norway East | Norway | Norway | norwaywest |
| Poland Central | 3 | N/A | Warsaw | Poland | polandcentral |
| Qatar Central | 3 | N/A | Doha | Qatar | qatarcentral |
| South Africa North | 3 | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) South Africa West | Johannesburg | South Africa | southafricanorth |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) South Africa West | N/A | South Africa North | Cape Town | South Africa | southafricawest |
| South Central US | 3 | North Central US | Texas | United States | southcentralus |
| South India | N/A | Central India | Chennai | India | southindia |
| Southeast Asia | 3 | East Asia | Singapore | Asia Pacific | southeastasia |
| Spain Central | 3 | N/A | Madrid | Spain | spaincentral |
| Sweden Central | 3 | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Sweden South | Gävle | Sweden | swedencentral |
| Switzerland North | 3 | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Switzerland West | Zurich | Switzerland | switzerlandnorth |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Switzerland West | N/A | Switzerland North | Geneva | Switzerland | switzerlandwest |
| ![Icon that shows that this region is coming soon.](media/icon-region-coming-soon.svg) Taiwan North | 3 | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Taiwan Northwest | Taipei | Taiwan | taiwannorth |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) UAE Central | N/A | UAE North | Abu Dhabi | UAE | uaecentral |
| UAE North | 3 | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) UAE Central | Dubai | UAE | uaenorth |
| UK South | 3 | UK West | London | United Kingdom | uksouth |
| UK West | N/A | UK South | Cardiff | United Kingdom | ukwest |
| West Central US | N/A | West US 2 | Wyoming | United States | westcentralus |
| West Europe | 3 | North Europe | Netherlands | Europe | westeurope |
| West India | N/A | South India | Mumbai | India | westindia |
| West US | N/A | East US | California | United States | westus |
| West US 2 | 3 | West Central US | Washington | United States | westus2 |
| West US 3 | 3 | East US | Phoenix | United States | westus3 |

**Legend:**

![Icon that shows that this region is coming soon.](media/icon-region-coming-soon.svg) In the **Region** column, this icon indicates that the region is in preview. To learn more about availability zones and available services support in this region, contact your Microsoft sales or customer representative.

![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area. To request access to a restricted region for your Azure subscription, see [Azure region access request process](/en-us/troubleshoot/azure/general/region-access-request-process#reserved-access-regions).

![Icon that shows that availability zone support in this region is coming soon.](media/icon-region-coming-soon.svg) In the **Availability zone support** column, this icon indicates that one or more availability zones are in preview in this region.

# [Americas](#tab/americas)
| Region | Availability zones | Paired region | Physical location | Geography | Programmatic name |
| --- | --- | --- | --- | --- | --- |
| Brazil South | 3 | South Central US | Sao Paulo State | Brazil | brazilsouth |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Brazil Southeast | N/A | Brazil South | Rio | Brazil | brazilsoutheast |
| Canada Central | 3 | Canada East | Toronto | Canada | canadacentral |
| Canada East | N/A | Canada Central | Quebec | Canada | canadaeast |
| Central US | 3 | East US 2 | Iowa | United States | centralus |
| Chile Central | 3 | N/A | Santiago | Chile | chilecentral |
| East US | 3 | West US | Virginia | United States | eastus |
| East US 2 | 4 ![Icon that shows that availability zone support in this region is coming soon.](media/icon-region-coming-soon.svg) | Central US | Virginia | United States | eastus2 |
| Mexico Central | 3 | N/A | Querétaro State | Mexico | mexicocentral |
| North Central US | 3 ![Icon that shows that availability zone support in this region is coming soon.](media/icon-region-coming-soon.svg) | South Central US | Illinois | United States | northcentralus |
| South Central US | 3 | North Central US | Texas | United States | southcentralus |
| West Central US | N/A | West US 2 | Wyoming | United States | westcentralus |
| West US | N/A | East US | California | United States | westus |
| West US 2 | 3 | West Central US | Washington | United States | westus2 |
| West US 3 | 3 | East US | Phoenix | United States | westus3 |

**Legend:**

![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area. To request access to a restricted region for your Azure subscription, see [Azure region access request process](/en-us/troubleshoot/azure/general/region-access-request-process#reserved-access-regions).

![Icon that shows that availability zone support in this region is coming soon.](media/icon-region-coming-soon.svg) In the **Availability zone support** column, this icon indicates that one or more availability zones are in preview in this region.

# [Europe](#tab/europe)
| Region | Availability zones | Paired region | Physical location | Geography | Programmatic name |
| --- | --- | --- | --- | --- | --- |
| Austria East | 3 | N/A | Vienna | Austria | austriaeast |
| Belgium Central | 3 | N/A | Brussels | Belgium | belgiumcentral |
| Denmark East | 3 | N/A | Copenhagen | Denmark | denmarkeast |
| France Central | 3 | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) France South | Paris | France | francecentral |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) France South | N/A | France Central | Marseille | France | francesouth |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Germany North | N/A | Germany West Central | Berlin | Germany | germanynorth |
| Germany West Central | 3 | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Germany North | Frankfurt | Germany | germanywestcentral |
| Italy North | 3 | N/A | Milan | Italy | italynorth |
| North Europe | 3 | West Europe | Ireland | Europe | northeurope |
| Norway East | 3 | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Norway West | Norway | Norway | norwayeast |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Norway West | N/A | Norway East | Norway | Norway | norwaywest |
| Poland Central | 3 | N/A | Warsaw | Poland | polandcentral |
| Spain Central | 3 | N/A | Madrid | Spain | spaincentral |
| Sweden Central | 3 | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Sweden South | Gävle | Sweden | swedencentral |
| Switzerland North | 3 | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Switzerland West | Zurich | Switzerland | switzerlandnorth |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Switzerland West | N/A | Switzerland North | Geneva | Switzerland | switzerlandwest |
| UK South | 3 | UK West | London | United Kingdom | uksouth |
| UK West | N/A | UK South | Cardiff | United Kingdom | ukwest |
| West Europe | 3 | North Europe | Netherlands | Europe | westeurope |

**Legend:**

![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area. To request access to a restricted region for your Azure subscription, see [Azure region access request process](/en-us/troubleshoot/azure/general/region-access-request-process#reserved-access-regions).

# [Middle East](#tab/middle-east)
| Region | Availability zones | Paired region | Physical location | Geography | Programmatic name |
| --- | --- | --- | --- | --- | --- |
| Israel Central | 3 | N/A | Israel | Israel | israelcentral |
| Qatar Central | 3 | N/A | Doha | Qatar | qatarcentral |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) UAE Central | N/A | UAE North | Abu Dhabi | UAE | uaecentral |
| UAE North | 3 | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) UAE Central | Dubai | UAE | uaenorth |

**Legend:**

![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area. To request access to a restricted region for your Azure subscription, see [Azure region access request process](/en-us/troubleshoot/azure/general/region-access-request-process#reserved-access-regions).

# [Africa](#tab/africa)
| Region | Availability zones | Paired region | Physical location | Geography | Programmatic name |
| --- | --- | --- | --- | --- | --- |
| South Africa North | 3 | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) South Africa West | Johannesburg | South Africa | southafricanorth |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) South Africa West | N/A | South Africa North | Cape Town | South Africa | southafricawest |

**Legend:**

![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area. To request access to a restricted region for your Azure subscription, see [Azure region access request process](/en-us/troubleshoot/azure/general/region-access-request-process#reserved-access-regions).

# [Asia Pacific](#tab/asia-pacific)
| Region | Availability zones | Paired region | Physical location | Geography | Programmatic name |
| --- | --- | --- | --- | --- | --- |
| Australia Central | N/A | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Australia Central 2 | Canberra | Australia | australiacentral |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Australia Central 2 | N/A | Australia Central | Canberra | Australia | australiacentral2 |
| Australia East | 3 | Australia Southeast | New South Wales | Australia | australiaeast |
| Australia Southeast | N/A | Australia East | Victoria | Australia | australiasoutheast |
| Central India | 3 | South India | Pune | India | centralindia |
| East Asia | 3 | Southeast Asia | Hong Kong | Asia Pacific | eastasia |
| India South Central | 3 | Central India | Hyderabad | India | indiasouthcentral |
| Indonesia Central | 3 | N/A | Jakarta | Indonesia | indonesiacentral |
| Japan East | 3 | Japan West | Tokyo, Saitama | Japan | japaneast |
| Japan West | 3 | Japan East | Osaka | Japan | japanwest |
| Korea Central | 3 | Korea South | Seoul | Korea | koreacentral |
| Korea South | N/A | Korea Central | Busan | Korea | koreasouth |
| Malaysia West | 3 | N/A | Kuala Lumpur | Malaysia | malaysiawest |
| New Zealand North | 3 | N/A | Auckland | New Zealand | newzealandnorth |
| South India | N/A | Central India | Chennai | India | southindia |
| Southeast Asia | 3 | East Asia | Singapore | Asia Pacific | southeastasia |
| ![Icon that shows that this region is coming soon.](media/icon-region-coming-soon.svg) Taiwan North | 3 | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Taiwan Northwest | Taipei | Taiwan | taiwannorth |
| West India | N/A | South India | Mumbai | India | westindia |

**Legend:**

![Icon that shows that this region is coming soon.](media/icon-region-coming-soon.svg) In the **Region** column, this icon indicates that the region is in preview. To learn more about availability zones and available services support in this region, contact your Microsoft sales or customer representative.

![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area. To request access to a restricted region for your Azure subscription, see [Azure region access request process](/en-us/troubleshoot/azure/general/region-access-request-process#reserved-access-regions).

---

### Azure programmatic region names

To retrieve a list of regions, including the names that can be used for programming and scripting, you can use the following methods:

- [Azure CLI - az account list-locations](/en-us/cli/azure/account#az-account-list-locations)
- [Azure PowerShell - Get-AzLocation](/en-us/powershell/module/az.resources/get-azlocation)
- [Azure Resource Manager REST API](/en-us/rest/api/resources/subscriptions/list-locations)

## Sovereign cloud regions

For information about regions in Azure's sovereign clouds, see the following resources:

- [Azure for US Government regions](/en-us/azure/azure-government/documentation-government-welcome#list-of-regions)
- [Azure in China regions](/en-us/azure/china/overview-regions)