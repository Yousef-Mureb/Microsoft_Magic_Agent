# Azure region pairs and nonpaired regions

This article describes how Azure uses region pairs and nonpaired regions.

Azure regions are independent of each other. However, Microsoft associates some Azure regions with another region, where both regions are usually in the same geography. Together, the regions form a *region pair*. A small number of Azure services use these region pairs to support geo-replication and geo-redundancy. The pairs also support some aspects of disaster recovery in the unlikely event that a region experiences a catastrophic and unrecoverable failure.

However, many regions aren't paired, and instead use availability zones as their primary means of redundancy. In addition, many Azure services support geo-redundancy whether regions are paired or not.

You can design a highly resilient solution whether you use paired regions, nonpaired regions, or a combination.

## Paired regions

Some Azure services use paired regions to build their multiregion geo-replication and geo-redundancy strategy. For example, [Azure geo-redundant storage](/en-us/azure/storage/common/storage-redundancy#geo-redundant-storage) (GRS) can automatically replicate data to a paired region.

If you're in a region that's paired, using its pair as a secondary region provides several benefits:

- **Region recovery sequence**. In the unlikely event of a geography-wide outage, one region in every region pair is prioritized for recovery. Components that are deployed across paired regions use one of the regions as the prioritized region for recovery.
- **Sequential updating**. Azure strives to stagger any planned system updates across region pairs. This approach minimizes the impact of bugs or logical failures in the rare event of a faulty update, and it prevents downtime to solutions that are designed to use paired regions together for resiliency.
- **Data residency**. To meet data residency requirements, almost all regions reside within the same geography as their pair. To learn about the exceptions, see the [list of Azure regions](regions-list).

Important

Deploying resources to a region in a pair doesn't automatically make them more resilient, nor does it provide automatic high availability, disaster recovery capabilities, or failover. Develop your own high availability and disaster recovery plans, regardless of whether you use paired regions or not.

Even if you configure service features to use region pairs, don't rely on Microsoft-managed failover between those pairs as your primary disaster recovery approach. For example, Microsoft-managed failover of GRS-enabled storage accounts is only performed in catastrophic situations and after repeated failed recovery attempts.

You're not limited to using services within a single region or within your region's pair. Although an Azure service might rely upon a specific regional pair for some of its reliability capabilities, you can host your services in any region that satisfies your business needs. For example, an Azure solution can use Azure Storage in the Canada Central region with GRS storage to replicate data to the paired region, Canada East, while using Azure compute resources located in East US, and Azure OpenAI resources located in West US.

To see a list of regions that includes all region pairs, see [List of Azure regions](regions-list).

### Asymmetrically paired regions

Most region pairs are *symmetrical*, which means that each region is bidirectionally paired with another region. For example, West US is paired with East US, and East US is paired with West US.

*Asymmetrical region pairs* involve regions that aren't bidirectionally paired. The following list includes public asymmetrical region pairs:

- Brazil South is paired with South Central US, which is outside of the Brazil geography. South Central US isn't paired with Brazil South.
- West India is paired with South India, but South India is paired with Central India.
- India South Central is paired with Central India, but Central India is paired with South India.
- West US 3 is paired in one direction with East US. East US is bidirectionally paired with West US.

For a list of regions that includes all asymmetrical region pairs, see [Azure region pairs](regions-list).

## Azure region pairs list

The following tables list Azure regions and their corresponding paired region, organized by geography. Regions without a pair show **N/A** in the paired region column. For a more comprehensive set of information about each region, see [List of Azure regions](regions-list).

# [All](#tab/all)
| Region | Paired region |
| --- | --- |
| Australia Central | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Australia Central 2 |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Australia Central 2 | Australia Central |
| Australia East | Australia Southeast |
| Australia Southeast | Australia East |
| Austria East | N/A |
| Belgium Central | N/A |
| Brazil South | South Central US |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Brazil Southeast | Brazil South |
| Canada Central | Canada East |
| Canada East | Canada Central |
| Central India | South India |
| Central US | East US 2 |
| Chile Central | N/A |
| Denmark East | N/A |
| East Asia | Southeast Asia |
| East US | West US |
| East US 2 | Central US |
| France Central | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) France South |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) France South | France Central |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Germany North | Germany West Central |
| Germany West Central | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Germany North |
| India South Central | Central India |
| Indonesia Central | N/A |
| Israel Central | N/A |
| Italy North | N/A |
| Japan East | Japan West |
| Japan West | Japan East |
| Korea Central | Korea South |
| Korea South | Korea Central |
| Malaysia West | N/A |
| Mexico Central | N/A |
| New Zealand North | N/A |
| North Central US | South Central US |
| North Europe | West Europe |
| Norway East | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Norway West |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Norway West | Norway East |
| Poland Central | N/A |
| Qatar Central | N/A |
| South Africa North | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) South Africa West |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) South Africa West | South Africa North |
| South Central US | North Central US |
| South India | Central India |
| Southeast Asia | East Asia |
| Spain Central | N/A |
| Sweden Central | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Sweden South |
| Switzerland North | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Switzerland West |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Switzerland West | Switzerland North |
| ![Icon that shows that this region is coming soon.](media/icon-region-coming-soon.svg) Taiwan North | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Taiwan Northwest |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) UAE Central | UAE North |
| UAE North | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) UAE Central |
| UK South | UK West |
| UK West | UK South |
| West Central US | West US 2 |
| West Europe | North Europe |
| West India | South India |
| West US | East US |
| West US 2 | West Central US |
| West US 3 | East US |

**Legend:**

![Icon that shows that this region is coming soon.](media/icon-region-coming-soon.svg) In the **Region** column, this icon indicates that the region is in preview. To learn more about availability zones and available services support in this region, contact your Microsoft sales or customer representative.

![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area. To request access to a restricted region for your Azure subscription, see [Azure region access request process](/en-us/troubleshoot/azure/general/region-access-request-process#reserved-access-regions).

# [Americas](#tab/americas)
| Region | Paired region |
| --- | --- |
| Brazil South | South Central US |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Brazil Southeast | Brazil South |
| Canada Central | Canada East |
| Canada East | Canada Central |
| Central US | East US 2 |
| Chile Central | N/A |
| East US | West US |
| East US 2 | Central US |
| Mexico Central | N/A |
| North Central US | South Central US |
| South Central US | North Central US |
| West Central US | West US 2 |
| West US | East US |
| West US 2 | West Central US |
| West US 3 | East US |

**Legend:**

![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area. To request access to a restricted region for your Azure subscription, see [Azure region access request process](/en-us/troubleshoot/azure/general/region-access-request-process#reserved-access-regions).

# [Europe](#tab/europe)
| Region | Paired region |
| --- | --- |
| Austria East | N/A |
| Belgium Central | N/A |
| Denmark East | N/A |
| France Central | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) France South |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) France South | France Central |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Germany North | Germany West Central |
| Germany West Central | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Germany North |
| Italy North | N/A |
| North Europe | West Europe |
| Norway East | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Norway West |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Norway West | Norway East |
| Poland Central | N/A |
| Spain Central | N/A |
| Sweden Central | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Sweden South |
| Switzerland North | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Switzerland West |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Switzerland West | Switzerland North |
| UK South | UK West |
| UK West | UK South |
| West Europe | North Europe |

**Legend:**

![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area. To request access to a restricted region for your Azure subscription, see [Azure region access request process](/en-us/troubleshoot/azure/general/region-access-request-process#reserved-access-regions).

# [Middle East](#tab/middle-east)
| Region | Paired region |
| --- | --- |
| Israel Central | N/A |
| Qatar Central | N/A |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) UAE Central | UAE North |
| UAE North | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) UAE Central |

**Legend:**

![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area. To request access to a restricted region for your Azure subscription, see [Azure region access request process](/en-us/troubleshoot/azure/general/region-access-request-process#reserved-access-regions).

# [Africa](#tab/africa)
| Region | Paired region |
| --- | --- |
| South Africa North | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) South Africa West |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) South Africa West | South Africa North |

**Legend:**

![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area. To request access to a restricted region for your Azure subscription, see [Azure region access request process](/en-us/troubleshoot/azure/general/region-access-request-process#reserved-access-regions).

# [Asia Pacific](#tab/asia-pacific)
| Region | Paired region |
| --- | --- |
| Australia Central | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Australia Central 2 |
| ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Australia Central 2 | Australia Central |
| Australia East | Australia Southeast |
| Australia Southeast | Australia East |
| Central India | South India |
| East Asia | Southeast Asia |
| India South Central | Central India |
| Indonesia Central | N/A |
| Japan East | Japan West |
| Japan West | Japan East |
| Korea Central | Korea South |
| Korea South | Korea Central |
| Malaysia West | N/A |
| New Zealand North | N/A |
| South India | Central India |
| Southeast Asia | East Asia |
| ![Icon that shows that this region is coming soon.](media/icon-region-coming-soon.svg) Taiwan North | ![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Taiwan Northwest |
| West India | South India |

**Legend:**

![Icon that shows that this region is coming soon.](media/icon-region-coming-soon.svg) In the **Region** column, this icon indicates that the region is in preview. To learn more about availability zones and available services support in this region, contact your Microsoft sales or customer representative.

![Icon that shows that access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area.](media/icon-region-restricted.svg) Access to this region is restricted to support specific customer scenarios, such as disaster recovery within a specific geographic area. To request access to a restricted region for your Azure subscription, see [Azure region access request process](/en-us/troubleshoot/azure/general/region-access-request-process#reserved-access-regions).

---

## Nonpaired regions

Azure continues to expand globally. Many of the newer regions provide multiple [availability zones](availability-zones-overview) for higher resiliency and don't have a region pair.

Many Azure services support geo-replication and geo-redundancy between any arbitrary set of regions and don't rely on region pairs. Others might require that you design and implement your own multiregion approaches. For a list of service multiregion capabilities, including those that work between nonpaired regions, see [Azure services that support multiple regions](regions-multiregion-support). For detailed information about each service, see its [reliability guide](overview-reliability-guidance).

| Americas | Europe | Middle East | Asia Pacific |
| --- | --- | --- | --- |
| Chile Central | Austria East | Israel Central | Indonesia Central |
| Mexico Central | Belgium Central | Qatar Central | Malaysia West |
|  | Denmark East |  | New Zealand North |
|  | Italy North |  |  |
|  | Poland Central |  |  |
|  | Spain Central |  |  |