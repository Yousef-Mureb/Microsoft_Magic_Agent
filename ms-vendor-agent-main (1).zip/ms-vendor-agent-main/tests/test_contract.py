"""The envelope and the A2A JSON-RPC binding: validation, echo of `request_id` and `role`, errors, the key."""

from __future__ import annotations

import json
import logging

from fastapi.testclient import TestClient

from tests.conftest import KEY, FakeModel, FakeRetriever, make_client, rpc_body, send_message, settings_for_tests


def test_healthz_is_open(client: TestClient) -> None:
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_without_the_key_both_bindings_answer_401(client: TestClient) -> None:
    for path in ("/a2a/microsoft", "/a2a/microsoft/rest"):
        response = client.post(path, json={"skill": "vendor_describe", "request": {}})
        assert response.status_code == 401
        assert response.json()["error"] == "unauthorized"
        wrong = client.post(path, json={"skill": "vendor_describe", "request": {}}, headers={"x-api-key": "nope"})
        assert wrong.status_code == 401


def test_the_key_is_accepted_as_bearer_too(client: TestClient) -> None:
    response = client.post("/a2a/microsoft/rest", json={"skill": "vendor_describe", "request": {}},
                           headers={"authorization": f"Bearer {KEY}"})
    assert response.status_code == 200
    assert response.json()["status"] == "complete"


def test_an_agent_without_keys_does_not_start() -> None:
    try:
        make_client(settings=settings_for_tests(ms_agent_api_keys=""))
    except ValueError as failure:
        assert "MS_AGENT_API_KEYS" in str(failure)
    else:
        raise AssertionError("An agent without a client key must refuse to start.")


def test_the_envelope_has_the_contract_shape(rest) -> None:
    envelope = rest("vendor_describe", {})
    assert envelope["contract"] == "vendor-agent/1"
    assert envelope["status"] == "complete"
    assert envelope["warnings"] == [] and envelope["files"] == []
    assert envelope["refusal"] is None
    assert isinstance(envelope["result"], dict)


def test_request_id_and_role_are_echoed(rest) -> None:
    envelope = rest("vendor_describe", {"request_id": "abc123", "role": "architect"})
    assert envelope["request_id"] == "abc123" and envelope["role"] == "architect"
    refused = rest("no_such_skill", {"request_id": "abc123", "role": "architect"})
    assert refused["status"] == "failed"
    assert refused["request_id"] == "abc123" and refused["role"] == "architect"


def test_without_them_they_are_null(rest) -> None:
    envelope = rest("vendor_describe", {})
    assert envelope["request_id"] is None and envelope["role"] is None


def test_an_unknown_skill_is_refused(rest) -> None:
    envelope = rest("catalog_search", {})
    assert envelope["status"] == "failed"
    assert envelope["refusal"]["code"] == "unknown_skill"
    assert "advice_explain" in envelope["refusal"]["message"]
    assert envelope["result"] is None


def test_a_bad_request_is_refused_with_the_field_named(rest) -> None:
    envelope = rest("advice_explain", {"request_id": "r-1"})
    assert envelope["status"] == "failed"
    assert envelope["refusal"]["code"] == "bad_request"
    assert "question" in envelope["refusal"]["message"]
    assert envelope["request_id"] == "r-1"


def test_an_unknown_field_is_refused(rest) -> None:
    envelope = rest("vendor_describe", {"customer": "Acme"})
    assert envelope["refusal"]["code"] == "bad_request"
    assert "customer" in envelope["refusal"]["message"]


def test_a_malformed_envelope_is_refused(client: TestClient, headers: dict[str, str]) -> None:
    response = client.post("/a2a/microsoft/rest", json={"request": {}}, headers=headers)
    assert response.status_code == 200
    assert response.json()["refusal"]["code"] == "bad_request"
    response = client.post("/a2a/microsoft/rest", content=b"not json", headers=headers)
    assert response.status_code == 400
    assert response.json()["refusal"]["code"] == "bad_request"


def test_send_message_returns_a_completed_task_with_the_envelope(client: TestClient, headers: dict[str, str]) -> None:
    response = client.post("/a2a/microsoft", json=send_message("vendor_describe", {"request_id": "r-7"},
                                                               context_id="ctx-1"), headers=headers)
    assert response.status_code == 200
    body = response.json()
    assert body["jsonrpc"] == "2.0" and body["id"] == "req-1" and "error" not in body
    task = body["result"]["task"]
    assert task["contextId"] == "ctx-1"
    assert task["status"]["state"] == "TASK_STATE_COMPLETED"
    assert task["status"]["message"]["parts"][0]["text"]
    artifact = next(one for one in task["artifacts"] if one["name"] == "result")
    envelope = artifact["parts"][0]["data"]
    assert envelope["contract"] == "vendor-agent/1" and envelope["status"] == "complete"
    assert envelope["request_id"] == "r-7"
    assert envelope["result"]["name"]


def test_a_text_part_with_the_json_is_read_too(client: TestClient, headers: dict[str, str]) -> None:
    response = client.post("/a2a/microsoft", json=send_message("vendor_describe", as_text=True), headers=headers)
    assert response.json()["result"]["task"]["status"]["state"] == "TASK_STATE_COMPLETED"


def test_get_task_returns_the_same_task(client: TestClient, headers: dict[str, str]) -> None:
    sent = client.post("/a2a/microsoft", json=send_message("vendor_describe"), headers=headers).json()
    task = sent["result"]["task"]
    held = client.post("/a2a/microsoft", json=rpc_body("GetTask", {"id": task["id"]}, "req-2"), headers=headers).json()
    assert held["id"] == "req-2"
    assert held["result"]["task"] == task
    cancelled = client.post("/a2a/microsoft", json=rpc_body("CancelTask", {"id": task["id"]}), headers=headers).json()
    assert cancelled["error"]["code"] == -32002


def test_a_refused_skill_is_a_failed_task_with_the_refusal(client: TestClient, headers: dict[str, str]) -> None:
    response = client.post("/a2a/microsoft", json=send_message("no_such_skill"), headers=headers)
    task = response.json()["result"]["task"]
    assert task["status"]["state"] == "TASK_STATE_FAILED"
    envelope = task["artifacts"][0]["parts"][0]["data"]
    assert envelope["status"] == "failed" and envelope["refusal"]["code"] == "unknown_skill"
    assert task["status"]["message"]["parts"][0]["text"] == envelope["refusal"]["message"]


def test_jsonrpc_errors(client: TestClient, headers: dict[str, str]) -> None:
    unknown = client.post("/a2a/microsoft", json=rpc_body("ListTasks", {}), headers=headers).json()
    assert unknown["error"]["code"] == -32601 and unknown["id"] == "req-1"
    missing = client.post("/a2a/microsoft", json=rpc_body("GetTask", {"id": "nope"}), headers=headers).json()
    assert missing["error"]["code"] == -32001
    no_part = client.post("/a2a/microsoft", json=rpc_body("SendMessage", {"message": {"parts": [{"text": "hi"}]}}),
                          headers=headers).json()
    assert no_part["error"]["code"] == -32602
    parse = client.post("/a2a/microsoft", content=b"{", headers=headers).json()
    assert parse["error"]["code"] == -32700
    not_rpc = client.post("/a2a/microsoft", json={"method": "SendMessage"}, headers=headers).json()
    assert not_rpc["error"]["code"] == -32600


def test_the_log_line_holds_the_request_number_and_never_the_question(caplog) -> None:
    client = make_client(FakeRetriever(), FakeModel())
    secret = "Which plans does Contoso Secret Project need?"
    with caplog.at_level(logging.INFO, logger="ms_agent"):
        client.post("/a2a/microsoft/rest", json={"skill": "advice_explain",
                                                 "request": {"question": secret, "request_id": "r-log"}},
                    headers={"x-api-key": KEY})
    records = [record for record in caplog.records if record.getMessage() == "skill call"]
    assert len(records) == 1
    record = records[0]
    assert record.request_id == "r-log" and record.skill == "advice_explain" and record.status == "complete"
    assert record.prompt_tokens == 120 and record.completion_tokens == 40 and record.duration_ms >= 0
    assert "Contoso" not in json.dumps(record.__dict__, default=str)
