"""`sizing_calc` over both bindings, on the recorded UAE North meters, with a local file store."""

from __future__ import annotations

import io
from typing import Any
from urllib.parse import urlsplit

import pytest
from fastapi.testclient import TestClient
from openpyxl import load_workbook

from ms_agent.files import LocalFileStore
from ms_agent.main import create_app
from ms_agent.skills.base import Services
from tests.conftest import KEY, PUBLIC_URL, send_message, settings_for_tests
from tests.pricing_data import loaded_store

STORE = loaded_store()
VERIFICATION = {"workloads": [{"name": "web servers", "vcpu": 4, "memory_gb": 16, "os": "linux", "count": 6},
                              {"name": "SQL servers", "vcpu": 8, "memory_gb": 64, "os": "windows", "count": 2}],
                "region": "uaenorth", "pricing_models": ["sp_3y"], "ahb": True, "request_id": "r-sizing"}


@pytest.fixture
def client(tmp_path) -> TestClient:
    settings = settings_for_tests()
    services = Services(settings=settings, prices=STORE, files=LocalFileStore(tmp_path), version="test")
    return TestClient(create_app(settings=settings, services=services))


def ask(client: TestClient, request: dict[str, Any]) -> dict[str, Any]:
    response = client.post("/a2a/microsoft/rest", json={"skill": "sizing_calc", "request": request},
                           headers={"x-api-key": KEY})
    assert response.status_code == 200
    return response.json()


def test_the_verification_request_gives_sizes_totals_and_a_workbook(client: TestClient) -> None:
    envelope = ask(client, VERIFICATION)
    assert envelope["status"] == "complete" and envelope["request_id"] == "r-sizing"
    result = envelope["result"]
    assert [one["size"]["name"] for one in result["workloads"]] == ["Standard_D4as_v5", "Standard_E8as_v5"]
    assert all(len(one["alternatives"]) == 3 and one["size"]["reason"] for one in result["workloads"])
    assert result["headline"] == {"pricing_model": "sp_3y", "label": "3-year savings plan", "monthly": 1117.51,
                                  "yearly": 13410.12}
    assert [row["pricing_model"] for row in result["totals"]] == ["payg", "ri_1y", "ri_3y", "sp_1y", "sp_3y"]
    assert "not CSP, EA or MCA" in result["list_price_notice"]
    for line in result["lines"]:
        for price in line["by_model"].values():
            assert price["source_url"] and price["effective_start_date"] and price["fetched_at"] and price["currency"]
    workbook = result["workbook"]
    assert envelope["files"] == [{"url": workbook["url"], "name": "azure-estimate-uaenorth.xlsx",
                                  "media_type": workbook["media_type"]}]
    assert workbook["url"].startswith(PUBLIC_URL + "/files/") and workbook["expires_at"]
    file = client.get(urlsplit(workbook["url"]).path, headers={"x-api-key": KEY})
    sheets = load_workbook(io.BytesIO(file.content)).sheetnames
    assert sheets == ["Summary", "Lines", "Assumptions", "Sources", "Disclaimer"]
    assert envelope["warnings"] == []


def test_over_json_rpc_the_task_carries_the_files_artifact(client: TestClient) -> None:
    response = client.post("/a2a/microsoft", json=send_message("sizing_calc", VERIFICATION),
                           headers={"x-api-key": KEY})
    task = response.json()["result"]["task"]
    assert task["status"]["state"] == "TASK_STATE_COMPLETED"
    artifacts = {artifact["name"]: artifact for artifact in task["artifacts"]}
    envelope = artifacts["result"]["parts"][0]["data"]
    part = artifacts["files"]["parts"][0]
    assert part["url"] == envelope["files"][0]["url"] and part["filename"].endswith(".xlsx")
    assert part["mediaType"] == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


def test_windows_without_ahb_adds_the_ahb_column(client: TestClient) -> None:
    envelope = ask(client, VERIFICATION | {"ahb": False, "pricing_models": ["payg"]})
    totals = {row["pricing_model"]: row["monthly"] for row in envelope["result"]["totals"]}
    assert totals["payg"] == 2495.4 and totals["ahb"] == 1958.12  # step 2 totals and the OS disks, 211.96
    assert any(line["service"] == "Virtual Machines (Windows Server licence)" for line in envelope["result"]["lines"])


def test_refusals(client: TestClient, tmp_path) -> None:
    assert ask(client, VERIFICATION | {"region": "westeurope"})["refusal"]["code"] == "region_not_supported"
    huge = {"workloads": [{"name": "huge", "vcpu": 400, "memory_gb": 64}]}
    assert ask(client, huge)["refusal"]["code"] == "no_size"
    assert ask(client, {"workloads": []})["refusal"]["code"] == "bad_request"
    assert ask(client, VERIFICATION | {"pricing_models": ["ahb"]})["refusal"]["code"] == "bad_request"
    settings = settings_for_tests()
    bare = TestClient(create_app(settings=settings, services=Services(settings=settings)))
    assert ask(bare, VERIFICATION)["refusal"]["code"] == "prices_not_configured"


def test_without_a_file_store_the_estimate_comes_without_a_workbook() -> None:
    settings = settings_for_tests()
    client = TestClient(create_app(settings=settings, services=Services(settings=settings, prices=STORE)))
    envelope = ask(client, VERIFICATION)
    assert envelope["status"] == "partial" and envelope["files"] == [] and envelope["result"]["workbook"] is None
    assert "workbook_not_stored" in [warning["code"] for warning in envelope["warnings"]]
    assert envelope["result"]["headline"]["monthly"] == 1117.51
