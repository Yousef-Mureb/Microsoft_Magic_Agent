"""Azure region facts read from Microsoft Learn: the stored data, the parser on the pages as fetched on
26 October 2026 (tests/fixtures/learn_regions_*.md), and how `design_propose` cites them."""

from __future__ import annotations

from pathlib import Path

import pytest

from ms_agent.regions import (
    REGION_PAIRS_URL,
    REGIONS_LIST_URL,
    RegionDataError,
    load_regions,
    parse_region_pairs,
    parse_regions_list,
    region_data,
)
from ms_agent.settings import DATA_DIR

PAGES = Path(__file__).resolve().parent / "fixtures"
REGIONS_LIST = (PAGES / "learn_regions_list.md").read_text(encoding="utf-8")
REGION_PAIRS = (PAGES / "learn_regions_paired.md").read_text(encoding="utf-8")
FACTS = load_regions(DATA_DIR)


def test_uae_north_has_three_availability_zones() -> None:
    north = FACTS.get("uaenorth")
    assert north.display_name == "UAE North" and north.availability_zones == 3
    assert not north.restricted_access and north.physical_location == "Dubai"
    assert north.zones_text() == "across availability zones 1, 2 and 3"


def test_uae_central_has_no_zones_and_is_restricted_access() -> None:
    central = FACTS.get("uaecentral")
    assert central.availability_zones == 0 and central.restricted_access
    assert central.zones_text() == "no availability zones"


def test_uae_north_and_uae_central_are_a_pair() -> None:
    assert FACTS.get("uaenorth").paired_region == "uaecentral" and FACTS.get("uaenorth").paired_region_restricted
    assert FACTS.get("uaecentral").paired_region == "uaenorth"


def test_the_data_holds_the_seven_regions_with_its_sources() -> None:
    assert set(FACTS.regions) == {"uaenorth", "uaecentral", "westeurope", "northeurope", "eastus", "eastus2",
                                  "swedencentral"}
    assert [source["url"] for source in FACTS.sources] == [REGIONS_LIST_URL, REGION_PAIRS_URL]
    assert all(source["read_at"].startswith("2026-10-26") for source in FACTS.sources)
    assert FACTS.get("westeurope").paired_region == "northeurope" and FACTS.get("eastus").paired_region == "westus"
    assert FACTS.get("eastus2").zones_note == "marked coming soon on the page"
    assert FACTS.get("swedencentral").paired_region_restricted


def test_the_parser_reads_the_pages_as_fetched_and_the_data_matches_them() -> None:
    listed = parse_regions_list(REGIONS_LIST)
    assert listed["uaecentral"]["restricted_access"] and listed["uaecentral"]["availability_zones"] == 0
    assert listed["uaenorth"]["paired_region_name"] == "UAE Central"
    assert parse_region_pairs(REGION_PAIRS)["UAE North"] == "UAE Central"
    stored = region_data(REGIONS_LIST, REGION_PAIRS, list(FACTS.regions), read_at="x")["regions"]
    assert {name: facts["availability_zones"] for name, facts in stored.items()} == \
        {name: region.availability_zones for name, region in FACTS.regions.items()}


def test_pages_that_disagree_on_a_pair_are_not_written() -> None:
    changed = REGION_PAIRS.replace("| UAE North | ![", "| UAE North | Qatar Central ![", 1)
    with pytest.raises(RegionDataError, match="uaenorth"):
        region_data(REGIONS_LIST, changed, ["uaenorth"], read_at="x")
    with pytest.raises(RegionDataError):
        parse_regions_list("# no table here")
