"""`price_get` over the REST binding, on the recorded UAE North meters."""

from __future__ import annotations

from typing import Any

from ms_agent.pricing.store import SqlPriceStore
from tests.conftest import KEY, make_client
from tests.pricing_data import loaded_store

STORE = loaded_store()


def ask(request: dict[str, Any], prices: Any = STORE) -> dict[str, Any]:
    response = make_client(prices=prices).post("/a2a/microsoft/rest", json={"skill": "price_get", "request": request},
                                              headers={"x-api-key": KEY})
    assert response.status_code == 200
    return response.json()


def test_a_windows_size_per_model_with_the_licence_line() -> None:
    envelope = ask({"arm_sku_names": ["Standard_D4s_v5"], "os": "windows",
                    "pricing_models": ["payg", "ri_1y", "sp_3y", "ahb"], "request_id": "r-9"})
    assert envelope["status"] == "complete" and envelope["request_id"] == "r-9"
    result = envelope["result"]
    assert "not CSP, EA or MCA" in result["list_price_notice"]
    lines = {(line["pricing_model"], line["component"]): line for line in result["lines"]}
    assert lines[("payg", "vm")]["value"] == 0.419
    assert lines[("ri_1y", "compute")]["value"] == 1272.0 and lines[("ri_1y", "compute")]["unit"] == "1 Year"
    assert lines[("sp_3y", "compute")]["value"] == 0.1217535
    assert lines[("ahb", "vm")]["value"] == 0.235
    assert lines[("windows_licence", "windows_licence")]["value"] == 0.184
    assert len(result["lines"]) == 5
    for line in result["lines"]:
        assert line["currency"] == "USD" and line["source_url"] and line["effective_start_date"] and line["fetched_at"]
    assert [warning["code"] for warning in envelope["warnings"]] == ["windows_licence_separate"]


def test_a_missing_model_makes_the_answer_partial() -> None:
    envelope = ask({"arm_sku_names": ["Standard_B4ms", "Standard_D4s_v5"], "pricing_models": ["payg", "ri_3y"]})
    assert envelope["status"] == "partial"
    assert envelope["result"]["not_found"] == [{"arm_sku_name": "Standard_B4ms", "pricing_model": "ri_3y",
                                                "reason": "No 3 years reservation for Standard_B4ms in uaenorth "
                                                          "in the price store."}]
    assert len(envelope["result"]["lines"]) == 3


def test_by_product_name_and_by_meter_id() -> None:
    envelope = ask({"product_name": "Premium SSD Managed Disks"})
    names = {line["meter_name"] for line in envelope["result"]["lines"]}
    assert "P10 LRS Disk" in names and all(line["pricing_model"] == "payg" for line in envelope["result"]["lines"])
    meter_id = next(line["meter_id"] for line in envelope["result"]["lines"] if line["meter_name"] == "P10 LRS Disk")
    by_code = ask({"codes": [meter_id]})
    assert [line["value"] for line in by_code["result"]["lines"]] == [21.504]


def test_savings_plans_of_a_meter_found_by_service_and_product() -> None:
    envelope = ask({"service_name": "Virtual Machines", "product_name": "Virtual Machines Esv5 Series",
                    "pricing_models": ["sp_1y", "sp_3y", "ri_3y"]})
    values = {(line["arm_sku_name"], line["pricing_model"]): line["value"] for line in envelope["result"]["lines"]}
    assert values[("Standard_E8s_v5", "sp_3y")] == 0.29357 and values[("Standard_E8s_v5", "ri_3y")] == 6440.0


def test_refusals_nothing_asked_nothing_found_no_store_empty_store() -> None:
    assert ask({"region": "uaenorth"})["refusal"]["code"] == "bad_request"
    assert ask({"arm_sku_names": ["Standard_Nope"]})["refusal"]["code"] == "no_price"
    assert ask({"arm_sku_names": ["Standard_D4s_v5"]}, prices=None)["refusal"]["code"] == "prices_not_configured"
    empty = ask({"arm_sku_names": ["Standard_D4s_v5"]}, prices=SqlPriceStore("sqlite://"))
    assert empty["refusal"]["code"] == "prices_not_loaded" and "refresh_prices" in empty["refusal"]["message"]
    assert ask({"arm_sku_names": ["x"], "region": "UAE North"})["refusal"]["code"] == "bad_request"


def test_a_reference_currency_and_ahb_on_linux_are_warned() -> None:
    envelope = ask({"arm_sku_names": ["Standard_D4s_v5"], "pricing_models": ["payg", "ahb"]})
    assert envelope["status"] == "partial"
    assert "ahb_not_applicable" in [warning["code"] for warning in envelope["warnings"]]
    aed = ask({"arm_sku_names": ["Standard_D4s_v5"], "currency": "AED"})
    assert aed["refusal"]["code"] == "no_price"
