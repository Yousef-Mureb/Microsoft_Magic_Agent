"""Refresh the price store from the Azure Retail Prices API: the entry point of the nightly
Container Apps scheduled job, and of a manual refresh in development.

    python jobs/refresh_prices.py          # the regions, families and currencies of the settings
    python jobs/refresh_prices.py --region uaenorth --family Compute --family Storage

The store is the one `MS_AGENT_PRICE_DB_URL` names. The exit code is 0 when every scope was stored,
1 when any failed (the failed scopes keep their previous prices).
"""

from __future__ import annotations

import argparse
import json
import sys

from ms_agent.log import configure_logging
from ms_agent.pricing.ingest import RetailPricesClient, ingest
from ms_agent.pricing.store import SqlPriceStore
from ms_agent.settings import Settings


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--region", action="append", help="armRegionName, case-sensitive; repeatable")
    parser.add_argument("--family", action="append", help="serviceFamily, case-sensitive; repeatable")
    parser.add_argument("--currency", action="append", help="currency code; repeatable")
    parser.add_argument("--service", action="append", help="serviceName, case-sensitive; repeatable")
    arguments = parser.parse_args(argv)
    settings = Settings()
    configure_logging(settings.ms_agent_log_level)
    report = ingest(SqlPriceStore.from_settings(settings), RetailPricesClient(),
                    regions=arguments.region or settings.price_regions,
                    families=arguments.family or settings.price_families,
                    currencies=[one.upper() for one in arguments.currency or settings.price_currencies],
                    services=arguments.service or settings.price_services,
                    global_services=settings.price_global_services)
    print(json.dumps({"fetched_at": report.fetched_at, "stored": report.stored, "failed": report.failed}, indent=2))
    return 0 if report.ok else 1


if __name__ == "__main__":
    sys.exit(main())
