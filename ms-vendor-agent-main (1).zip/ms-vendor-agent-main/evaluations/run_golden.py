"""Run the golden questions through `advice_explain` and score the answers.

    uv run python evaluations/run_golden.py                  # in process, real Learn and Azure OpenAI from .env
    uv run python evaluations/run_golden.py --fake           # in process, fakes built from the file itself
    uv run python evaluations/run_golden.py --url http://localhost:8080 --key <client key>

The file `golden_questions.yaml` holds, per question: `id`, `domain`, `difficulty`, `question`,
`expected_facts`, `must_not_say`, `sources` (`url`, `title`, `checked`) and `notes`. An answer
passes when it cites at least one Microsoft page, states every expected fact and says nothing of
`must_not_say`. Facts are judged by words in common (`--judge keyword`, the default, needs no
model) or by the chat model (`--judge model`, needs Azure OpenAI from the environment, also with
`--url`). The fake run proves the plumbing and the scoring, not the agent: its model answers with
the expected facts.

Each fact gets a verdict: `present`, `missing`, or `judge_error` when the judge itself failed (the
error is kept). Judge errors are counted apart from missing facts, so a broken judge does not read
as a wrong answer. `--json` keeps, per question, the answer, the citations, the URLs of the passages
the agent retrieved, and every verdict. The judge goes through the same chat client as the agent,
so it never sends `temperature`, `top_p` or `max_tokens` either.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import re
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

import httpx
import yaml
from pydantic import BaseModel, ConfigDict, Field, ValidationError

HERE = Path(__file__).resolve().parent
QUESTIONS = HERE / "golden_questions.yaml"
MICROSOFT_HOSTS = ("microsoft.com", "azure.com", "office.com")
STOP_WORDS = {"the", "and", "for", "with", "that", "this", "from", "are", "its", "has", "have", "not", "any", "can",
              "only", "than", "into", "such", "must", "via", "per", "each", "also", "all", "one", "two", "three",
              "when", "which", "what", "their", "they", "them", "been", "was", "were", "will", "both", "does"}


class Source(BaseModel):
    model_config = ConfigDict(extra="forbid")

    url: str
    title: str = ""
    checked: str = ""


class Golden(BaseModel):
    """One golden question, exactly as the file spells it."""

    model_config = ConfigDict(extra="forbid")

    id: str
    domain: str
    difficulty: str = ""
    question: str = Field(min_length=3)
    expected_facts: list[str] = Field(min_length=1)
    must_not_say: list[str] = Field(default_factory=list)
    sources: list[Source] = Field(min_length=1)
    notes: str = ""


def load(path: Path = QUESTIONS) -> list[Golden]:
    with path.open(encoding="utf-8") as stream:
        given = yaml.safe_load(stream)
    if not isinstance(given, list):
        raise SystemExit(f"{path}: expected a list of questions.")
    try:
        return [Golden.model_validate(item) for item in given]
    except ValidationError as failure:
        raise SystemExit(f"{path}: {failure}") from None


# --- judges -----------------------------------------------------------------------------------

def words_of(text: str) -> set[str]:
    found = re.findall(r"[a-z0-9][a-z0-9.\-]*", text.lower())
    return {word for word in found if len(word) > 2 and word not in STOP_WORDS}


def squeeze(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower()).strip().rstrip(".")


PRESENT, MISSING, JUDGE_ERROR = "present", "missing", "judge_error"


@dataclass
class Verdict:
    statement: str
    verdict: str
    error: str = ""


class KeywordJudge:
    """A stand-in for the semantic judge the file asks for, good enough to see the plumbing work and
    needing no model. An expected fact is present when at least 60 % of its content words appear
    in the answer. A forbidden statement (`strict`) counts only when it appears word for word:
    words in common cannot tell "has no availability zones" from "has three availability zones",
    so anything looser would blame correct answers. `--judge model` judges both in substance."""

    def __init__(self, threshold: float = 0.6) -> None:
        self.threshold = threshold

    async def judge(self, answer: str, statement: str, *, strict: bool = False) -> Verdict:
        if strict:
            found = squeeze(statement) in squeeze(answer)
        else:
            wanted = words_of(statement)
            found = bool(wanted) and len(wanted & words_of(answer)) / len(wanted) >= self.threshold
        return Verdict(statement, PRESENT if found else MISSING)


class ModelJudge:
    """The chat model says whether the answer states the statement. A failed call, or an answer that is
    not `{"states": true|false}`, is a `judge_error`, never a missing fact."""

    SYSTEM = ("You judge whether an answer states a given fact, in substance, even in other words. "
              'Reply with JSON {"states": true} or {"states": false}.')

    def __init__(self, model: Any) -> None:
        self.model = model

    async def judge(self, answer: str, statement: str, *, strict: bool = False) -> Verdict:
        try:
            completion = await self.model.complete_json(self.SYSTEM, f"Answer:\n{answer}\n\nFact:\n{statement}")
        except Exception as failure:  # whatever the judge's failure, it is recorded, not scored
            return Verdict(statement, JUDGE_ERROR, f"{type(failure).__name__}: {failure}"[:300])
        try:
            states = json.loads(completion.text).get("states")
        except (ValueError, AttributeError):
            states = None
        if not isinstance(states, bool):
            return Verdict(statement, JUDGE_ERROR, f"unexpected judge output: {completion.text[:200]!r}")
        return Verdict(statement, PRESENT if states else MISSING)


# --- how the agent is asked -------------------------------------------------------------------

class Asker:
    async def ask(self, golden: Golden) -> dict[str, Any]: ...


class HttpAsker(Asker):
    def __init__(self, url: str, key: str) -> None:
        self.client = httpx.AsyncClient(base_url=url.rstrip("/"), timeout=180.0, headers={"x-api-key": key})

    async def ask(self, golden: Golden) -> dict[str, Any]:
        response = await self.client.post("/a2a/microsoft/rest", json={
            "skill": "advice_explain", "request": {"question": golden.question, "request_id": f"golden-{golden.id}"}})
        response.raise_for_status()
        return response.json()


class InProcessAsker(Asker):
    """The application in this process, over an in-memory transport."""

    def __init__(self, app: Any, key: str) -> None:
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://golden",
                                        timeout=180.0, headers={"x-api-key": key})

    async def ask(self, golden: Golden) -> dict[str, Any]:
        response = await self.client.post("/a2a/microsoft/rest", json={
            "skill": "advice_explain", "request": {"question": golden.question, "request_id": f"golden-{golden.id}"}})
        response.raise_for_status()
        return response.json()


class GoldenFakeRetriever:
    """Passages made from the file: one per expected source, holding the expected facts."""

    def __init__(self, goldens: list[Golden]) -> None:
        self.by_question = {golden.question: golden for golden in goldens}

    async def retrieve(self, question: str, *, limit: int = 8):
        from ms_agent.knowledge.retriever import Passage

        golden = self.by_question.get(question)
        if golden is None:
            return []
        text = " ".join(golden.expected_facts)
        passages = [Passage(url=source.url, title=source.title or source.url, text=text) for source in golden.sources]
        return passages[:limit]


class GoldenFakeModel:
    """Answers with the expected facts and cites the first expected source."""

    def __init__(self, goldens: list[Golden]) -> None:
        self.goldens = goldens

    async def complete_json(self, system: str, user: str):
        from ms_agent.llm.client import Completion

        golden = next((one for one in self.goldens if one.question.strip() in user), None)
        if golden is None:
            return Completion(text=json.dumps({"answer": "The passages do not answer the question.", "citations": []}))
        first = golden.sources[0]
        answer = " ".join(golden.expected_facts)
        citations = [{"url": first.url, "title": first.title, "quote": golden.expected_facts[0]}]
        return Completion(text=json.dumps({"answer": answer, "citations": citations}), prompt_tokens=300,
                          completion_tokens=120)


# --- scoring ----------------------------------------------------------------------------------

@dataclass
class Score:
    id: str
    domain: str
    status: str
    cited: bool = False
    microsoft_domain: bool = False
    source_hit: bool = False
    facts_present: int = 0
    facts_total: int = 0
    judge_errors: int = 0
    forbidden_said: int = 0
    refusal: str = ""
    seconds: float = 0.0
    answer: str = ""
    citations: list[dict[str, Any]] = field(default_factory=list)
    passage_urls: list[str] = field(default_factory=list)
    facts: list[Verdict] = field(default_factory=list)
    forbidden: list[Verdict] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return self.status == "complete" and self.cited and self.microsoft_domain \
            and self.facts_present == self.facts_total and self.forbidden_said == 0


def host_of(url: str) -> str:
    return urlsplit(url).netloc.lower()


def is_microsoft(url: str) -> bool:
    host = host_of(url)
    return any(host == suffix or host.endswith("." + suffix) for suffix in MICROSOFT_HOSTS)


async def score(golden: Golden, envelope: dict[str, Any], judge: Any) -> Score:
    from ms_agent.knowledge.retriever import canonical

    result = envelope.get("result") or {}
    cited = [one for one in result.get("citations") or [] if isinstance(one, dict)]
    citations = [one.get("url", "") for one in cited]
    found = Score(id=golden.id, domain=golden.domain, status=envelope.get("status", "?"),
                  facts_total=len(golden.expected_facts), citations=cited,
                  passage_urls=list(result.get("passage_urls") or []),
                  refusal=(envelope.get("refusal") or {}).get("code", "") if envelope.get("refusal") else "",
                  seconds=float((envelope.get("usage") or {}).get("seconds") or 0.0))
    found.cited = bool(citations)
    found.microsoft_domain = any(is_microsoft(url) for url in citations)
    expected = {canonical(source.url) for source in golden.sources}
    found.source_hit = any(canonical(url) in expected for url in citations)
    answer = result.get("answer") or ""
    found.answer = answer
    if answer:
        found.facts = [await judge.judge(answer, fact) for fact in golden.expected_facts]
        found.forbidden = [await judge.judge(answer, forbidden, strict=True) for forbidden in golden.must_not_say]
    else:
        found.facts = [Verdict(fact, MISSING, "no answer") for fact in golden.expected_facts]
    found.facts_present = sum(one.verdict == PRESENT for one in found.facts)
    found.judge_errors = sum(one.verdict == JUDGE_ERROR for one in found.facts + found.forbidden)
    found.forbidden_said = sum(one.verdict == PRESENT for one in found.forbidden)
    return found


def table(scores: list[Score]) -> str:
    head = (f"{'id':<10} {'domain':<17} {'status':<9} {'cited':<5} {'ms':<4} {'src':<4} {'facts':<6} {'bad':<4} "
            f"{'s':>6}  pass")
    lines = [head, "-" * len(head)]
    for one in scores:
        lines.append(f"{one.id:<10} {one.domain:<17} {one.status:<9} {'yes' if one.cited else 'no':<5} "
                     f"{'yes' if one.microsoft_domain else 'no':<4} {'yes' if one.source_hit else 'no':<4} "
                     f"{one.facts_present}/{one.facts_total:<4} {one.forbidden_said:<4} {one.seconds:>6.1f}  "
                     f"{'PASS' if one.passed else 'FAIL' + (' ' + one.refusal if one.refusal else '')}")
    total = len(scores)
    passed = sum(one.passed for one in scores)
    cited = sum(one.cited for one in scores)
    facts = sum(one.facts_present for one in scores)
    facts_total = sum(one.facts_total for one in scores)
    missing = sum(one.verdict == MISSING for score in scores for one in score.facts)
    errors = sum(one.judge_errors for one in scores)
    lines.append("-" * len(head))
    lines.append(f"passed {passed}/{total}   cited {cited}/{total}   facts {facts}/{facts_total}"
                 f" (missing {missing}, judge errors {errors})"
                 f"   source hit {sum(one.source_hit for one in scores)}/{total}"
                 f"   forbidden said {sum(one.forbidden_said for one in scores)}")
    return "\n".join(lines)


def model_judge(fake: bool) -> ModelJudge:
    """The environment's chat model as the judge, whether the agent runs here or at `--url`. Up to
    v0.1.1, `--judge model` was silently ignored with `--url` and the keyword judge scored the run."""
    if fake:
        raise SystemExit("--judge model needs a real model; the fake run uses the keyword judge.")
    from ms_agent.llm.client import AzureOpenAIClient
    from ms_agent.settings import Settings

    model = AzureOpenAIClient.from_settings(Settings())
    if model is None:
        raise SystemExit("--judge model needs Azure OpenAI: set the AZURE_OPENAI_* variables.")
    return ModelJudge(model)


async def run(arguments: argparse.Namespace) -> int:
    goldens = load(Path(arguments.questions))
    if arguments.only:
        wanted = set(arguments.only.split(","))
        goldens = [one for one in goldens if one.id in wanted]
    goldens = goldens[: arguments.limit] if arguments.limit else goldens

    judge: Any = model_judge(arguments.fake) if arguments.judge == "model" else KeywordJudge()
    if arguments.url:
        asker: Asker = HttpAsker(arguments.url, arguments.key or "")
    else:
        from ms_agent.main import build_services, create_app
        from ms_agent.settings import Settings
        from ms_agent.skills.base import Services

        settings = Settings(ms_agent_api_keys="golden") if arguments.fake else Settings()
        key = settings.api_keys[0] if settings.api_keys else "golden"
        if arguments.fake:
            services = Services(settings=settings, retriever=GoldenFakeRetriever(goldens),
                                model=GoldenFakeModel(goldens), version="golden")
        else:
            services = build_services(settings)
            if services.model is None:
                raise SystemExit("No Azure OpenAI model is configured; set the AZURE_OPENAI_* variables or use --fake.")
        asker = InProcessAsker(create_app(settings=settings, services=services), key)
        # The agent's JSON log lines would drown the table; only problems are shown here.
        logging.getLogger().setLevel(logging.WARNING)

    scores: list[Score] = []
    for golden in goldens:
        try:
            envelope = await asker.ask(golden)
        except httpx.HTTPError as failure:
            envelope = {"status": "failed", "refusal": {"code": "unreachable", "message": str(failure)}}
        scores.append(await score(golden, envelope, judge))
        print(f"{golden.id}: {scores[-1].status}", file=sys.stderr)
    print(table(scores))
    if arguments.json:
        out = Path(arguments.json)
        out.parent.mkdir(parents=True, exist_ok=True)
        rows = [asdict(one) | {"passed": one.passed} for one in scores]
        out.write_text(json.dumps(rows, indent=2, ensure_ascii=False), encoding="utf-8")
    return 0 if all(one.passed for one in scores) else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--questions", default=str(QUESTIONS), help="the YAML file of golden questions")
    parser.add_argument("--url", help="a running agent; without it the agent runs in this process")
    parser.add_argument("--key", help="the client key for --url")
    parser.add_argument("--fake", action="store_true", help="fake retriever and model built from the file")
    parser.add_argument("--judge", choices=("keyword", "model"), default="keyword")
    parser.add_argument("--only", help="comma-separated question ids")
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--json", help="write the scores to this file")
    return asyncio.run(run(parser.parse_args()))


if __name__ == "__main__":
    sys.exit(main())
