# Microsoft vendor agent — deployment record

Status as of 26 Oct 2026: **step 1 live in Azure** (`vendor_describe`, `advice_explain` answering
from Microsoft Learn with citations via GPT-6.1). Steps 2–4 planned.

## Where it lives

- Tenant **mindwareae** (`0e6d156f…`, Mindware corporate) — deliberately separate from Magic's
  `mindwaresand`; the agent is a vendor-supplied service Magic calls over A2A.
- Subscription **MW-Azure-SP-Data&AI** (`edc17cf3-080c-4485-898e-5fd21bce6535`),
  resource group **rg-vendor-agents**, region UAE North (model in East US).
- Public address: `https://ms-agent.lemonocean-4c71b53e.uaenorth.azurecontainerapps.io`
  - card: `/.well-known/agent-card.json` · JSON-RPC: `/a2a/microsoft` · REST: `/a2a/microsoft/rest`
  - custom domain deliberately not used (Magic's DNS zone is in mindwaresand); a vendor-side
    domain can be bound later.

| Resource | Name | Notes |
|---|---|---|
| Budget | vendor-agents-monthly | $500/month, alerts 50/80/100% to Elias, R. Achalla, S. Tulsiani, N. Shaikh |
| Log Analytics | log-vendor-agents | 90-day retention |
| Key Vault | kv-vendoragents-mw01 | RBAC, purge protection; secrets `client-key-magic-uat`, `aoai-key-dev` |
| Container Registry | acrvendoragentsmw | Basic, admin disabled; images built with `az acr build` |
| Container Apps env | cae-vendor-agents | |
| Container App | ms-agent | scale 0–1; live revision `ms-agent--0000003`, image `ms-agent:0.1.1-4919798`; secrets from Key Vault by identity |
| Managed identity | id-ms-agent | AcrPull, Key Vault Secrets User, Cognitive Services OpenAI User |
| Azure OpenAI | aoai-vendor-agents-mw (East US) | gpt-6.1-sol 2026-09-29 (500K TPM, pinned), text-embedding-3-large v1 (300K, pinned) |

## How to redeploy (Cloud Shell, mindwareae)

```
cd ~/ms-vendor-agent && gh auth login --hostname github.com --git-protocol https --web
git pull && gh auth logout --hostname github.com
TAG=<version>-$(git rev-parse --short HEAD)
az acr build --registry acrvendoragentsmw --image ms-agent:$TAG .
az containerapp update -g rg-vendor-agents -n ms-agent --image acrvendoragentsmw.azurecr.io/ms-agent:$TAG
```

## Facts learned (keep)

- Magic's client (`magic3-platform/modules/tools/services/authority/src/vendors.py`) fetches
  `/.well-known/agent-card.json`, calls JSON-RPC `SendMessage`/`GetTask`/`CancelTask` (A2A 1.0),
  sends the key as `x-api-key` and Bearer.
- Magic's operator check fails "Designs a solution" without a `design_propose` skill — needed
  before the agent can be published (step 2).
- Magic refuses request fields whose names contain customer, client, company, organization,
  contact, e-mail, phone, price, discount, margin, deal, person, people.
- GPT-6.x reasoning models reject `temperature` (non-default), `top_p` and `max_tokens`.
- UAE North offers no GPT-6 model and no text-embedding-3-large.
- In this subscription Global Standard quota is one pool per model across all regions
  (10,000K TPM each); gpt-6-luna is fully used (Magic East US 2 + `magic3backup-resource`
  Sweden Central).
- Azure Container Registry builds do not support BuildKit `--mount` in Dockerfiles.
- The laptop blocks uv/pip launcher executables; use `python -m …`.
- First live answer (Copilot prerequisites): correct, cited, ~3.6K in / 0.9K out tokens, 19 s.

## Next

1. Run the 30 golden questions against the live agent (`run_golden.py --url … --judge model`).
2. Step 2 (brief ready): Azure Retail Prices, `price_get`, `sizing_calc`, estimate workbook,
   first `design_propose`, managed identity for OpenAI, merge duplicate citations.
3. Step 3: diagrams (`design_figure`) and Azure AI Search knowledge base. Step 4: licensing rules,
   `bom_from_spec`.
4. Hand Stan the card URL and the client key (via vault) once `design_propose` passes.

## What a step 2 redeploy needs (0.2.3, branches `elias/step2-pricing`, `elias/logo`, `elias/logo-svg`; not deployed)

- Azure OpenAI without a key: leave `AZURE_OPENAI_API_KEY` unset and set `AZURE_CLIENT_ID` to
  `id-ms-agent`'s client id (it already has Cognitive Services OpenAI User).
- The price store must be shared by the app and the nightly job: an Azure Database for
  PostgreSQL and `MS_AGENT_PRICE_DB_URL=postgresql+psycopg://...` (the driver, `psycopg[binary]`,
  is in the image since 0.2.1; the password belongs in Key Vault, referenced as a Container Apps
  secret). With the image's default SQLite in `/tmp`, each container has its own
  empty store and the pricing skills refuse `prices_not_loaded`.
- The nightly job: a Container Apps job on a schedule, same image, command
  `python jobs/refresh_prices.py`, same environment as the app.
- The workbook: a storage account with a container `estimates` (lifecycle rule: delete after one
  day), `MS_AGENT_FILES_BACKEND=blob`, `AZURE_STORAGE_ACCOUNT_URL`; the identity needs Storage
  Blob Data Contributor and Storage Blob Delegator (for the 24-hour SAS link).
- After the redeploy, MAGIC must check and publish the agent again to see the three new skills.

## What step 3a adds to a redeploy (0.3.0, branch `elias/step3-diagrams`; not deployed)

- New settings, both with working defaults: `MS_AGENT_PRICE_SERVICES` (the baseline services
  ingested per region: Application Gateway, Backup, Key Vault, Log Analytics, Microsoft Defender for
  Cloud, Azure Bastion, Azure Site Recovery, API Management) and `MS_AGENT_PRICE_GLOBAL_SERVICES`
  (`Load Balancer`, under `armRegionName 'Global'`). The nightly job reads them; run it once after
  the redeploy, for `uaenorth` and `uaecentral` at least, before asking for a design.
- The image installs `fonts-dejavu-core` (text in the PNG diagrams) and carries resvg-py (wheels,
  no system library) and the icons under `src/ms_agent/diagram/icons/`. No new secret, no new role.
- The diagrams go to the same file store as the workbook (`MS_AGENT_FILES_BACKEND`).
- New skill `design_figure`: MAGIC must check and publish the agent again to offer it.
