<#
.SYNOPSIS
    Regenerate data/vm_sizes_<region>.json from the Azure CLI: every virtual machine size offered in
    the region, with vCPU, memory, quota family, premium disk support, Hyper-V generations and
    accelerated networking.

.EXAMPLE
    ./scripts/refresh_vm_sizes.ps1 -Region uaenorth

.NOTES
    Needs `az login` to any subscription; the call only reads. The Retail Prices API has no
    specifications, which is why this snapshot exists. The shape is the one
    src/ms_agent/pricing/vm_catalog.py reads:
    {region, source, generated, sizes: [{name, family, vcpus, memory_gb, premium_io,
    hyperv_generations, accelerated_networking}]}.
#>
param(
    [Parameter(Mandatory = $true)][string]$Region
)
$ErrorActionPreference = "Stop"

$skus = az vm list-skus -l $Region --resource-type virtualMachines -o json | ConvertFrom-Json
$sizes = foreach ($sku in $skus) {
    # A size restricted in the region for this subscription is still listed by Azure; leave it out.
    if ($sku.restrictions | Where-Object { $_.type -eq "Location" }) { continue }
    $capability = @{}
    foreach ($one in $sku.capabilities) { $capability[$one.name] = $one.value }
    if (-not $capability.ContainsKey("vCPUs") -or -not $capability.ContainsKey("MemoryGB")) { continue }
    [ordered]@{
        name                   = $sku.name
        family                 = $sku.family
        vcpus                  = [int]$capability["vCPUs"]
        memory_gb              = [double]$capability["MemoryGB"]
        premium_io             = ($capability["PremiumIO"] -eq "True")
        hyperv_generations     = $capability["HyperVGenerations"]
        accelerated_networking = ($capability["AcceleratedNetworkingEnabled"] -eq "True")
    }
}

$document = [ordered]@{
    region    = $Region
    source    = "az vm list-skus"
    generated = (Get-Date -Format "yyyy-MM-dd")
    sizes     = @($sizes | Sort-Object { $_.name })
}
$target = Join-Path (Split-Path $PSScriptRoot -Parent) "data/vm_sizes_$Region.json"
$document | ConvertTo-Json -Depth 4 | Set-Content -Path $target -Encoding utf8
Write-Output "$($document.sizes.Count) sizes -> $target"
