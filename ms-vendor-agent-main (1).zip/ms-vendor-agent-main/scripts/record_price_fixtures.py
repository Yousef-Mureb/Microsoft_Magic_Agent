"""Record the Retail Prices API answers the tests use, into tests/fixtures/retail_uaenorth.json.

Run once, by hand, with network: `python scripts/record_price_fixtures.py`. The tests never call
the API; they read this file. Spot, Low Priority and Dev/Test meters are left out to keep it small
(the lookup excludes them anyway; one of each stays, to prove it does).
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from ms_agent.pricing.ingest import RetailPricesClient, build_filter, now_text

ROOT = Path(__file__).resolve().parents[1]
REGION = "uaenorth"
# The sizes of the test catalog, not the full list: the fixture stays small.
CATALOG = json.loads((ROOT / "tests" / "fixtures" / f"vm_sizes_{REGION}.json").read_text(encoding="utf-8"))
DISKS = ("Premium SSD Managed Disks", "Standard SSD Managed Disks", "Standard HDD Managed Disks")


def kept(item: dict, keep_one: set[str]) -> bool:
    name = item["skuName"]
    for marker in ("Spot", "Low Priority"):
        if marker in name:
            if item["armSkuName"] == "Standard_D4s_v5" and marker not in keep_one:
                keep_one.add(marker)
                return True
            return False
    if item["type"] == "DevTestConsumption":
        if item["armSkuName"] == "Standard_D4s_v5" and "DevTest" not in keep_one:
            keep_one.add("DevTest")
            return True
        return False
    return True


def main() -> int:
    client = RetailPricesClient()
    items: list[dict] = []
    queries: list[str] = []
    keep_one: set[str] = set()
    for size in CATALOG["sizes"]:
        query = build_filter({"serviceName": "Virtual Machines", "armRegionName": REGION, "armSkuName": size["name"]})
        queries.append(query)
        items += [item for item in client.items(query) if kept(item, keep_one)]
    for product in DISKS:
        query = build_filter({"armRegionName": REGION, "productName": product, "priceType": "Consumption"})
        queries.append(query)
        items += [item for item in client.items(query) if item["meterName"].endswith(("LRS Disk", "LRS Disk Mount"))]
    out = ROOT / "tests" / "fixtures" / f"retail_{REGION}.json"
    out.write_text(json.dumps({"recorded_at": now_text(), "api_version": client.api_version, "queries": queries,
                               "Items": items}, indent=1), encoding="utf-8")
    print(f"{len(items)} items -> {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
