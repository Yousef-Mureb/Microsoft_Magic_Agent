"""Record the Retail Prices API answers step 3's tests use, into tests/fixtures/retail_services.json.

Run once, by hand, with network: `python scripts/record_service_fixtures.py`. Recorded: the baseline
services of a design in UAE North (consumption meters), Load Balancer under `armRegionName 'Global'`,
and, for the DR region UAE Central: Azure Site Recovery, the managed disk meters and the VM meters of
the test catalog's sizes. Step 2's tests/fixtures/retail_uaenorth.json is left as it was.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from ms_agent.pricing.ingest import RetailPricesClient, build_filter, now_text
from ms_agent.settings import Settings

ROOT = Path(__file__).resolve().parents[1]
CATALOG = json.loads((ROOT / "tests" / "fixtures" / "vm_sizes_uaenorth.json").read_text(encoding="utf-8"))
DISKS = ("Premium SSD Managed Disks", "Standard SSD Managed Disks", "Standard HDD Managed Disks")


def main() -> int:
    client = RetailPricesClient()
    queries: list[str] = []
    items: list[dict] = []

    def take(equals: dict[str, str], keep=lambda item: item["type"] == "Consumption") -> None:
        query = build_filter(equals)
        queries.append(query)
        items.extend(item for item in client.items(query) if keep(item))

    for service in Settings(_env_file=None).price_services:
        take({"serviceName": service, "armRegionName": "uaenorth"})
    for service in Settings(_env_file=None).price_global_services:
        take({"serviceName": service, "armRegionName": "Global"})
    take({"serviceName": "Azure Site Recovery", "armRegionName": "uaecentral"})
    for product in DISKS:
        take({"armRegionName": "uaecentral", "productName": product, "priceType": "Consumption"},
             lambda item: item["meterName"].endswith("LRS Disk"))
    for size in CATALOG["sizes"]:
        take({"serviceName": "Virtual Machines", "armRegionName": "uaecentral", "armSkuName": size["name"]},
             lambda item: item["type"] in ("Consumption", "Reservation") and "Spot" not in item["skuName"]
             and "Low Priority" not in item["skuName"])
    out = ROOT / "tests" / "fixtures" / "retail_services.json"
    out.write_text(json.dumps({"recorded_at": now_text(), "api_version": client.api_version, "queries": queries,
                               "Items": items}, indent=1), encoding="utf-8")
    print(f"{len(items)} items -> {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
