"""Download Microsoft's architecture icons and keep only the SVGs `diagram/icons.py` maps, unmodified.

    python scripts/fetch_icons.py

Writes the files under src/ms_agent/diagram/icons/{azure,entra}/ with their original names and
bytes, and src/ms_agent/diagram/icons/originals.json with, per file, the zip it came from, its path
in the zip and its SHA-256. SOURCE.md (versions, URLs, terms) is written by hand from the pages.
"""

from __future__ import annotations

import hashlib
import io
import json
import sys
import zipfile
from datetime import UTC, datetime

import httpx

from ms_agent.diagram.icons import ICON_DIR, ICONS

AZURE_ZIP = "https://arch-center.azureedge.net/icons/Azure_Public_Service_Icons_V24.zip"
ENTRA_ZIP = ("https://download.microsoft.com/download/3/1/a/31a56038-856a-4489-88e4-ee5a1c4352be/"
             "Microsoft%20Entra%20architecture%20icons%20-%20Oct%202023.zip")
FOLDERS = {"azure": AZURE_ZIP, "entra": ENTRA_ZIP}
# Where a file name is in several folders of the Azure zip (the same icon under several categories),
# the folder the file is taken from.
PREFERRED = ("compute", "networking", "integration", "app services", "containers", "databases", "storage",
             "security", "monitor", "management + governance", "identity", "general", "ai + machine learning", "iot",
             "other", "Microsoft Entra color icons SVG")


def main() -> int:
    archives = {folder: zipfile.ZipFile(io.BytesIO(httpx.get(url, follow_redirects=True, timeout=180).content))
                for folder, url in FOLDERS.items()}
    originals: dict[str, dict[str, str]] = {}
    for relative in sorted(set(ICONS.values())):
        folder, name = relative.split("/", 1)
        candidates = [entry for entry in archives[folder].namelist() if entry.endswith("/" + name)]
        if not candidates:
            print(f"Not in the zip: {relative}", file=sys.stderr)
            return 1
        candidates.sort(key=lambda entry: next((index for index, one in enumerate(PREFERRED)
                                                if f"/{one}/" in entry), len(PREFERRED)))
        data = archives[folder].read(candidates[0])
        target = ICON_DIR / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        originals[relative] = {"zip": FOLDERS[folder], "path_in_zip": candidates[0],
                               "sha256": hashlib.sha256(data).hexdigest()}
    document = {"downloaded_at": datetime.now(tz=UTC).isoformat(timespec="seconds").replace("+00:00", "Z"),
                "files": originals}
    (ICON_DIR / "originals.json").write_text(json.dumps(document, indent=1) + "\n", encoding="utf-8")
    print(f"{len(originals)} icons -> {ICON_DIR}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
