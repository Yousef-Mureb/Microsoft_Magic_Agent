"""Read the Azure region facts from Microsoft Learn into data/azure_regions.json.

    python scripts/refresh_regions.py
    python scripts/refresh_regions.py --save-pages tests/fixtures    # also keep the pages, for the tests

The pages are read through the Microsoft Learn MCP server (`microsoft_docs_fetch`), the same server the
agent's `advice_explain` uses. The script stops, writing nothing, when the two pages disagree on a pair.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

from ms_agent.knowledge.learn_mcp import LearnMcpClient
from ms_agent.pricing.ingest import now_text
from ms_agent.regions import REGION_PAIRS_URL, REGIONS_LIST_URL, RegionDataError, region_data
from ms_agent.settings import DATA_DIR, Settings

REGIONS = ["uaenorth", "uaecentral", "westeurope", "northeurope", "eastus", "eastus2", "swedencentral"]


async def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--save-pages", help="a folder to keep the two pages' Markdown in")
    arguments = parser.parse_args(argv)
    client = LearnMcpClient(Settings().learn_mcp_url)
    try:
        regions_list = await client.fetch(REGIONS_LIST_URL)
        region_pairs = await client.fetch(REGION_PAIRS_URL)
    finally:
        await client.close()
    try:
        document = region_data(regions_list, region_pairs, REGIONS, read_at=now_text())
    except RegionDataError as failure:
        print(f"Not written: {failure}", file=sys.stderr)
        return 1
    target = DATA_DIR / "azure_regions.json"
    target.write_text(json.dumps(document, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    if arguments.save_pages:
        folder = Path(arguments.save_pages)
        # newline="": the pages are kept byte for byte, without Windows adding a second carriage return.
        (folder / "learn_regions_list.md").write_text(regions_list, encoding="utf-8", newline="")
        (folder / "learn_regions_paired.md").write_text(region_pairs, encoding="utf-8", newline="")
    print(f"{len(document['regions'])} regions -> {target}")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
