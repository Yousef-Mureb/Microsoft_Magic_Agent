"""`design_figure`: an Azure architecture diagram of a design, with Microsoft's official icons.

Input: the `design` object `design_propose` returns, or the request `design_propose` takes (then the
design is made first, without the model). Output: the diagram as SVG (primary) and PNG (for
documents), both as links in `files`; the result has a caption and a legend of the services drawn.
The drawing is code, from the design's data: the model draws nothing.
"""

from __future__ import annotations

import asyncio

from pydantic import Field, model_validator

from ms_agent.contract import Common, Outcome
from ms_agent.diagram.figure import make_figure
from ms_agent.diagram.model import FigureDesign
from ms_agent.skills.base import Services, Skill
from ms_agent.skills.design_propose import DesignProposeRequest, design_core, figure_design, solution_of
from ms_agent.skills.sizing_calc import WorkloadIn


class DesignFigureRequest(DesignProposeRequest):
    design: FigureDesign | None = Field(default=None, description="The `design` object of a design_propose answer")
    workloads: list[WorkloadIn] | None = Field(  # type: ignore[assignment]
        default=None, min_length=1, max_length=50,
        description="Instead of `design`: the workloads, as design_propose takes them")

    @model_validator(mode="after")
    def _one_source(self) -> DesignFigureRequest:
        if (self.design is None) == (self.workloads is None):
            raise ValueError("give either design (from design_propose) or workloads")
        return self


def figure_from_request(services: Services, request: DesignFigureRequest) -> FigureDesign:
    if request.design is not None:
        return request.design
    core = design_core(services, request)
    solution = solution_of(core, request)
    return figure_design(solution, request, core.regions, core.dr_region)


def answer(services: Services, request: DesignFigureRequest) -> Outcome:
    design = figure_from_request(services, request)
    figure = make_figure(services, design, title=f"azure-diagram-{design.region}")
    status = "complete" if len(figure.files) == 2 else "partial"
    return Outcome(figure.result() | {"design": design.model_dump()}, warnings=figure.warnings, files=figure.files,
                   status=status)


async def handle(request: Common, services: Services) -> Outcome:
    assert isinstance(request, DesignFigureRequest)
    return await asyncio.to_thread(answer, services, request)


SKILL = Skill(
    id="design_figure",
    name="Design figure",
    description=("An Azure architecture diagram of a design, drawn by code with Microsoft's official icons: region, "
                 "virtual network, subnets, availability zones, front door, shared services, disaster recovery "
                 "region. SVG and PNG as links."),
    input_model=DesignFigureRequest,
    handler=handle,
    tags=("microsoft", "azure", "vendor-agent/1", "design"),
    examples=('{"skill": "design_figure", "request": {"workloads": [{"name": "API workers", "vcpu": 4, '
              '"memory_gb": 16, "os": "linux", "count": 2}], "region": "uaenorth", '
              '"availability": "zone_redundant"}}',),
)
