"""The skill registry: id -> handler and input schema.

A new skill is one module in this package and one line in `REGISTRY`. The card (`card.py`)
and the dispatcher (`main.py`) read nothing else.
"""

from __future__ import annotations

from ms_agent.skills import advice_explain, design_figure, design_propose, price_get, sizing_calc, vendor_describe
from ms_agent.skills.base import Services, Skill

REGISTRY: dict[str, Skill] = {skill.id: skill for skill in (
    vendor_describe.SKILL,
    design_propose.SKILL,
    design_figure.SKILL,
    advice_explain.SKILL,
    price_get.SKILL,
    sizing_calc.SKILL,
)}

__all__ = ["REGISTRY", "Services", "Skill"]
