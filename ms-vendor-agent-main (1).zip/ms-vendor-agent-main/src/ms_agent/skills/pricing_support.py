"""What the pricing skills share: the request fields for region and currency, the price store check,
and the warnings every priced answer carries."""

from __future__ import annotations

from pydantic import Field

from ms_agent.contract import SkillError, Warning
from ms_agent.pricing.store import PriceStore
from ms_agent.skills.base import Services

DEFAULT_REGION = "uaenorth"


def region_field() -> object:
    return Field(default=DEFAULT_REGION, pattern=r"^[a-z0-9]+$", max_length=40,
                 description="Azure region as armRegionName, lower case, e.g. uaenorth, uaecentral, westeurope")


def currency_field() -> object:
    return Field(default="USD", pattern=r"^[A-Z]{3}$",
                 description="ISO currency code; USD is Microsoft's list price, others (AED, SAR, EUR) are for "
                             "reference and must have been ingested")


def store_of(services: Services) -> PriceStore:
    """The price store, or the refusal that says why there is none."""
    if services.prices is None:
        raise SkillError("prices_not_configured", "No price store is configured: set MS_AGENT_PRICE_DB_URL.")
    if services.prices.count() == 0:
        raise SkillError("prices_not_loaded", "The price store is empty: run jobs/refresh_prices.py first.")
    return services.prices


def currency_warnings(currency: str) -> list[Warning]:
    if currency == "USD":
        return []
    return [Warning(code="reference_currency",
                    message=f"Prices in {currency} are given by Microsoft for reference; the list price is in USD.")]
