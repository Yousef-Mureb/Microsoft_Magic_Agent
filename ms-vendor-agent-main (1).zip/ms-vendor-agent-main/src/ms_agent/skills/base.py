"""What a skill is, and what it may use.

A skill is an id, the words MAGIC's model reads about it, an input model whose JSON schema goes
into the agent card, and an asynchronous handler. The handler receives the validated request
and the `Services`: the retriever, the chat model and the settings.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from ms_agent.contract import Common, Outcome

if TYPE_CHECKING:  # pragma: no cover - typing only, to keep the skill modules free of cycles
    from ms_agent.files import FileStore, StoredFile
    from ms_agent.knowledge.retriever import Retriever
    from ms_agent.llm.client import ChatModel
    from ms_agent.pricing.store import PriceStore
    from ms_agent.settings import Settings


@dataclass
class Services:
    """What the handlers may use. Tests pass fakes; `main.py` builds the real ones."""

    settings: Settings
    retriever: Retriever | None = None
    model: ChatModel | None = None
    version: str = "0.0.0"
    # The Azure price store (`pricing/store.py`); None when it could not be opened.
    prices: PriceStore | None = None
    # Where made files are kept for 24 hours (`files.py`), served at `/files/<id>`.
    files: FileStore | None = None

    def file_link(self, stored: StoredFile) -> dict[str, Any]:
        """The envelope's entry for a stored file: on the agent's own host, where MAGIC fetches it."""
        return {"url": f"{self.settings.ms_agent_public_url.rstrip('/')}/files/{stored.id}", "name": stored.name,
                "media_type": stored.media_type}

    @staticmethod
    def data_date() -> str:
        """The date of the knowledge: Microsoft Learn is read live, so it is today."""
        return datetime.now(tz=UTC).date().isoformat()


Handler = Callable[[Common, Services], Awaitable[Outcome]]


@dataclass(frozen=True)
class Skill:
    id: str
    name: str
    description: str
    input_model: type[Common]
    handler: Handler
    tags: tuple[str, ...] = ()
    examples: tuple[str, ...] = field(default_factory=tuple)
