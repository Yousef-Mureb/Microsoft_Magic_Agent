"""`price_get`: Azure list prices, each with its source and dates.

By virtual machine size (`arm_sku_names`, per pricing model), by Retail Prices meter or SKU id
(`codes`), or by service and product name. Every line carries value, currency, unit, source URL,
Microsoft's `effectiveStartDate` and our `fetched_at`. Code only, no model.
"""

from __future__ import annotations

import asyncio
from typing import Any, Literal

from pydantic import Field, model_validator

from ms_agent.contract import Common, Outcome, SkillError, Warning
from ms_agent.pricing.lookup import (
    LABELS,
    LIST_PRICE_NOTICE,
    TERM_MONTHS,
    TERMS,
    Price,
    PriceNotFound,
    PricingModel,
    decimal_of,
    price_for,
    source_of,
    windows_licence,
)
from ms_agent.pricing.store import Meter, PriceStore
from ms_agent.skills.base import Services, Skill
from ms_agent.skills.pricing_support import currency_field, currency_warnings, region_field, store_of

LINE_LIMIT = 200


class PriceGetRequest(Common):
    arm_sku_names: list[str] | None = Field(default=None, min_length=1, max_length=50,
                                            description="VM sizes as armSkuName, e.g. Standard_D4s_v5")
    codes: list[str] | None = Field(default=None, min_length=1, max_length=50,
                                    description="Retail Prices meterId or skuId values")
    service_name: str | None = Field(default=None, max_length=128,
                                     description="Retail Prices serviceName, exact case, e.g. 'Virtual Machines'")
    product_name: str | None = Field(default=None, max_length=256,
                                     description="Retail Prices productName, exact case, e.g. "
                                                 "'Premium SSD Managed Disks'")
    region: str = region_field()  # type: ignore[assignment]
    os: Literal["linux", "windows"] = Field(default="linux", description="For VM sizes: Windows includes the licence")
    pricing_models: list[PricingModel] = Field(default=["payg"], min_length=1, max_length=6,
                                               description="payg, ri_1y, ri_3y, sp_1y, sp_3y, ahb")
    currency: str = currency_field()  # type: ignore[assignment]

    @model_validator(mode="after")
    def _something_to_price(self) -> PriceGetRequest:
        if not (self.arm_sku_names or self.codes or self.service_name or self.product_name):
            raise ValueError("give arm_sku_names, codes, or service_name / product_name")
        return self


def _line(price: Price, **what: Any) -> dict[str, Any]:
    return {key: value for key, value in what.items() if value is not None} | price.as_dict()


def _vm_lines(store: PriceStore, request: PriceGetRequest, sku: str) -> tuple[list[dict], list[dict]]:
    lines, missing = [], []
    licence_added = False
    for model in dict.fromkeys(request.pricing_models):
        try:
            price = price_for(store, sku, request.region, request.os, model, request.currency)
        except PriceNotFound as failure:
            missing.append({"arm_sku_name": sku, "pricing_model": model, "reason": str(failure)})
            continue
        compute_only = request.os == "windows" and model[:3] in ("ri_", "sp_")
        lines.append(_line(price, arm_sku_name=sku, region=request.region, os=request.os,
                           component="compute" if compute_only else "vm"))
        if compute_only and not licence_added:
            licence_added = True
            try:
                licence = windows_licence(store, sku, request.region, request.currency)
            except PriceNotFound as failure:
                missing.append({"arm_sku_name": sku, "pricing_model": "windows_licence", "reason": str(failure)})
            else:
                lines.append(_line(licence, arm_sku_name=sku, region=request.region, os="windows",
                                   component="windows_licence"))
    return lines, missing


def _basis(unit: str) -> str:
    return "hourly" if "Hour" in unit else "monthly" if "Month" in unit else "unit"


def _meter_lines(meter: Meter, models: list[str]) -> list[dict[str, Any]]:
    """A meter as the requested pricing models see it: consumption as `payg`, a reservation as its term,
    each savings plan term as `sp_*`. Dev/Test meters are not list prices of production use."""
    what = {"meter_id": meter.meter_id, "meter_name": meter.meter_name, "product_name": meter.product_name,
            "sku_name": meter.sku_name, "arm_sku_name": meter.arm_sku_name or None, "region": meter.arm_region_name,
            "service_name": meter.service_name}
    lines = []
    if meter.type == "Consumption" and "payg" in models:
        lines.append(_line(Price(decimal_of(meter.retail_price), meter.currency_code, meter.unit_of_measure,
                                 _basis(meter.unit_of_measure), "payg", LABELS["payg"],  # type: ignore[arg-type]
                                 (source_of(meter, "retailPrice"),)), **what))
    if meter.type == "Reservation":
        model = next((one for one in ("ri_1y", "ri_3y") if TERMS[one] == meter.reservation_term), None)
        if model in models:
            lines.append(_line(Price(decimal_of(meter.retail_price), meter.currency_code, meter.reservation_term,
                                     "term", model, LABELS[model] + ", price of the whole term",
                                     (source_of(meter, "retailPrice"),),
                                     term_months=TERM_MONTHS.get(meter.reservation_term, 0)), **what))
    if meter.type == "Consumption":
        for model in ("sp_1y", "sp_3y"):
            plan = meter.savings_plan_for(TERMS[model])
            if plan is not None and model in models:
                lines.append(_line(Price(decimal_of(plan.retail_price), meter.currency_code, meter.unit_of_measure,
                                         "hourly", model, LABELS[model],
                                         (source_of(meter, f"savingsPlan[{TERMS[model]}].retailPrice"),)), **what))
    return lines


def answer(store: PriceStore, request: PriceGetRequest) -> Outcome:
    lines: list[dict[str, Any]] = []
    missing: list[dict[str, Any]] = []
    warnings: list[Warning] = currency_warnings(request.currency)
    models = list(dict.fromkeys(request.pricing_models))
    for sku in request.arm_sku_names or []:
        found, lost = _vm_lines(store, request, sku)
        lines += found
        missing += lost
    for code in request.codes or []:
        meters = store.find(currency=request.currency, meter_id=code, arm_region_name=request.region) \
            or store.find(currency=request.currency, sku_id=code, arm_region_name=request.region)
        if not meters:
            missing.append({"code": code, "reason": f"No meter or SKU {code} in {request.region} in the price store."})
        for meter in meters:
            lines += _meter_lines(meter, models)
    if request.service_name or request.product_name:
        equals = {key: value for key, value in (("service_name", request.service_name),
                                                ("product_name", request.product_name)) if value}
        meters = store.find(currency=request.currency, limit=LINE_LIMIT + 1, arm_region_name=request.region, **equals)
        if not meters:
            missing.append({**equals, "reason": "No meter matches; names are exact and case-sensitive."})
        for meter in meters[:LINE_LIMIT]:
            lines += _meter_lines(meter, models)
    if len(lines) > LINE_LIMIT:
        lines = lines[:LINE_LIMIT]
        warnings.append(Warning(code="truncated", message=f"Only the first {LINE_LIMIT} lines are given; narrow the "
                                                          "product or SKU."))
    if "ahb" in models and request.os != "windows" and request.arm_sku_names:
        warnings.append(Warning(code="ahb_not_applicable", message="Azure Hybrid Benefit applies to Windows only."))
    if any(line.get("component") == "windows_licence" for line in lines):
        warnings.append(Warning(code="windows_licence_separate",
                                message="Reservations and savings plans cover compute only; the Windows licence "
                                        "line is paid on top, per hour."))
    if not lines:
        reasons = "; ".join(one["reason"] for one in missing[:5]) or "Nothing matched."
        raise SkillError("no_price", f"No price found. {reasons}")
    return Outcome({"region": request.region, "currency": request.currency, "list_price_notice": LIST_PRICE_NOTICE,
                    "lines": lines, "not_found": missing},
                   warnings=warnings, status="partial" if missing else "complete")


async def handle(request: Common, services: Services) -> Outcome:
    assert isinstance(request, PriceGetRequest)
    store = store_of(services)
    return await asyncio.to_thread(answer, store, request)


SKILL = Skill(
    id="price_get",
    name="Price get",
    description=("Azure list prices from the Azure Retail Prices API, per pricing model (pay-as-you-go, "
                 "reservations, savings plans, Azure Hybrid Benefit), with source URL and dates. Code only."),
    input_model=PriceGetRequest,
    handler=handle,
    tags=("microsoft", "azure", "vendor-agent/1", "data"),
    examples=('{"skill": "price_get", "request": {"arm_sku_names": ["Standard_D4s_v5"], "region": "uaenorth", '
              '"os": "windows", "pricing_models": ["payg", "ri_1y", "sp_3y", "ahb"]}}',),
)
