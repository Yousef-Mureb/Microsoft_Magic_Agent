"""`sizing_calc`: from workloads to virtual machine sizes, disks, a priced estimate and its workbook.

Code only, no model. Each workload is sized on the leading pricing model (the first of
`pricing_models`); the estimate shows all five commitments side by side, and Azure Hybrid Benefit
where it applies. Every number carries its provenance; the workbook link is on the agent's own host.
"""

from __future__ import annotations

import asyncio
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from ms_agent.contract import Common, Outcome, SkillError, Warning
from ms_agent.estimate_workbook import MEDIA_TYPE, build_workbook, summary_rows
from ms_agent.pricing.lookup import LABELS, LIST_PRICE_NOTICE
from ms_agent.pricing.vm_catalog import CatalogNotFound, load
from ms_agent.sizing.vm import NoSize, Ranked
from ms_agent.sizing.workloads import DiskSpec, Sizing, WorkloadSpec, size_workloads
from ms_agent.skills.base import Services, Skill
from ms_agent.skills.pricing_support import currency_field, currency_warnings, region_field, store_of

Commitment = Literal["payg", "ri_1y", "ri_3y", "sp_1y", "sp_3y"]


class DiskIn(BaseModel):
    model_config = ConfigDict(extra="forbid")

    type: Literal["premium_ssd", "standard_ssd", "standard_hdd"] = "premium_ssd"
    size_gb: int = Field(ge=1, le=32767, description="Size in GiB; the smallest disk tier that holds it is priced")
    count: int = Field(default=1, ge=1, le=64, description="Disks of this kind per machine")


class WorkloadIn(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=80, description="What the machines do, e.g. 'web servers'")
    vcpu: int = Field(ge=1, le=416, description="vCPU per machine, at least")
    memory_gb: float = Field(gt=0, le=12000, description="Memory per machine in GiB, at least")
    os: Literal["linux", "windows"] = "linux"
    count: int = Field(default=1, ge=1, le=1000, description="Number of machines")
    hours_per_month: float = Field(default=730, gt=0, le=744, description="Hours each machine runs; 730 = always on")
    disks: list[DiskIn] = Field(default_factory=list, max_length=16, description="Data disks per machine")
    os_disk: DiskIn | None = Field(default=None, description="Default: Premium SSD P10 (128 GiB) for Linux, "
                                                             "P15 (256 GiB) for Windows")
    traffic: Literal["http", "tcp", "internal"] = Field(
        default="internal", description="http: reached over HTTP/HTTPS (Application Gateway WAF v2, or API "
                                        "Management); tcp: other traffic from outside (Standard Load Balancer); "
                                        "internal: not reached from outside")
    environment: Literal["production", "dev_test"] = Field(
        default="production", description="B-series (burstable) sizes are chosen only for dev_test")


class SizingCalcRequest(Common):
    workloads: list[WorkloadIn] = Field(min_length=1, max_length=50)
    region: str = region_field()  # type: ignore[assignment]
    pricing_models: list[Commitment] = Field(
        default=["payg"], min_length=1, max_length=5,
        description="The first is the model sizes are ranked on and the headline total; the estimate always shows "
                    "payg, ri_1y, ri_3y, sp_1y and sp_3y side by side")
    ahb: bool = Field(default=False, description="Azure Hybrid Benefit for every Windows machine: the customer "
                                                 "brings eligible Windows Server licences")
    families: list[str] | None = Field(
        default=None, max_length=12,
        description="VM families allowed, e.g. ['D', 'E']; default D, E, F, B (B for dev_test only)")
    currency: str = currency_field()  # type: ignore[assignment]


def _size_of(ranked: Ranked, currency: str) -> dict[str, Any]:
    size = ranked.size
    return {"name": size.name, "vcpu": size.vcpu, "memory_gib": size.memory_gib, "family": size.family,
            "generation": size.generation, "current_generation": ranked.current_generation,
            "premium_disk": size.premium_disk, "monthly_per_machine": float(ranked.monthly), "currency": currency,
            "rank": ranked.rank, "reason": ranked.reason}


def specs_of(workloads: list[WorkloadIn]) -> list[WorkloadSpec]:
    return [WorkloadSpec(name=one.name, vcpu=one.vcpu, memory_gb=one.memory_gb, os=one.os, count=one.count,
                         hours_per_month=one.hours_per_month,
                         disks=tuple(DiskSpec(disk.type, disk.size_gb, disk.count) for disk in one.disks),
                         traffic=one.traffic, environment=one.environment,
                         os_disk=DiskSpec(one.os_disk.type, one.os_disk.size_gb) if one.os_disk else None)
            for one in workloads]


def run_sizing(services: Services, workloads: list[WorkloadIn], *, region: str, headline: str, ahb: bool,
               families: list[str] | None, currency: str) -> Sizing:
    """The sizing of `sizing_calc` and `design_propose`, with their refusals."""
    store = store_of(services)
    try:
        catalog = load(region, services.settings.ms_agent_data_dir)
    except CatalogNotFound as failure:
        raise SkillError("region_not_supported", str(failure)) from None
    allowed = [family.upper() for family in families] if families else services.settings.vm_families
    try:
        return size_workloads(store, catalog, specs_of(workloads), region=region, headline=headline, ahb=ahb,
                              families=allowed, currency=currency)
    except NoSize as failure:
        raise SkillError("no_size", str(failure)) from None
    except ValueError as failure:
        raise SkillError("bad_request", str(failure)) from None


def estimate_result(services: Services, sizing: Sizing, *, title: str, made_by: str) \
        -> tuple[dict[str, Any], list[dict[str, Any]], list[Warning]]:
    """The estimate's part of an answer: sizes, totals, lines, assumptions, sources, the workbook link."""
    estimate = sizing.estimate
    warnings = list(sizing.warnings) + currency_warnings(estimate.currency)
    workbook: dict[str, Any] | None = None
    files: list[dict[str, Any]] = []
    if services.files is None:
        warnings.append(Warning(code="workbook_not_stored", message="No file store is configured; the estimate is "
                                                                    "in the answer, without a workbook."))
    else:
        data = build_workbook(estimate, sizing.workloads, made_by=made_by)
        stored = services.files.put(f"{title}.xlsx", MEDIA_TYPE, data)
        link = services.file_link(stored)
        files.append(link)
        workbook = link | {"expires_at": stored.expires_at} | ({"direct_url": stored.direct_url}
                                                              if stored.direct_url else {})
    headline = estimate.headline
    result = {
        "region": estimate.region,
        "currency": estimate.currency,
        "list_price_notice": LIST_PRICE_NOTICE,
        "fetched_at": estimate.fetched_at,
        "headline": {"pricing_model": headline, "label": LABELS[headline],
                     "monthly": float(estimate.total(headline)), "yearly": float(estimate.total(headline) * 12)},
        "workloads": [{"name": one.spec.name, "os": one.spec.os, "count": one.spec.count,
                       "hours_per_month": one.spec.hours_per_month, "vcpu": one.spec.vcpu,
                       "memory_gb": one.spec.memory_gb, "size": _size_of(one.choice.chosen, estimate.currency),
                       "alternatives": [_size_of(alternative, estimate.currency)
                                        for alternative in one.choice.alternatives],
                       "excluded": one.choice.excluded, "disks": one.disks}
                      for one in sizing.workloads],
        "totals": summary_rows(estimate),
        "lines": [line.as_dict(estimate.models) for line in estimate.lines],
        "assumptions": estimate.assumptions,
        "sources": [source.as_dict() for source in estimate.sources()],
        "vm_catalog": {"region": sizing.catalog.region, "source": sizing.catalog.source,
                       "generated": sizing.catalog.generated, "sizes": len(sizing.catalog.sizes)},
        "workbook": workbook,
    }
    return result, files, warnings


def answer(services: Services, request: SizingCalcRequest) -> Outcome:
    headline = request.pricing_models[0]
    sizing = run_sizing(services, request.workloads, region=request.region, headline=headline, ahb=request.ahb,
                        families=request.families, currency=request.currency)
    result, files, warnings = estimate_result(services, sizing, title=f"azure-estimate-{request.region}",
                                              made_by=f"the Microsoft vendor agent {services.version}")
    missing = any(sizing.estimate.missing(model) for model in sizing.estimate.models)
    return Outcome(result, warnings=warnings, files=files,
                   status="partial" if missing or result["workbook"] is None else "complete")


async def handle(request: Common, services: Services) -> Outcome:
    assert isinstance(request, SizingCalcRequest)
    return await asyncio.to_thread(answer, services, request)


SKILL = Skill(
    id="sizing_calc",
    name="Sizing calc",
    description=("Azure virtual machine sizes and managed disks for workloads (vCPU, memory, OS, hours, count, "
                 "region), with alternatives, list-price totals per pricing model and an Excel estimate. Code only."),
    input_model=SizingCalcRequest,
    handler=handle,
    tags=("microsoft", "azure", "vendor-agent/1", "data"),
    examples=('{"skill": "sizing_calc", "request": {"workloads": [{"name": "web servers", "vcpu": 4, '
              '"memory_gb": 16, "os": "linux", "count": 6}, {"name": "SQL servers", "vcpu": 8, "memory_gb": 64, '
              '"os": "windows", "count": 2}], "region": "uaenorth", "pricing_models": ["sp_3y"], "ahb": true}}',),
)
