"""`advice_explain`: answer a Microsoft question with citations.

The retriever finds passages of Microsoft documentation for the question; the model answers
from those passages only and names, for each claim, the passage it used. A citation that
points at no retrieved page is dropped, and an answer left without a citation is refused with
`no_citation`: the skill returns an error, not an answer.
"""

from __future__ import annotations

import json
import re
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from ms_agent.contract import Clock, Common, Outcome, SkillError, Usage, Warning
from ms_agent.knowledge.learn_mcp import LearnMcpError
from ms_agent.knowledge.retriever import Passage, canonical
from ms_agent.knowledge.sources import allowed_source
from ms_agent.skills.base import Services, Skill

PASSAGE_LIMIT = 8
QUOTE_LIMIT = 300

SYSTEM = """You are the Microsoft vendor agent of MAGIC, a presales assistant. You answer questions about Microsoft \
products, services and licensing for a solution architect or a seller.

Rules:
1. Answer only from the numbered passages given. Do not use any other knowledge. If the passages do not \
answer the question, say so plainly in "answer" and return an empty "citations" list.
2. Be complete before being brief: state every condition, prerequisite, limit and exception the passages give \
that bears on the question, including numbers, editions, regions and dates. Only then keep the wording short. \
Write in English.
3. Every claim needs a citation. A citation names the passage's "url" exactly as given, its "title", and a \
"quote": one sentence copied verbatim from that passage that supports the claim. Cite each page once; give \
its most relevant sentence.
4. Never invent a URL, a price, a date or a product name that the passages do not contain.
5. When two passages conflict, prefer the newer one (by the date or version it states) and say in "answer" that \
the sources differ and which one you followed.

Answer with one JSON object and nothing else:
{"answer": "<the answer, plain text, may use short paragraphs>", \
"citations": [{"url": "<url of a passage>", "title": "<its title>", "quote": "<verbatim sentence>"}]}"""


class AdviceExplainRequest(Common):
    question: str = Field(min_length=3, max_length=1000)
    part: dict[str, Any] | None = Field(default=None, description="The part the question is about, as context")


class Citation(BaseModel):
    model_config = ConfigDict(extra="ignore")

    url: str
    title: str = ""
    quote: str = ""


class Draft(BaseModel):
    """What the model is asked to return."""

    model_config = ConfigDict(extra="ignore")

    answer: str = Field(min_length=1)
    citations: list[Citation] = Field(default_factory=list)


def render(question: str, part: dict[str, Any] | None, passages: list[Passage]) -> str:
    """The user message: the question, the part as context, the numbered passages."""
    lines = [f"Question: {question.strip()}"]
    if part:
        lines.append("Context, the part the question is about (JSON): " + json.dumps(part, ensure_ascii=False)[:2000])
    lines.append("")
    lines.append("Passages:")
    for number, passage in enumerate(passages, start=1):
        lines.append(f"[{number}] title: {passage.title}")
        lines.append(f"    url: {passage.url}")
        lines.append(f"    text: {passage.text}")
        lines.append("")
    return "\n".join(lines)


def _squeeze(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip().lower()


def _verbatim(quote: str, passage: Passage) -> bool:
    return bool(quote.strip()) and _squeeze(quote) in _squeeze(passage.text)


async def handle(request: Common, services: Services) -> Outcome:
    assert isinstance(request, AdviceExplainRequest)
    clock = Clock()
    if services.retriever is None:
        raise SkillError("retriever_not_configured", "No documentation retriever is configured.")
    if services.model is None:
        raise SkillError("model_not_configured", "No chat model is configured: set the AZURE_OPENAI_* variables.")
    try:
        passages = await services.retriever.retrieve(request.question, limit=PASSAGE_LIMIT)
    except LearnMcpError as failure:
        raise SkillError("sources_unavailable", f"Microsoft Learn could not be searched: {failure}") from None
    # Only Microsoft documentation, pricing and licensing pages are evidence: never a forum answer, whatever
    # retriever found it (`knowledge/sources.py`).
    passages = [passage for passage in passages if allowed_source(passage.url)]
    if not passages:
        raise SkillError("no_sources", "No Microsoft documentation passage was found for the question.")

    completion = await services.model.complete_json(SYSTEM, render(request.question, request.part, passages))
    usage = Usage(prompt_tokens=completion.prompt_tokens, completion_tokens=completion.completion_tokens,
                  seconds=clock.seconds())
    try:
        draft = Draft.model_validate_json(completion.text)
    except ValidationError:
        raise SkillError("bad_model_output", "The model did not answer in the expected shape.", usage=usage) from None

    pages: dict[str, list[Passage]] = {}
    for passage in passages:
        pages.setdefault(canonical(passage.url), []).append(passage)
    # One citation per page: the model may cite the same page several times (the live agent cited one page
    # three times), and several passages may come from one page. The first verbatim quote is kept.
    merged: dict[str, dict[str, str]] = {}
    warnings: list[Warning] = []
    dropped = 0
    for citation in draft.citations:
        key = canonical(citation.url)
        found = pages.get(key)
        if not found or not allowed_source(citation.url):
            dropped += 1
            continue
        quote = citation.quote.strip()
        verbatim = any(_verbatim(quote, passage) for passage in found)
        held = merged.get(key)
        if held is None:
            merged[key] = {"url": found[0].url, "title": citation.title.strip() or found[0].title,
                           "quote": quote if verbatim else ""}
        elif verbatim and not held["quote"]:
            held["quote"] = quote
    citations = list(merged.values())
    for key, citation in merged.items():
        if not citation["quote"]:
            citation["quote"] = pages[key][0].text[:QUOTE_LIMIT].strip()
            warnings.append(Warning(code="quote_not_verbatim",
                                    message=f"The quote for {citation['url']} was not found in the passage; "
                                            "the passage's opening is given instead."))
    if dropped:
        warnings.append(Warning(code="citation_dropped",
                                message=f"{dropped} citation(s) pointed at no retrieved page and were dropped."))
    if not citations:
        raise SkillError("no_citation", "The model gave no citation that points at a retrieved Microsoft page, "
                                        "so no answer is returned.", usage=usage)

    usage.seconds = clock.seconds()
    passage_urls = list(dict.fromkeys(passage.url for passage in passages))
    return Outcome({"answer": draft.answer.strip(), "citations": citations, "passages_considered": len(passages),
                    "passage_urls": passage_urls}, usage=usage, warnings=warnings)


SKILL = Skill(
    id="advice_explain",
    name="Advice explain",
    description=("Answer a question about Microsoft products or licensing from Microsoft Learn, "
                 "with quotes and sources."),
    input_model=AdviceExplainRequest,
    handler=handle,
    tags=("microsoft", "vendor-agent/1", "data"),
    examples=('{"skill": "advice_explain", "request": {"question": "Which Microsoft 365 plans are required '
              'before a customer can buy Microsoft 365 Copilot?"}}',),
)
