"""`vendor_describe`: the agent profile.

MAGIC calls it with an empty request when an operator checks the agent, and reads `name` or
`vendor`, `summary`, `product_lines`, `can`, `region`, `data_date`, `agent_version`,
`maintained_by`, `endorsed_by_vendor`, `request_retention_days`, `contract_versions` and
`advisory` (`profile_of` in the platform's `vendors.py`).

The logo: MAGIC keeps a logo only when it is a plain SVG (`safe_svg`). It takes `logo_svg`, the SVG
inline, first; else it fetches `logo_url` from the card's own host. Both are given: `logo_svg` is
the text of `static/microsoft-logo.svg`, and `logo_url` is `/logo.svg`. `/logo.png` stays served for
anyone who wants the PNG; MAGIC would not keep it.
"""

from __future__ import annotations

from pathlib import Path

from ms_agent.contract import CONTRACT, Common, Outcome
from ms_agent.skills.base import Services, Skill

VENDOR = "Microsoft"
NAME = "Microsoft vendor agent"
SUMMARY = ("Microsoft answers from Microsoft Learn with sources; Azure infrastructure designs, sizing and list prices "
           "with an Excel estimate.")
PRODUCT_LINES = ("Azure", "Microsoft 365", "Microsoft 365 Copilot", "Microsoft Security", "Microsoft licensing")
# MAGIC shows at most four.
CAN = ("Design Azure infrastructure for workloads, with an Excel estimate",
       "Size Azure virtual machines and disks",
       "Give Azure list prices with source and date",
       "Answer questions from Microsoft Learn with citations")
REGION = "MEA"
MAINTAINER = "Mindware Cloud Unit"
# The logos, served by `main.py` without a key, like the card.
STATIC = Path(__file__).resolve().parents[1] / "static"
PNG_LOGO_PATH, PNG_LOGO_FILE = "/logo.png", STATIC / "microsoft-logo.png"
SVG_LOGO_PATH, SVG_LOGO_FILE = "/logo.svg", STATIC / "microsoft-logo.svg"
# Read as bytes and decoded, so the text is the file's exactly (no newline translation).
LOGO_SVG = SVG_LOGO_FILE.read_bytes().decode("utf-8")
ADVISORY = ("Answers are read live from Microsoft Learn. Prices are Microsoft retail list prices from the Azure Retail "
            "Prices API, refreshed nightly, not CSP, EA or MCA agreement prices. Designs cover Azure infrastructure "
            "only; licensing rules are not checked yet.")


class VendorDescribeRequest(Common):
    """Nothing beyond `request_id` and `role`."""


async def handle(request: Common, services: Services) -> Outcome:
    from ms_agent.skills import REGISTRY  # late: the registry imports this module

    return Outcome({
        "contract": CONTRACT,
        "contract_versions": [CONTRACT],
        "vendor": VENDOR,
        "name": NAME,
        "summary": SUMMARY,
        "product_lines": list(PRODUCT_LINES),
        "can": list(CAN),
        "region": REGION,
        "data_date": services.data_date(),
        "agent_version": services.version,
        "maintained_by": MAINTAINER,
        "endorsed_by_vendor": False,
        "request_retention_days": 0,
        "advisory": ADVISORY,
        "logo_svg": LOGO_SVG,
        "logo_url": services.settings.ms_agent_public_url.rstrip("/") + SVG_LOGO_PATH,
        "skills": [{"id": skill.id, "name": skill.name, "description": skill.description}
                   for skill in REGISTRY.values()],
        "knowledge": [{"source": "Microsoft Learn", "domain": "learn.microsoft.com", "kind": "live"},
                      {"source": "Azure Retail Prices API", "domain": "prices.azure.com", "kind": "nightly"}],
    })


SKILL = Skill(
    id="vendor_describe",
    name="Vendor describe",
    description="The agent profile: vendor, product lines, skills, agent version, data date.",
    input_model=VendorDescribeRequest,
    handler=handle,
    tags=("microsoft", "vendor-agent/1", "data"),
    examples=('{"skill": "vendor_describe", "request": {}}',),
)
