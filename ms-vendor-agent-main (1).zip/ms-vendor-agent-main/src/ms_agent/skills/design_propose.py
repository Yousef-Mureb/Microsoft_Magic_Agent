"""`design_propose`: a first Azure infrastructure design for workloads, with its estimate.

Scope at step 2: Azure infrastructure only. The design is the solution by role (compute, storage,
network, backup, disaster recovery), its assumptions, gaps and caveats, the estimate's totals and
the workbook. Every size and every number comes from the sizing and the price lookup (the same code
as `sizing_calc`). The model writes only the summary and the caveats, from the design's facts; a
summary with a number that is not among those facts is replaced by a plain one the code writes.
"""

from __future__ import annotations

import asyncio
import json
import re
from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from ms_agent.contract import Clock, Common, Outcome, Usage, Warning
from ms_agent.diagram.figure import make_figure
from ms_agent.diagram.model import Component, FigureDesign, zones_label
from ms_agent.knowledge.sources import allowed_source, urls_in
from ms_agent.pricing.lookup import LABELS, LIST_PRICE_NOTICE, PriceNotFound, price_for
from ms_agent.pricing.store import PriceStore
from ms_agent.regions import ACCESS_REQUEST_URL, REGION_PAIRS_URL, REGIONS_LIST_URL, Region, RegionFacts, load_regions
from ms_agent.settings import DATA_DIR
from ms_agent.sizing.baseline import DEFAULT_GATEWAY_CAPACITY_UNITS, Baseline, Quantities, baseline
from ms_agent.sizing.workloads import Sizing
from ms_agent.skills.base import Services, Skill
from ms_agent.skills.pricing_support import currency_field, region_field, store_of
from ms_agent.skills.sizing_calc import Commitment, WorkloadIn, estimate_result, run_sizing

Availability = Literal["single_zone", "zone_redundant", "with_dr"]

# Zones, restricted access and region pairs come from Microsoft Learn's regions list and region pairs pages,
# read into data/azure_regions.json by scripts/refresh_regions.py; a region not in it gets no zone claim.
AVAILABILITY_WORDS = {"single_zone": "in one zone", "zone_redundant": "spread across availability zones",
                      "with_dr": "spread across availability zones, with a disaster recovery region"}

SYSTEM = """You write the summary and the caveats of an Azure infrastructure design for a presales engineer. \
The design's facts are given as JSON: the sizes, counts, regions, totals and gaps were decided by code and are \
final.

Rules:
1. Use only the facts given. Do not add a size, a service, a price, a number or a date that is not in them.
2. "summary": three to six sentences in English: what is deployed where, how it meets the availability need, the \
leading pricing model's monthly total with its currency, and that prices are list prices.
3. "caveats": short sentences on what the buyer must check or decide: each gap, Azure Hybrid Benefit eligibility \
when it is applied, a count raised for zones, list prices against the customer's agreement.

Answer with one JSON object and nothing else: {"summary": "<text>", "caveats": ["<sentence>", ...]}"""


class DesignProposeRequest(Common):
    workloads: list[WorkloadIn] = Field(min_length=1, max_length=50)
    region: str = region_field()  # type: ignore[assignment]
    availability: Availability = Field(
        default="single_zone",
        description="single_zone; zone_redundant (machines across availability zones, at least two per workload); "
                    "with_dr (zone-redundant plus a disaster recovery region)")
    dr_region: str | None = Field(default=None, pattern=r"^[a-z0-9]+$", max_length=40,
                                  description="Disaster recovery region for with_dr; default the region's pair")
    pricing_models: list[Commitment] = Field(
        default=["payg"], min_length=1, max_length=5,
        description="The first is the model sizes are ranked on and the headline total")
    ahb: bool = Field(default=False, description="Azure Hybrid Benefit for every Windows machine")
    families: list[str] | None = Field(
        default=None, max_length=12,
        description="VM families allowed, e.g. ['D', 'E']; default D, E, F, B (B for dev_test only)")
    currency: str = currency_field()  # type: ignore[assignment]
    third_party_apis: bool = Field(default=False, description="The HTTP workloads publish APIs to third parties: "
                                                              "API Management instead of Application Gateway")
    connectivity: Literal["none", "vpn", "expressroute"] = Field(
        default="none", description="A private connection from the customer network (drawn, not priced)")
    gateway_capacity_units: int = Field(
        default=DEFAULT_GATEWAY_CAPACITY_UNITS, ge=0, le=1000,
        description="Application Gateway WAF v2 capacity units charged every hour; default 2, a pilot's load")


# A private connection is drawn and named, not priced, at this step: (service name, icon kind, what it is).
CONNECTIONS = {"vpn": ("Azure VPN Gateway", "vpn_gateway", "site-to-site VPN from the customer network"),
               "expressroute": ("Azure ExpressRoute", "expressroute",
                                "private circuit from the customer network")}
DRAWN_NOT_PRICED = "drawn, not priced"


class Narrative(BaseModel):
    model_config = ConfigDict(extra="ignore")

    summary: str = Field(min_length=1)
    caveats: list[str] = Field(default_factory=list)


def _zones(region: Region | None, availability: str) -> str:
    if availability == "single_zone":
        return "one zone"
    if region is None:
        return "zones not confirmed for the region"
    return region.zones_text() if region.availability_zones else "one zone: the region has no availability zones"


def region_facts(facts: RegionFacts, *names: str | None) -> dict[str, Any]:
    """The region facts the design rests on, with their sources, for the answer to cite."""
    known = {name: vars(facts.get(name)) for name in names if name and facts.get(name)}
    return {"regions": known, "sources": list(facts.sources)}


def region_caveats(facts: RegionFacts, request: DesignProposeRequest, dr_region: str | None) -> list[str]:
    """What the region facts mean for the buyer, each with its source page."""
    caveats = []
    primary = facts.get(request.region)
    if request.availability != "single_zone":
        if primary is None:
            caveats.append(f"Availability zones in {request.region} were not confirmed from Microsoft Learn's regions "
                           "list.")
        elif not primary.availability_zones:
            caveats.append(f"{primary.display_name} has no availability zones ({REGIONS_LIST_URL}), so the machines "
                           "cannot be spread across zones there.")
    dr = facts.get(dr_region) if dr_region else None
    if request.availability == "with_dr" and dr is not None and dr.restricted_access:
        caveats.append(f"{dr.display_name} is a restricted-access region ({REGIONS_LIST_URL}): the subscription needs "
                       f"an access request before it can be used for disaster recovery ({ACCESS_REQUEST_URL}).")
    read = facts.sources[0]["read_at"][:10] if facts.sources else "an unknown date"
    caveats.append(f"Availability zones and region pairs are from Microsoft Learn ({REGIONS_LIST_URL}, "
                   f"{REGION_PAIRS_URL}), read on {read}.")
    return caveats


def zones_used(count: int, region: Region | None, availability: str) -> list[int]:
    """The zones a workload's machines go in: spread over the region's zones, one machine per zone in turn."""
    if availability == "single_zone" or region is None or not region.availability_zones:
        return []
    return list(range(1, min(count, region.availability_zones) + 1))


ROLES = ("compute", "storage", "network", "security", "monitoring", "backup", "dr")
ENTRY_NAMES = {"app_gateway": "Application Gateway WAF v2", "api_management": "API Management",
               "load_balancer": "Standard Load Balancer"}


def solution_of(core: Core, request: DesignProposeRequest) -> dict[str, list[dict[str, Any]]]:
    """The design by role. Each item says whether it is priced and how it is drawn: `kind` (its icon),
    `placement` (where in the diagram; absent when it is not a node of its own), and for machines the zones used
    and the front door (`entry`) they are reached through."""
    facts, sizing = core.regions, core.sizing
    zones = _zones(facts.get(request.region), request.availability)
    solution: dict[str, list[dict[str, Any]]] = {role: [] for role in ROLES}
    for one in sizing.workloads:
        entry = {"http": core.front, "tcp": "load_balancer"}.get(one.spec.traffic) or ""
        solution["compute"].append({
            "workload": one.spec.name, "service": "Azure Virtual Machines", "size": one.choice.chosen.size.name,
            "count": one.spec.count, "os": one.spec.os, "traffic": one.spec.traffic,
            "environment": one.spec.environment, "region": request.region, "zones": zones,
            "zones_used": zones_used(one.spec.count, facts.get(request.region), request.availability),
            "zones_source": REGIONS_LIST_URL, "hours_per_month": one.spec.hours_per_month,
            "reason": one.choice.chosen.reason, "priced": True, "kind": "vm", "placement": "app",
            "web": bool(entry), "entry": entry})
        solution["storage"] += [{"workload": one.spec.name, "service": "Azure Managed Disks", "role": disk["role"],
                                 "type": disk["type"], "tier": disk["tier"], "size_gib": disk["tier_gib"],
                                 "per_machine": disk["count_per_machine"], "redundancy": "LRS, in the machine's zone",
                                 "priced": True, "kind": "disk"} for disk in one.disks]
    # The virtual network is the diagram's box, not a node.
    solution["network"].append({"service": "Azure Virtual Network", "item": "one virtual network, a subnet per tier, "
                                "network security groups", "priced": False, "note": "no charge for the network itself",
                                "kind": "vnet"})
    solution["security"].append({"service": "Microsoft Entra ID", "name": "Microsoft Entra ID", "item": "identity "
                                 "for administrators and workloads", "priced": False,
                                 "note": "no charge: Microsoft Entra ID Free comes with the subscription",
                                 "kind": "entra_id", "placement": "shared", "detail": "identity"})
    if request.connectivity != "none":
        service, kind, what = CONNECTIONS[request.connectivity]
        solution["network"].append({"service": service, "name": service, "item": what, "priced": False,
                                    "status": DRAWN_NOT_PRICED, "kind": kind, "placement": "front",
                                    "detail": f"to the customer network ({DRAWN_NOT_PRICED})"})
        solution["network"].append({"service": "Customer network", "name": "Customer network", "priced": False,
                                    "note": "no charge: the customer's side", "kind": "on_premises",
                                    "placement": "outside", "detail": "on-premises"})
    for item in core.baseline.items:
        copy = dict(item)
        solution[copy.pop("role")].append(copy)
    for machine in core.dr_machines:
        solution["dr"].append(machine)
    return solution


def figure_design(solution: dict[str, list[dict[str, Any]]], request: DesignProposeRequest, facts: RegionFacts,
                  dr_region: str | None) -> FigureDesign:
    """The compact `design` a diagram is drawn from: every solution item that has a placement, and the users."""
    primary, dr = facts.get(request.region), facts.get(dr_region) if dr_region else None
    components = [Component(kind="users", name="Users", detail="over the internet", placement="outside")]
    for items in solution.values():
        for item in items:
            if not item.get("placement"):
                continue
            size = str(item.get("size", "")).removeprefix("Standard_")
            if item["kind"] == "vm":
                name = item.get("workload") or item["service"]
                detail = f"{item['count']} × {size}" + (f", {zones_label(item['zones_used'])}"
                                                        if item.get("zones_used") else "")
                if item["placement"] == "dr":
                    detail += ", created at failover"
                components.append(Component(kind="vm", name=name, detail=detail, placement=item["placement"],
                                            zones=item.get("zones_used", []), size=size, count=item["count"],
                                            web=bool(item.get("web")), entry=item.get("entry", "")))
            else:
                components.append(Component(kind=item["kind"], name=item.get("name") or item["service"],
                                            detail=item.get("detail", ""), placement=item["placement"],
                                            zones=item.get("zones_used", [])))
    zones = primary.availability_zones if primary and request.availability != "single_zone" else 0
    return FigureDesign(region=request.region, region_name=primary.display_name if primary else "",
                        availability=request.availability, zones=zones,
                        dr_region=dr_region if request.availability == "with_dr" else None,
                        dr_region_name=dr.display_name if dr and request.availability == "with_dr" else "",
                        components=components)


def gaps_of(solution: dict[str, list[dict[str, Any]]], core: Core) -> list[str]:
    """What the design names but does not price, and every meter the store did not hold, by name."""
    gaps = [f"{'Drawn, not priced' if item.get('status') == DRAWN_NOT_PRICED else 'Not priced'}: "
            f"{item['service']} ({item['item']})." for items in solution.values() for item in items
            if not item.get("priced") and item.get("item") and not item.get("note", "").startswith("no charge")
            and item.get("placement") != "dr"]
    gaps += [f"Not priced: {missing}" for missing in core.baseline.missing]
    if core.dr_problem:
        gaps.append(core.dr_problem)
    return gaps


def front_door_caveats(core: Core) -> list[str]:
    """Why the front door is what it is: the code's words, kept whatever the model writes."""
    caveats = []
    if core.front == "app_gateway":
        caveats.append("The HTTP workloads are published through Application Gateway WAF v2: layer-7 routing, TLS "
                       "termination and a Web Application Firewall. A Standard Load Balancer works at layer 4 and "
                       "has no Web Application Firewall, so it is used only for non-HTTP traffic.")
    elif core.front == "api_management":
        caveats.append("The APIs are published to third parties through API Management: keys, quotas, policies and "
                       "a developer portal. Put Application Gateway WAF v2 or Front Door in front of it if a Web "
                       "Application Firewall is required.")
    if any(one.spec.traffic == "tcp" for one in core.sizing.workloads):
        caveats.append("Non-HTTP traffic from outside reaches its workloads through a Standard Load Balancer "
                       "(layer 4).")
    caveats += [machine["note"] for machine in core.dr_machines if machine.get("substituted")]
    return caveats


def plain_summary(sizing: Sizing, request: DesignProposeRequest) -> str:
    estimate = sizing.estimate
    machines = "; ".join(f"{one.spec.count} × {one.choice.chosen.size.name} ({one.spec.os}) for {one.spec.name}"
                         for one in sizing.workloads)
    total = estimate.total(estimate.headline)
    return (f"Azure infrastructure in {request.region}, {AVAILABILITY_WORDS[request.availability]}: {machines}. "
            f"{LABELS[estimate.headline]}: {total:.2f} {estimate.currency} a month, {total * 12:.2f} a year, at "
            f"Microsoft list prices.")


def plain_caveats(sizing: Sizing, request: DesignProposeRequest, raised: list[str], gaps: list[str]) -> list[str]:
    caveats = [LIST_PRICE_NOTICE]
    if raised:
        caveats.append(f"Zone redundancy needs two machines or more; the count was raised to two for: "
                       f"{', '.join(raised)}.")
    if request.ahb and any(one.spec.os == "windows" for one in sizing.workloads):
        caveats.append("Azure Hybrid Benefit needs eligible Windows Server licences with Software Assurance or "
                       "subscriptions.")
    if gaps:
        caveats.append("Items named but not priced are listed under gaps.")
    return caveats


NUMBER = re.compile(r"\d[\d,]*(?:\.\d+)?")


def numbers_in(text: str) -> set[str]:
    """The numbers of a text, without thousands separators or trailing zeros: `1,746.10` -> `1746.1`."""
    found = set()
    for raw in NUMBER.findall(text):
        number = raw.replace(",", "")
        found.add(number.rstrip("0").rstrip(".") if "." in number else number)
    return found


def invented(narrative: Narrative, facts_text: str) -> set[str]:
    """Numbers in the model's words that are not among the facts'."""
    return numbers_in(" ".join([narrative.summary, *narrative.caveats])) - numbers_in(facts_text)


async def narrate(services: Services, facts_text: str) -> tuple[Narrative | None, Usage | None, Warning | None]:
    """The model's summary and caveats, or None with the warning that says why the plain ones are used."""
    if services.model is None:
        return None, None, Warning(code="narrative_not_written",
                                   message="No chat model is configured; the summary is the plain one written by the "
                                           "code.")
    try:
        completion = await services.model.complete_json(SYSTEM, facts_text)
    except Exception as failure:  # the design stands without the model's words
        return None, None, Warning(code="narrative_not_written",
                                   message=f"The chat model failed ({type(failure).__name__}); the summary is the "
                                           "plain one written by the code.")
    usage = Usage(prompt_tokens=completion.prompt_tokens, completion_tokens=completion.completion_tokens)
    try:
        narrative = Narrative.model_validate_json(completion.text)
    except ValidationError:
        return None, usage, Warning(code="narrative_replaced",
                                    message="The model's summary was not used because it was not in the expected "
                                            "shape.")
    extra = invented(narrative, facts_text)
    if extra:
        return None, usage, Warning(code="narrative_replaced",
                                    message="The model's summary was not used because it held numbers that are not "
                                            f"in the design: {', '.join(sorted(extra))}.")
    return narrative, usage, None


@dataclass
class Core:
    """The design's decisions, before any word is written: sizes, the front door, the priced baseline services,
    the DR region and its recovery machines, the region facts."""

    sizing: Sizing
    front: str | None
    baseline: Baseline
    dr_region: str | None
    dr_machines: list[dict[str, Any]]
    dr_problem: str | None
    regions: RegionFacts
    raised: list[str]


def _priced_in(store: PriceStore, size: str, region: str, os_name: str, currency: str) -> Decimal | None:
    try:
        return price_for(store, size, region, "windows" if os_name == "windows" else "linux", "payg", currency).value
    except PriceNotFound:
        return None


def recovery_machines(store: PriceStore, sizing: Sizing, dr_region: str, currency: str) \
        -> tuple[list[dict[str, Any]], str | None]:
    """The machines Azure Site Recovery creates at failover: the same size when the DR region prices it, else the
    cheapest size of the same family, at least as large, that it does price (UAE Central prices no v7 size)."""
    machines, problems = [], []
    for one in sizing.workloads:
        size = one.choice.chosen.size
        chosen, note, substituted = size, "billed only while running after a failover or a test", False
        if _priced_in(store, size.name, dr_region, one.spec.os, currency) is None:
            candidates = []
            for other in sizing.catalog.sizes:
                if other.family != size.family or other.vcpu < size.vcpu or other.memory_gib < size.memory_gib \
                        or other.arm64 or other.constrained_cores:
                    continue
                cost = _priced_in(store, other.name, dr_region, one.spec.os, currency)
                if cost is not None:
                    candidates.append((cost, -other.generation, other.vcpu, other.memory_gib, other.name, other))
            if not candidates:
                problems.append(f"{dr_region} has no price for {size.name} or a same-family size at least as large; "
                                f"the recovery machines of {one.spec.name} are not chosen.")
                continue
            chosen, substituted = min(candidates)[-1], True
            note = (f"{dr_region} has no list price for {size.short_name}; {chosen.short_name}, the cheapest "
                    f"{size.family}-series size at least as large that it prices, is used for the recovery machines "
                    f"of {one.spec.name}.")
        machines.append({"workload": one.spec.name, "service": "Azure Virtual Machines (recovery, created at "
                         "failover)", "size": chosen.name, "count": one.spec.count, "region": dr_region,
                         "priced": False, "note": note, "substituted": substituted, "kind": "vm", "placement": "dr"})
    return machines, " ".join(problems) or None


def design_core(services: Services, request: DesignProposeRequest) -> Core:
    """Size the workloads, choose the front door by traffic, price the baseline services into the estimate and,
    with a DR region (the region pair by default), choose the recovery machines. Raises `SkillError`."""
    raised = [one.name for one in request.workloads if request.availability != "single_zone" and one.count < 2]
    workloads = [one.model_copy(update={"count": 2}) if one.name in raised else one for one in request.workloads]
    regions = load_regions(DATA_DIR)
    store = store_of(services)
    sizing = run_sizing(services, workloads, region=request.region, headline=request.pricing_models[0],
                        ahb=request.ahb, families=request.families, currency=request.currency)
    traffic = {one.spec.traffic for one in sizing.workloads}
    front = ("api_management" if request.third_party_apis else "app_gateway") if "http" in traffic else None
    dr_region, dr_problem, machines = None, None, []
    if request.availability == "with_dr":
        primary = regions.get(request.region)
        dr_region = request.dr_region or (primary.paired_region if primary else None)
        if dr_region:
            machines, dr_problem = recovery_machines(store, sizing, dr_region, request.currency)
        else:
            dr_problem = f"No disaster recovery region is paired with {request.region}; name one."
    priced = baseline(store, sizing.workloads, region=request.region, dr_region=dr_region, front=front,
                      tcp="tcp" in traffic, models=sizing.estimate.models, currency=request.currency,
                      quantities=Quantities(gateway_capacity_units=request.gateway_capacity_units))
    sizing.estimate.lines += priced.lines
    sizing.estimate.assumptions += priced.assumptions
    if request.connectivity != "none":
        service, _, what = CONNECTIONS[request.connectivity]
        # In the workbook too: on the Summary sheet and the Assumptions sheet, by name.
        sizing.estimate.not_priced.append(f"{service}: {what}; {DRAWN_NOT_PRICED} (its meters are not read at this "
                                          "step)")
        sizing.estimate.assumptions.append(f"Drawn, not priced: {service} ({what}); the estimate leaves it out.")
    sizing.warnings += [Warning(code="price_missing", message=missing) for missing in priced.missing]
    return Core(sizing, front, priced, dr_region, machines, dr_problem, regions, raised)


async def handle(request: Common, services: Services) -> Outcome:
    assert isinstance(request, DesignProposeRequest)
    clock = Clock()
    core = await asyncio.to_thread(design_core, services, request)
    sizing, dr_region, dr_problem = core.sizing, core.dr_region, core.dr_problem
    regions, raised = core.regions, core.raised
    result, files, warnings = await asyncio.to_thread(
        estimate_result, services, sizing, title=f"azure-design-{request.region}",
        made_by=f"the Microsoft vendor agent {services.version}")
    solution = solution_of(core, request)
    gaps = gaps_of(solution, core)
    caveats = plain_caveats(sizing, request, raised, gaps)
    # The region and front-door caveats are the code's, with their sources; they stay whatever the model writes.
    cited = front_door_caveats(core) + region_caveats(regions, request, dr_region)
    facts_of_regions = region_facts(regions, request.region, dr_region)
    if raised:
        warnings.append(Warning(code="count_raised_for_zones",
                                message=f"Raised to two machines for zone redundancy: {', '.join(raised)}."))
    facts = {"region": request.region, "availability": AVAILABILITY_WORDS[request.availability],
             "dr_region": dr_region, "solution": solution, "headline": result["headline"],
             "totals": result["totals"], "currency": request.currency, "gaps": gaps,
             "assumptions": result["assumptions"], "list_price_notice": LIST_PRICE_NOTICE, "count_raised": raised,
             "region_facts": facts_of_regions, "region_caveats": cited}
    facts_text = json.dumps(facts, ensure_ascii=False)
    narrative, usage, problem = await narrate(services, facts_text)
    if problem:
        warnings.append(problem)
    summary = narrative.summary.strip() if narrative else plain_summary(sizing, request)
    if narrative:
        # A caveat that cites a page which may not be evidence (a forum answer) is not used.
        written = [one.strip() for one in narrative.caveats
                   if one.strip() and all(allowed_source(url) for url in urls_in(one))]
        if len(written) < len([one for one in narrative.caveats if one.strip()]):
            warnings.append(Warning(code="caveat_dropped", message="A caveat that cited a page that is not "
                                                                    "Microsoft documentation, pricing or "
                                                                    "licensing was dropped."))
        caveats = written or caveats
    caveats += [one for one in cited if one not in caveats]
    if usage is not None:
        usage.seconds = clock.seconds()
    design = figure_design(solution, request, regions, dr_region)
    figure = await asyncio.to_thread(make_figure, services, design, title=f"azure-diagram-{request.region}")
    files += figure.files
    warnings += figure.warnings
    result = {"summary": summary, "availability": request.availability, "dr_region": dr_region,
              "solution": solution, "gaps": gaps, "caveats": caveats, "region_facts": facts_of_regions,
              "design": design.model_dump(), "diagram": figure.result()["diagram"],
              "not_priced": [{"service": item["service"], "status": item["status"], "item": item["item"]}
                             for items in solution.values() for item in items
                             if item.get("status") == DRAWN_NOT_PRICED],
              "diagram_caption": figure.caption} | result
    # Items named but not priced (load balancer, backup) are expected gaps; a missing price, a DR region that
    # could not be sized or a missing workbook make the answer partial.
    incomplete = dr_problem is not None or result["workbook"] is None \
        or any(sizing.estimate.missing(model) for model in sizing.estimate.models)
    return Outcome(result, usage=usage, warnings=warnings, files=files,
                   status="partial" if incomplete else "complete")


SKILL = Skill(
    id="design_propose",
    name="Design propose",
    description=("A first Azure infrastructure design for workloads: services and sizes by role (compute, storage, "
                 "network, backup, disaster recovery), availability, assumptions, gaps and caveats, list-price "
                 "totals per pricing model, and the estimate as an Excel link."),
    input_model=DesignProposeRequest,
    handler=handle,
    tags=("microsoft", "azure", "vendor-agent/1", "design"),
    examples=('{"skill": "design_propose", "request": {"workloads": [{"name": "web servers", "vcpu": 4, '
              '"memory_gb": 16, "os": "linux", "count": 6}, {"name": "SQL servers", "vcpu": 8, "memory_gb": 64, '
              '"os": "windows", "count": 2}], "region": "uaenorth", "availability": "zone_redundant", '
              '"pricing_models": ["sp_3y"], "ahb": true}}',),
)
