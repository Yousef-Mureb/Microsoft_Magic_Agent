"""Structured JSON logs.

Every skill call is logged once, with the request number, the skill, the duration, the token
counts and the outcome. The request body is never logged: a question may contain a
customer's words, and MAGIC's contract says the vendor keeps nothing of them.
"""

from __future__ import annotations

import json
import logging
import sys
from datetime import UTC, datetime
from typing import Any

LOGGER_NAME = "ms_agent"


class JsonFormatter(logging.Formatter):
    """One JSON object per line: time, level, message and whatever `extra` fields were given."""

    RESERVED = set(vars(logging.LogRecord("", 0, "", 0, "", (), None)).keys()) | {"message", "asctime"}

    def format(self, record: logging.LogRecord) -> str:
        line: dict[str, Any] = {
            "time": datetime.fromtimestamp(record.created, tz=UTC).isoformat(timespec="milliseconds"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        for key, value in record.__dict__.items():
            if key not in self.RESERVED and not key.startswith("_"):
                line[key] = value
        if record.exc_info:
            line["exception"] = self.formatException(record.exc_info)
        return json.dumps(line, default=str, ensure_ascii=False)


def configure_logging(level: str = "INFO") -> logging.Logger:
    """Send the agent's logs and uvicorn's to standard output as JSON lines."""
    root = logging.getLogger()
    # Added once per process; other handlers (a test's capture, for example) are left in place.
    if not any(isinstance(existing.formatter, JsonFormatter) for existing in root.handlers):
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(JsonFormatter())
        root.addHandler(handler)
    root.setLevel(level.upper())
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
        logging.getLogger(name).handlers = []
        logging.getLogger(name).propagate = True
    return logging.getLogger(LOGGER_NAME)


def log_call(skill: str, *, request_id: str | None, status: str, seconds: float, prompt_tokens: int = 0,
             completion_tokens: int = 0, refusal: str | None = None) -> None:
    """The one log line of a skill call. No field of the request is written, only its number."""
    logging.getLogger(LOGGER_NAME).info(
        "skill call",
        extra={"request_id": request_id, "skill": skill, "status": status, "duration_ms": round(seconds * 1000),
               "prompt_tokens": prompt_tokens, "completion_tokens": completion_tokens, "refusal": refusal},
    )
