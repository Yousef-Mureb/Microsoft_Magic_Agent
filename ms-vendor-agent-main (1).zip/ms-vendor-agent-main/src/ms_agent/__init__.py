"""Microsoft vendor agent for MAGIC: the `vendor-agent/1` contract over A2A."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("ms-vendor-agent")
except PackageNotFoundError:  # pragma: no cover - only when the package is not installed
    __version__ = "0.0.0"
