"""Azure OpenAI chat and embeddings through the official `openai` SDK.

The endpoint and the deployment names come from the environment. With `AZURE_OPENAI_API_KEY` set,
the key is sent; with it empty, the agent signs in with a managed identity:
`azure.identity.DefaultAzureCredential` for the user-assigned identity `AZURE_CLIENT_ID`, and a
bearer token for the scope `https://cognitiveservices.azure.com/.default`, so the deployed app holds
no key. The identity needs the role Cognitive Services OpenAI User on the Azure OpenAI account.

Reasoning models (for example the `gpt-6.1-sol` deployment) reject sampling parameters: a
`temperature` other than the default, `top_p`, and the old `max_tokens` all answer HTTP 400. So a
chat request carries none of them. A token limit, when one is set, goes in
`max_completion_tokens`, which every current chat model accepts. `chat_arguments` is the one place
the request is built, and the tests assert on what it sends.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Protocol

import httpx
from openai import AsyncAzureOpenAI

from ms_agent.settings import Settings

COGNITIVE_SERVICES_SCOPE = "https://cognitiveservices.azure.com/.default"

# Parameters a chat request must never carry: reasoning models refuse them with HTTP 400.
FORBIDDEN_CHAT_PARAMETERS = frozenset({"temperature", "top_p", "max_tokens"})


@dataclass(frozen=True)
class Completion:
    """What one chat call gave back: the text and the tokens it cost."""

    text: str
    prompt_tokens: int = 0
    completion_tokens: int = 0


class ChatModel(Protocol):
    """What a skill needs from a model: one JSON answer to a system and a user message."""

    async def complete_json(self, system: str, user: str) -> Completion: ...


def chat_arguments(deployment: str, system: str, user: str, *,
                   max_completion_tokens: int | None = None) -> dict[str, Any]:
    """The arguments of one chat completion: no sampling parameters, and a token limit only as
    `max_completion_tokens`."""
    arguments: dict[str, Any] = {
        "model": deployment,
        "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
        "response_format": {"type": "json_object"},
    }
    if max_completion_tokens is not None:
        arguments["max_completion_tokens"] = max_completion_tokens
    assert not FORBIDDEN_CHAT_PARAMETERS & arguments.keys()
    return arguments


def managed_identity_token_provider(client_id: str | None) -> Callable[[], str]:
    """Bearer tokens for Azure OpenAI from the user-assigned managed identity `client_id`. The credential
    caches the token and renews it before it expires."""
    from azure.identity import DefaultAzureCredential, get_bearer_token_provider

    credential = DefaultAzureCredential(managed_identity_client_id=client_id or None)
    return get_bearer_token_provider(credential, COGNITIVE_SERVICES_SCOPE)


class AzureOpenAIClient:
    """The real model. One instance per process; the SDK keeps its own connection pool."""

    def __init__(self, *, endpoint: str, api_version: str, chat_deployment: str, api_key: str | None = None,
                 token_provider: Callable[[], str] | None = None, embedding_deployment: str | None = None,
                 max_completion_tokens: int | None = None, http_client: httpx.AsyncClient | None = None) -> None:
        # A key, or a token provider (managed identity); `http_client` exists for the tests, which read the
        # request off the wire.
        if not api_key and token_provider is None:
            raise ValueError("Give an API key or a token provider.")
        self._client = AsyncAzureOpenAI(azure_endpoint=endpoint, api_key=api_key or None,
                                        azure_ad_token_provider=None if api_key else token_provider,
                                        api_version=api_version, http_client=http_client)
        self._chat_deployment = chat_deployment
        self._embedding_deployment = embedding_deployment
        self._max_completion_tokens = max_completion_tokens

    @classmethod
    def from_settings(cls, settings: Settings) -> AzureOpenAIClient | None:
        """The client, or None when the environment does not configure a model. Without a key, the managed
        identity `AZURE_CLIENT_ID` (or, when that is empty, whatever `DefaultAzureCredential` finds)."""
        if not settings.model_configured:
            return None
        assert settings.azure_openai_endpoint and settings.azure_openai_chat_deployment
        key = settings.azure_openai_api_key.get_secret_value() if settings.azure_openai_api_key else ""
        provider = None if key else managed_identity_token_provider(settings.azure_client_id)
        return cls(endpoint=settings.azure_openai_endpoint, api_key=key or None, token_provider=provider,
                   api_version=settings.azure_openai_api_version, chat_deployment=settings.azure_openai_chat_deployment,
                   embedding_deployment=settings.azure_openai_embedding_deployment,
                   max_completion_tokens=settings.azure_openai_max_completion_tokens)

    async def complete_json(self, system: str, user: str) -> Completion:
        response = await self._client.chat.completions.create(
            **chat_arguments(self._chat_deployment, system, user, max_completion_tokens=self._max_completion_tokens))
        choice = response.choices[0] if response.choices else None
        text = (choice.message.content or "") if choice and choice.message else ""
        usage = response.usage
        return Completion(text=text, prompt_tokens=usage.prompt_tokens if usage else 0,
                          completion_tokens=usage.completion_tokens if usage else 0)

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Embeddings for step 2 (Azure AI Search). Not used by any step 1 skill."""
        if not self._embedding_deployment:
            raise RuntimeError("No embedding deployment is configured: set AZURE_OPENAI_EMBEDDING_DEPLOYMENT.")
        response = await self._client.embeddings.create(model=self._embedding_deployment, input=texts)
        return [item.embedding for item in response.data]
