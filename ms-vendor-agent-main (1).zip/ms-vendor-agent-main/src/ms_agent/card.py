"""The agent card, built from the skill registry.

Its structure copies the Lenovo agent card MAGIC already reads: `supportedInterfaces` (JSON-RPC
and HTTP+JSON), `capabilities` with the extension `urn:magic:vendor-agent:1` carrying one JSON
schema per skill, `securitySchemes` with `x-api-key`, and `skills[]` with id, name, description,
tags and examples. MAGIC fetches it, without a key, from `/.well-known/agent-card.json`.
"""

from __future__ import annotations

from typing import Any

from ms_agent.auth import HEADER
from ms_agent.settings import Settings
from ms_agent.skills.base import Skill

EXTENSION = "urn:magic:vendor-agent:1"
JSONRPC_PATH = "/a2a/microsoft"
REST_PATH = "/a2a/microsoft/rest"
NAME = "Microsoft vendor agent"
DESCRIPTION = ("Microsoft vendor agent for MAGIC: answers about Microsoft products and licensing from Microsoft "
               "Learn, with quotes and sources. Contract vendor-agent/1: send a data part "
               '{"skill": <skill id>, "request": {...}}.')
INPUT_MODES = ["application/json", "text/plain"]
OUTPUT_MODES = ["application/json"]


def schema_of(skill: Skill) -> dict[str, Any]:
    """The skill's input schema as the card carries it: Pydantic's JSON schema without its title."""
    schema = skill.input_model.model_json_schema()
    schema.pop("title", None)
    return schema


def build_card(settings: Settings, skills: dict[str, Skill], version: str) -> dict[str, Any]:
    base = settings.ms_agent_public_url.rstrip("/")
    return {
        "name": NAME,
        "description": DESCRIPTION,
        "supportedInterfaces": [
            {"url": base + JSONRPC_PATH, "protocolBinding": "JSONRPC", "protocolVersion": "1.0"},
            {"url": base + REST_PATH, "protocolBinding": "HTTP+JSON", "protocolVersion": "1.0"},
        ],
        "provider": {"url": base, "organization": "Mindware"},
        "version": version,
        "capabilities": {
            # Step 1 answers within one request; streaming and push notifications are step 2 extension points.
            "streaming": False,
            "pushNotifications": False,
            "extensions": [{
                "uri": EXTENSION,
                "description": "Input schema of every skill (vendor-agent/1)",
                "params": {"schemas": {skill.id: schema_of(skill) for skill in skills.values()}},
            }],
            "extendedAgentCard": False,
        },
        "securitySchemes": {
            "apiKey": {"apiKeySecurityScheme": {"description": "Client key, given by the agent's admin",
                                                "location": "header", "name": HEADER}},
        },
        "securityRequirements": [{"schemes": {"apiKey": {}}}],
        "defaultInputModes": list(INPUT_MODES),
        "defaultOutputModes": list(OUTPUT_MODES),
        "skills": [
            {"id": skill.id, "name": skill.name, "description": skill.description, "tags": list(skill.tags),
             "examples": list(skill.examples), "inputModes": list(INPUT_MODES), "outputModes": list(OUTPUT_MODES)}
            for skill in skills.values()
        ],
    }
