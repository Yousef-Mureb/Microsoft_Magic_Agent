"""The FastAPI application: the A2A endpoints, the health route and the agent card.

Routes:
- `POST /a2a/microsoft`       JSON-RPC binding of A2A 1.0: `SendMessage`, `GetTask`, `CancelTask`. This is
                              the one MAGIC calls.
- `POST /a2a/microsoft/rest`  HTTP+JSON binding: the data part in, the envelope out. For `curl` and the
                              golden run.
- `GET /healthz`
- `GET /.well-known/agent-card.json`  the card, where MAGIC looks; `/.well-known/agent.json` serves the same.
- `GET /files/{id}`           a file the agent made (the estimate workbook), for 24 hours, with the key.
- `GET /logo.svg`             the vendor logo, SVG, without a key (`logo_url` of `vendor_describe`).
- `GET /logo.png`             the same logo as PNG, without a key; MAGIC keeps only SVG logos.

Start it with `uvicorn ms_agent.main:create_app --factory`.
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from collections import OrderedDict
from datetime import UTC, datetime
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, Response
from pydantic import ValidationError
from sqlalchemy.exc import SQLAlchemyError

from ms_agent import __version__
from ms_agent.auth import KeyRing
from ms_agent.card import JSONRPC_PATH, REST_PATH, build_card
from ms_agent.contract import Answer, Clock, Envelope, SkillError, completed, refused, validation_message
from ms_agent.files import FileStore, file_store_from_settings
from ms_agent.knowledge.learn_mcp import LearnMcpClient
from ms_agent.knowledge.retriever import LearnRetriever
from ms_agent.llm.client import AzureOpenAIClient
from ms_agent.log import LOGGER_NAME, configure_logging, log_call
from ms_agent.pricing.store import SqlPriceStore
from ms_agent.settings import Settings
from ms_agent.skills import REGISTRY, Services, Skill
from ms_agent.skills.vendor_describe import PNG_LOGO_FILE, PNG_LOGO_PATH, SVG_LOGO_FILE, SVG_LOGO_PATH

CARD_PATHS = ("/.well-known/agent-card.json", "/.well-known/agent.json")

# JSON-RPC 2.0 error codes, and the A2A ones for tasks.
PARSE_ERROR = -32700
INVALID_REQUEST = -32600
METHOD_NOT_FOUND = -32601
INVALID_PARAMS = -32602
TASK_NOT_FOUND = -32001
TASK_NOT_CANCELABLE = -32002

COMPLETED, FAILED = "TASK_STATE_COMPLETED", "TASK_STATE_FAILED"


def build_services(settings: Settings) -> Services:
    """The real retriever, model and price store. The model is None when the environment does not configure
    one; `advice_explain` then refuses with `model_not_configured` and `vendor_describe` still works. A price
    store that cannot be opened is None too, and the pricing skills refuse with `prices_not_configured`."""
    return Services(settings=settings, retriever=LearnRetriever(LearnMcpClient(settings.learn_mcp_url)),
                    model=AzureOpenAIClient.from_settings(settings), version=__version__,
                    prices=open_price_store(settings), files=open_file_store(settings))


def open_price_store(settings: Settings) -> SqlPriceStore | None:
    try:
        return SqlPriceStore.from_settings(settings)
    except SQLAlchemyError:
        logging.getLogger(LOGGER_NAME).exception("price store not opened")
        return None


def open_file_store(settings: Settings) -> FileStore | None:
    """The file store, or None (the skills then answer without a workbook link, with a warning)."""
    try:
        return file_store_from_settings(settings)
    except Exception:  # a misconfigured store must not stop the agent from starting
        logging.getLogger(LOGGER_NAME).exception("file store not opened")
        return None


class TaskStore:
    """Finished tasks, kept for `GetTask`, most recent last; the oldest go when the store is full."""

    def __init__(self, capacity: int = 512) -> None:
        self._tasks: OrderedDict[str, dict[str, Any]] = OrderedDict()
        self._capacity = capacity

    def put(self, task: dict[str, Any]) -> None:
        self._tasks[task["id"]] = task
        while len(self._tasks) > self._capacity:
            self._tasks.popitem(last=False)

    def get(self, identifier: Any) -> dict[str, Any] | None:
        return self._tasks.get(identifier) if isinstance(identifier, str) else None


class Agent:
    """One running agent: its services, its card, its dispatcher."""

    def __init__(self, settings: Settings, services: Services, skills: dict[str, Skill] | None = None) -> None:
        self.settings = settings
        self.services = services
        self.skills = skills if skills is not None else REGISTRY
        self.keys = KeyRing.from_settings(settings)
        self.card = build_card(settings, self.skills, services.version)
        self.tasks = TaskStore()

    async def answer(self, given: Any) -> Answer:
        """One data part `{"skill", "request"}` to one envelope. Never raises: every problem is a refusal."""
        clock = Clock()
        request = given.get("request") if isinstance(given, dict) else None
        try:
            envelope = Envelope.model_validate(given)
        except ValidationError as failure:
            return self._done(refused("bad_request", validation_message(failure), request), "?", clock)
        skill = self.skills.get(envelope.skill)
        if skill is None:
            return self._done(refused("unknown_skill", f"No skill {envelope.skill}; the skills are "
                                                       f"{', '.join(sorted(self.skills))}.", request),
                              envelope.skill, clock)
        try:
            validated = skill.input_model.model_validate(envelope.request)
        except ValidationError as failure:
            return self._done(refused("bad_request", validation_message(failure), request), skill.id, clock)
        try:
            outcome = await skill.handler(validated, self.services)
        except SkillError as failure:
            return self._done(refused(failure.code, failure.message, request, question=failure.question,
                                      usage=failure.usage), skill.id, clock)
        except Exception:
            logging.getLogger(LOGGER_NAME).exception("skill failed", extra={"skill": skill.id,
                                                                            "request_id": request_id_of(request)})
            return self._done(refused("internal_error", "The agent failed while answering.", request), skill.id, clock)
        return self._done(completed(outcome, request), skill.id, clock)

    @staticmethod
    def _done(answer: Answer, skill: str, clock: Clock) -> Answer:
        usage = answer.usage
        log_call(skill, request_id=answer.request_id, status=answer.status, seconds=clock.seconds(),
                 prompt_tokens=usage.prompt_tokens if usage else 0,
                 completion_tokens=usage.completion_tokens if usage else 0,
                 refusal=answer.refusal.code if answer.refusal else None)
        return answer

    def task_of(self, answer: Answer, context_id: str | None) -> dict[str, Any]:
        """The finished A2A task: its status with one sentence for a person, and the artifact `result`
        with the envelope, where MAGIC reads it."""
        task = {
            "id": uuid.uuid4().hex,
            "contextId": context_id or uuid.uuid4().hex,
            "status": {
                "state": FAILED if answer.status == "failed" else COMPLETED,
                "timestamp": datetime.now(tz=UTC).isoformat(timespec="seconds"),
                "message": {"messageId": uuid.uuid4().hex, "role": "ROLE_AGENT",
                            "parts": [{"text": answer.text()[:4000]}]},
            },
            "artifacts": [{"artifactId": uuid.uuid4().hex, "name": "result",
                           "parts": [{"data": answer.model_dump(mode="json")}]}],
        }
        if answer.files:
            # MAGIC reads files from the envelope and from any artifact's `url` parts; the contract names an
            # artifact `files`, so the links are in both.
            task["artifacts"].append({"artifactId": uuid.uuid4().hex, "name": "files", "parts": [
                {"url": one["url"], "filename": one.get("name"), "mediaType": one.get("media_type")}
                for one in answer.files]})
        self.tasks.put(task)
        return task


def request_id_of(request: Any) -> str | None:
    return request.get("request_id") if isinstance(request, dict) and isinstance(request.get("request_id"), str) \
        else None


def data_part_of(params: Any) -> dict[str, Any] | None:
    """The data part of the message, or a text part that holds the same JSON (`text/plain` input mode)."""
    message = params.get("message") if isinstance(params, dict) else None
    parts = message.get("parts") if isinstance(message, dict) else None
    for part in parts or []:
        if isinstance(part, dict) and isinstance(part.get("data"), dict):
            return part["data"]
    for part in parts or []:
        if isinstance(part, dict) and isinstance(part.get("text"), str):
            try:
                parsed = Envelope.model_validate_json(part["text"])
            except ValidationError:
                continue
            return parsed.model_dump()
    return None


def rpc_error(identifier: Any, code: int, message: str, status: int = 200) -> JSONResponse:
    return JSONResponse({"jsonrpc": "2.0", "id": identifier, "error": {"code": code, "message": message}},
                        status_code=status)


def create_app(settings: Settings | None = None, services: Services | None = None,
               skills: dict[str, Skill] | None = None) -> FastAPI:
    settings = settings or Settings()
    configure_logging(settings.ms_agent_log_level)
    services = services or build_services(settings)
    agent = Agent(settings, services, skills)
    app = FastAPI(title="Microsoft vendor agent", version=services.version, docs_url=None, redoc_url=None,
                  openapi_url=None)
    app.state.agent = agent

    @app.exception_handler(HTTPException)
    async def flat_http_error(request: Request, failure: HTTPException) -> JSONResponse:
        body = failure.detail if isinstance(failure.detail, dict) \
            else {"error": "http_error", "message": str(failure.detail)}
        return JSONResponse(body, status_code=failure.status_code, headers=failure.headers)

    @app.get("/healthz")
    async def healthz() -> dict[str, str]:
        return {"status": "ok", "version": services.version}

    for path in CARD_PATHS:
        app.add_api_route(path, lambda: agent.card, methods=["GET"], name="agent_card")

    png_logo, svg_logo = PNG_LOGO_FILE.read_bytes(), SVG_LOGO_FILE.read_bytes()
    public = {"cache-control": "public, max-age=86400"}

    @app.get(PNG_LOGO_PATH)
    async def logo_png() -> Response:
        """The vendor logo as PNG, public like the card. MAGIC does not keep PNG logos; it uses the SVG."""
        return Response(png_logo, media_type="image/png", headers=public)

    @app.get(SVG_LOGO_PATH)
    async def logo_svg() -> Response:
        """The vendor logo as SVG, public like the card: `logo_url` of `vendor_describe`, where MAGIC's operator
        check fetches it when it does not take `logo_svg` inline."""
        return Response(svg_logo, media_type="image/svg+xml", headers=public)

    @app.post(JSONRPC_PATH)
    async def jsonrpc(request: Request) -> JSONResponse:
        agent.keys.require(request)
        try:
            body = await request.json()
        except ValueError:
            return rpc_error(None, PARSE_ERROR, "The body is not JSON.")
        if not isinstance(body, dict) or body.get("jsonrpc") != "2.0" or not isinstance(body.get("method"), str):
            return rpc_error(body.get("id") if isinstance(body, dict) else None, INVALID_REQUEST,
                             "Not a JSON-RPC 2.0 request.")
        identifier, method, params = body.get("id"), body["method"], body.get("params")
        if method == "SendMessage":
            data = data_part_of(params)
            if data is None:
                return rpc_error(identifier, INVALID_PARAMS,
                                 'The message needs one data part {"skill": <skill id>, "request": {...}}.')
            message = params.get("message") if isinstance(params, dict) else {}
            context_id = message.get("contextId") if isinstance(message, dict) \
                and isinstance(message.get("contextId"), str) else None
            task = agent.task_of(await agent.answer(data), context_id)
            return JSONResponse({"jsonrpc": "2.0", "id": identifier, "result": {"task": task}})
        if method in ("GetTask", "CancelTask"):
            task = agent.tasks.get(params.get("id") if isinstance(params, dict) else None)
            if task is None:
                return rpc_error(identifier, TASK_NOT_FOUND, "Task not found.")
            if method == "CancelTask":
                return rpc_error(identifier, TASK_NOT_CANCELABLE, "The task has already finished.")
            return JSONResponse({"jsonrpc": "2.0", "id": identifier, "result": {"task": task}})
        return rpc_error(identifier, METHOD_NOT_FOUND, f"Method not found: {method}.")

    @app.get("/files/{file_id}")
    async def file(file_id: str, request: Request) -> Response:
        """A file the agent made, for 24 hours, with the client key: MAGIC fetches it from here, never
        from another host."""
        agent.keys.require(request)
        found = await asyncio.to_thread(services.files.get, file_id) if services.files else None
        if found is None:
            raise HTTPException(status_code=404, detail={"error": "not_found",
                                                         "message": "No such file, or it has expired."})
        data, stored = found
        return Response(data, media_type=stored.media_type,
                        headers={"content-disposition": f'attachment; filename="{stored.name}"',
                                 "cache-control": "no-store"})

    @app.post(REST_PATH)
    async def rest(request: Request) -> JSONResponse:
        agent.keys.require(request)
        try:
            body = await request.json()
        except ValueError:
            return JSONResponse(refused("bad_request", "The body is not JSON.").model_dump(mode="json"),
                                status_code=400)
        answer = await agent.answer(body)
        return JSONResponse(answer.model_dump(mode="json"))

    return app
