"""Ingestion from the Azure Retail Prices API into the price store.

Facts the code rests on (checked live on 26 October 2026, see PROGRESS.md, stage 0):
- `GET https://prices.azure.com/api/retail/prices?api-version=2023-01-01-preview&$filter=...`, no authentication;
  this api-version carries savings plan prices and the full meter set.
- Filter values are case-sensitive: `serviceName eq 'Virtual Machines'` matches, `'virtual machines'` does not.
- 1,000 items per page; `NextPageLink` is the absolute address of the next page, null on the last.
- `currencyCode='AED'` (and SAR, EUR) is accepted; USD is Microsoft's list price, the others are for reference.

`ingest` pulls one scope at a time (a region and a service family, in one currency) and replaces that
scope in the store in one transaction, so a failed pull leaves yesterday's prices in place.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable, Iterator, Mapping
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any
from urllib.parse import quote

import httpx

from ms_agent.log import LOGGER_NAME
from ms_agent.pricing.store import FIELDS, SqlPriceStore

BASE_URL = "https://prices.azure.com/api/retail/prices"
API_VERSION = "2023-01-01-preview"
RETRIED_STATUS = frozenset({429, 500, 502, 503, 504})
MAX_PAGES = 10_000

logger = logging.getLogger(LOGGER_NAME)


class IngestError(Exception):
    """The API could not be read, after the retries."""


def build_filter(equals: Mapping[str, str]) -> str:
    """An OData `$filter` of equalities joined by `and`, in the given order and the given case: the API
    compares case-sensitively. A single quote inside a value is doubled, as OData requires."""
    return " and ".join(f"{name} eq '{str(value).replace(chr(39), chr(39) * 2)}'" for name, value in equals.items())


def query_url(filter_text: str, currency: str = "USD", *, base_url: str = BASE_URL,
              api_version: str = API_VERSION) -> str:
    """The address of one query, readable in a browser; the currency is named only when it is not USD."""
    url = f"{base_url}?api-version={api_version}"
    if currency.upper() != "USD":
        url += "&currencyCode=" + quote(f"'{currency.upper()}'", safe="")
    return url + f"&$filter={quote(filter_text, safe='')}"


def source_url_of(item: Mapping[str, Any]) -> str:
    """The query that returns this meter again: its meter id, region and price type, in its currency."""
    equals = {"meterId": item.get("meterId") or "", "armRegionName": item.get("armRegionName") or "",
              "priceType": item.get("type") or ""}
    return query_url(build_filter(equals), str(item.get("currencyCode") or "USD"))


class RetailPricesClient:
    """Pages of the Retail Prices API, with retries and backoff."""

    def __init__(self, http: httpx.Client | None = None, *, base_url: str = BASE_URL, api_version: str = API_VERSION,
                 retries: int = 5, backoff_seconds: float = 1.0, sleep: Callable[[float], None] = time.sleep) -> None:
        self._http = http or httpx.Client(timeout=httpx.Timeout(60.0, connect=10.0),
                                          headers={"user-agent": "ms-vendor-agent price ingestion"})
        self.base_url = base_url
        self.api_version = api_version
        self._retries = retries
        self._backoff = backoff_seconds
        self._sleep = sleep

    def _get(self, url: str, params: dict[str, str] | None) -> dict[str, Any]:
        for attempt in range(self._retries + 1):
            last = attempt == self._retries
            try:
                answer = self._http.get(url, params=params)
            except httpx.TransportError as failure:
                if last:
                    raise IngestError(f"The Retail Prices API could not be reached: {type(failure).__name__}.") \
                        from None
                self._sleep(self._backoff * 2 ** attempt)
                continue
            if answer.status_code == 200:
                return answer.json()
            if answer.status_code not in RETRIED_STATUS or last:
                raise IngestError(f"The Retail Prices API answered HTTP {answer.status_code}.")
            self._sleep(self._wait(answer, attempt))
        raise IngestError("unreachable")  # pragma: no cover - the loop returns or raises

    def _wait(self, answer: httpx.Response, attempt: int) -> float:
        given = answer.headers.get("retry-after", "")
        if given.isdigit():
            return min(60.0, float(given))
        return self._backoff * 2 ** attempt

    def pages(self, filter_text: str, currency: str = "USD") -> Iterator[list[dict[str, Any]]]:
        """Each page's items, following `NextPageLink` until it is null."""
        params = {"api-version": self.api_version, "$filter": filter_text}
        if currency.upper() != "USD":
            params["currencyCode"] = f"'{currency.upper()}'"
        url: str | None = self.base_url
        seen: set[str] = set()
        for _ in range(MAX_PAGES):
            page = self._get(url, params)  # type: ignore[arg-type]
            yield list(page.get("Items") or [])
            url = page.get("NextPageLink")
            if not url:
                return
            if url in seen:
                raise IngestError("The Retail Prices API returned the same NextPageLink twice.")
            seen.add(url)
            params = None  # the next link carries the query and its skip token
        raise IngestError(f"More than {MAX_PAGES} pages.")

    def items(self, filter_text: str, currency: str = "USD") -> list[dict[str, Any]]:
        return [item for page in self.pages(filter_text, currency) for item in page]


@dataclass
class IngestReport:
    """What one run stored, scope by scope, and what failed."""

    fetched_at: str
    stored: dict[str, int] = field(default_factory=dict)
    failed: dict[str, str] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return not self.failed


def now_text() -> str:
    return datetime.now(tz=UTC).isoformat(timespec="seconds").replace("+00:00", "Z")


def ingest_scope(store: SqlPriceStore, client: RetailPricesClient, scope: Mapping[str, str], currency: str = "USD",
                 *, fetched_at: str | None = None) -> int:
    """Pull one scope (API field -> value) and replace it in the store. Returns the number of meters stored."""
    fetched_at = fetched_at or now_text()
    items = client.items(build_filter(scope), currency)
    # `priceType` is the filter's name for the item field `type`.
    columns = {FIELDS["type" if name == "priceType" else name]: value for name, value in scope.items()}
    return store.replace(items, scope=columns, currency=currency.upper(), fetched_at=fetched_at,
                         source_url_of=source_url_of)


def ingest(store: SqlPriceStore, client: RetailPricesClient, *, regions: list[str], families: list[str],
           currencies: list[str], services: list[str] | None = None,
           global_services: list[str] | None = None) -> IngestReport:
    """Every region and service family in every currency; then the named services in every region (a service
    whose family is also pulled is replaced by its own scope, so it is stored once); then the services Microsoft
    publishes under `armRegionName 'Global'` (Load Balancer). A scope that fails keeps its old prices and is
    reported; the others go on."""
    report = IngestReport(fetched_at=now_text())
    scopes: list[tuple[str, dict[str, str]]] = []
    for region in regions:
        scopes += [(f"{region}/{family}", {"serviceFamily": family, "armRegionName": region}) for family in families]
        scopes += [(f"{region}/{service}", {"serviceName": service, "armRegionName": region})
                   for service in services or []]
    scopes += [(f"Global/{service}", {"serviceName": service, "armRegionName": "Global"})
               for service in global_services or []]
    for currency in currencies:
        for label, scope in scopes:
            name = f"{currency}/{label}"
            try:
                report.stored[name] = ingest_scope(store, client, scope, currency, fetched_at=report.fetched_at)
            except IngestError as failure:
                report.failed[name] = str(failure)
            logger.info("prices ingested", extra={"scope": name, "stored": report.stored.get(name),
                                                  "failed": report.failed.get(name)})
    return report
