"""Virtual machine size specifications: vCPU, memory, family, generation, premium disk support.

The Retail Prices API has no specifications, so they come from a snapshot per region,
`data/vm_sizes_<region>.json`, written by `scripts/refresh_vm_sizes.ps1` from
`az vm list-skus -l <region> --resource-type virtualMachines`:

    {"region", "source", "generated", "sizes": [{"name", "family", "vcpus", "memory_gb", "premium_io",
                                                 "hyperv_generations", "accelerated_networking"}]}

`family` there is Azure's quota family (`StandardDsv6Family`); sizing uses the series letters of the
name instead (`Standard_D4as_v5` -> `D`), and the generation is the name's `_v<n>` (none -> 1). A size
is offered in a region only when the price store also holds its price there.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from functools import cache
from pathlib import Path

GENERATION = re.compile(r"_v(\d+)$")
# Arm64 sizes have a `p` among the feature letters after the vCPU count: D4ps_v6, D4plds_v6, E8pds_v6.
ARM64 = re.compile(r"^Standard_[A-Z]+\d+[a-z]*p[a-z]*_v\d+$")


class CatalogNotFound(LookupError):
    pass


@dataclass(frozen=True)
class VmSize:
    name: str
    vcpu: int
    memory_gib: float
    family: str
    generation: int
    premium_disk: bool
    quota_family: str = ""

    @property
    def short_name(self) -> str:
        return self.name.removeprefix("Standard_")

    @property
    def constrained_cores(self) -> bool:
        """A constrained-core size (`E8-4s_v5`): the parent's price with fewer active cores, for per-core
        licensing."""
        return "-" in self.short_name

    @property
    def arm64(self) -> bool:
        return bool(ARM64.match(self.name))


@dataclass(frozen=True)
class VmCatalog:
    region: str
    sizes: tuple[VmSize, ...]
    source: str
    generated: str

    def newest_generation(self, family: str) -> int:
        return max((one.generation for one in self.sizes if one.family == family), default=1)

    def current_generation(self, size: VmSize) -> bool:
        """Whether no size of the same family in this catalog has a newer generation."""
        return size.generation >= self.newest_generation(size.family)

    def get(self, name: str) -> VmSize | None:
        return next((size for size in self.sizes if size.name.lower() == name.lower()), None)


def family_of(name: str) -> str:
    """`Standard_E8as_v5` -> `E`; `Standard_DC4s_v3` -> `DC`: the letters before the first digit."""
    found = re.match(r"([A-Z]+)", name.removeprefix("Standard_"))
    return found.group(1) if found else ""


def generation_of(name: str) -> int:
    found = GENERATION.search(name)
    return int(found.group(1)) if found else 1


@cache
def load(region: str, directory: Path) -> VmCatalog:
    path = directory / f"vm_sizes_{region}.json"
    if not path.is_file():
        raise CatalogNotFound(f"No VM size snapshot for {region} ({path.name}); run scripts/refresh_vm_sizes.ps1.")
    # `utf-8-sig`: PowerShell's Set-Content may write a byte order mark.
    given = json.loads(path.read_text(encoding="utf-8-sig"))
    sizes = tuple(VmSize(name=one["name"], vcpu=int(one["vcpus"]), memory_gib=float(one["memory_gb"]),
                         family=family_of(one["name"]), generation=generation_of(one["name"]),
                         premium_disk=bool(one.get("premium_io", False)), quota_family=one.get("family", ""))
                  for one in given["sizes"])
    return VmCatalog(region=given.get("region", region), sizes=sizes, source=given.get("source", ""),
                     generated=given.get("generated", ""))
