"""Azure list prices: ingestion from the Retail Prices API, the price store, and the lookup by pricing model."""
