"""Prices by pricing model, each with its provenance.

`price_for(store, arm_sku, region, os, pricing_model)` answers one virtual machine price:

- `payg`: the consumption meter, `Virtual Machines <series>` (Linux) or `... Windows` (licence
  included); per hour.
- `ri_1y`, `ri_3y`: the `Reservation` meter with `reservationTerm` `1 Year` / `3 Years`; the price
  of the whole term, whatever `unitOfMeasure` says.
- `sp_1y`, `sp_3y`: `savingsPlan[term].retailPrice` of the Linux consumption meter; per hour.
- `ahb`: Azure Hybrid Benefit, the Linux consumption meter, for a Windows machine whose licence the
  customer brings; per hour.

Reservations and savings plans cover compute only: a Windows machine pays its licence on top, at
`windows_licence` (the Windows meter minus the Linux meter, same size and region). Every `Price`
names the meters it was read from, with their source URL, Microsoft's `effectiveStartDate` and our
`fetched_at`. Prices are Microsoft's retail list prices, not agreement prices.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Literal

from ms_agent.pricing.store import Meter, PriceStore

PricingModel = Literal["payg", "ri_1y", "ri_3y", "sp_1y", "sp_3y", "ahb"]
OperatingSystem = Literal["linux", "windows"]
Basis = Literal["hourly", "monthly", "term", "unit"]

MODELS: tuple[PricingModel, ...] = ("payg", "ri_1y", "ri_3y", "sp_1y", "sp_3y", "ahb")
LABELS: dict[str, str] = {
    "payg": "Pay-as-you-go",
    "ri_1y": "1-year reservation",
    "ri_3y": "3-year reservation",
    "sp_1y": "1-year savings plan",
    "sp_3y": "3-year savings plan",
    "ahb": "Azure Hybrid Benefit (pay-as-you-go)",
}
TERMS = {"ri_1y": "1 Year", "ri_3y": "3 Years", "sp_1y": "1 Year", "sp_3y": "3 Years"}
TERM_MONTHS = {"1 Year": 12, "3 Years": 36, "5 Years": 60}
LIST_PRICE_NOTICE = ("Microsoft retail list prices from the Azure Retail Prices API; not CSP, EA or MCA agreement "
                     "prices.")
AHB_LABEL = ("Azure Hybrid Benefit: the Linux meter price for the same size and region; the customer brings an "
             "eligible Windows Server licence.")
COMPUTE_ONLY = "Compute only: reservations and savings plans do not cover the Windows licence."
LICENCE_LABEL = ("Windows Server licence: the Windows meter minus the Linux meter for the same size and region, "
                 "billed per hour on top of a reservation or savings plan.")
DISK_PRODUCTS = {"premium_ssd": "Premium SSD Managed Disks", "standard_ssd": "Standard SSD Managed Disks",
                 "standard_hdd": "Standard HDD Managed Disks"}
EXCLUDED_SKU_MARKERS = ("Spot", "Low Priority")


class PriceNotFound(LookupError):
    """The store holds no price for what was asked; the message says what was missing."""


@dataclass(frozen=True)
class Source:
    """One meter a number was read from."""

    url: str
    effective_start_date: str
    fetched_at: str
    meter_id: str
    meter_name: str
    product_name: str
    type: str
    field: str

    def as_dict(self) -> dict[str, str]:
        return dict(vars(self))


@dataclass(frozen=True)
class Price:
    """A price with what it is and where it came from. `value` is per `unit`; `basis` says how it adds up
    to a month: `hourly` (× hours), `monthly`, or `term` (the whole term, ÷ `term_months`)."""

    value: Decimal
    currency: str
    unit: str
    basis: Basis
    pricing_model: str
    label: str
    sources: tuple[Source, ...]
    term_months: int = 0

    @property
    def source_url(self) -> str:
        return self.sources[0].url

    @property
    def effective_start_date(self) -> str:
        return max(source.effective_start_date for source in self.sources)

    @property
    def fetched_at(self) -> str:
        return min(source.fetched_at for source in self.sources)

    def as_dict(self) -> dict[str, Any]:
        return {"value": float(self.value), "currency": self.currency, "unit": self.unit, "basis": self.basis,
                "pricing_model": self.pricing_model, "label": self.label, "source_url": self.source_url,
                "effective_start_date": self.effective_start_date, "fetched_at": self.fetched_at,
                "term_months": self.term_months, "sources": [source.as_dict() for source in self.sources]}


def decimal_of(number: float) -> Decimal:
    """The price exactly as the API wrote it (the shortest decimal of the stored float)."""
    return Decimal(repr(float(number)))


def source_of(meter: Meter, field: str) -> Source:
    return Source(url=meter.source_url, effective_start_date=meter.effective_start_date, fetched_at=meter.fetched_at,
                  meter_id=meter.meter_id, meter_name=meter.meter_name, product_name=meter.product_name,
                  type=meter.type, field=field)


def _best(meters: list[Meter]) -> Meter | None:
    """The meter to use among equals: the primary meter region first, then the first tier. The store gives
    the newest effective date first and the sort is stable, so among the rest the newest wins."""
    ranked = sorted(meters, key=lambda meter: (not meter.is_primary_meter_region, meter.tier_minimum_units))
    return ranked[0] if ranked else None


def vm_meters(store: PriceStore, arm_sku: str, region: str, currency: str = "USD") -> list[Meter]:
    """The virtual machine meters of one size in one region: consumption and reservation, no Spot, Low
    Priority or Dev/Test, and only products named `Virtual Machines ...` (`... Cloud Services` shares the
    service name)."""
    return [meter for meter in store.find(currency=currency, types=("Consumption", "Reservation"),
                                          service_name="Virtual Machines", arm_sku_name=arm_sku,
                                          arm_region_name=region)
            if meter.product_name.startswith("Virtual Machines ")
            and not any(marker in meter.sku_name for marker in EXCLUDED_SKU_MARKERS)]


def _consumption(meters: list[Meter], windows: bool) -> Meter | None:
    return _best([meter for meter in meters if meter.type == "Consumption"
                  and meter.product_name.endswith(" Windows") == windows])


def _missing(arm_sku: str, region: str, what: str) -> PriceNotFound:
    return PriceNotFound(f"No {what} for {arm_sku} in {region} in the price store.")


def price_for(store: PriceStore, arm_sku: str, region: str, os: OperatingSystem, pricing_model: PricingModel,
              currency: str = "USD") -> Price:
    """One virtual machine price. Reservations and savings plans are compute only, whatever the OS: a
    Windows machine adds `windows_licence`."""
    meters = vm_meters(store, arm_sku, region, currency)
    if pricing_model == "payg":
        meter = _consumption(meters, windows=os == "windows")
        if meter is None:
            raise _missing(arm_sku, region, f"{os.capitalize()} pay-as-you-go meter")
        label = LABELS["payg"] + (", Windows licence included" if os == "windows" else ", Linux")
        return Price(decimal_of(meter.retail_price), meter.currency_code, meter.unit_of_measure, "hourly", "payg",
                     label, (source_of(meter, "retailPrice"),))
    if pricing_model == "ahb":
        if os != "windows":
            raise PriceNotFound("Azure Hybrid Benefit applies to Windows machines only.")
        meter = _consumption(meters, windows=False)
        if meter is None:
            raise _missing(arm_sku, region, "Linux pay-as-you-go meter (the Azure Hybrid Benefit price)")
        return Price(decimal_of(meter.retail_price), meter.currency_code, meter.unit_of_measure, "hourly", "ahb",
                     AHB_LABEL, (source_of(meter, "retailPrice"),))
    term = TERMS[pricing_model]
    if pricing_model.startswith("ri_"):
        meter = _best([meter for meter in meters if meter.type == "Reservation" and meter.reservation_term == term])
        if meter is None:
            raise _missing(arm_sku, region, f"{term.lower()} reservation")
        label = f"{LABELS[pricing_model]}, price of the whole term" + (f". {COMPUTE_ONLY}" if os == "windows" else "")
        return Price(decimal_of(meter.retail_price), meter.currency_code, term, "term", pricing_model, label,
                     (source_of(meter, "retailPrice"),), term_months=TERM_MONTHS[term])
    meter = _consumption(meters, windows=False)
    plan = meter.savings_plan_for(term) if meter else None
    if meter is None or plan is None:
        raise _missing(arm_sku, region, f"{term.lower()} savings plan price")
    label = LABELS[pricing_model] + (f". {COMPUTE_ONLY}" if os == "windows" else "")
    return Price(decimal_of(plan.retail_price), meter.currency_code, meter.unit_of_measure, "hourly", pricing_model,
                 label, (source_of(meter, f"savingsPlan[{term}].retailPrice"),))


def windows_licence(store: PriceStore, arm_sku: str, region: str, currency: str = "USD") -> Price:
    """The Windows Server licence per hour for one size: the Windows meter minus the Linux meter."""
    meters = vm_meters(store, arm_sku, region, currency)
    windows, linux = _consumption(meters, windows=True), _consumption(meters, windows=False)
    if windows is None or linux is None:
        raise _missing(arm_sku, region, "Windows and Linux pay-as-you-go meter pair")
    value = decimal_of(windows.retail_price) - decimal_of(linux.retail_price)
    if value < 0:
        raise PriceNotFound(f"The Windows meter of {arm_sku} in {region} is below its Linux meter.")
    return Price(value, windows.currency_code, windows.unit_of_measure, "hourly", "windows_licence", LICENCE_LABEL,
                 (source_of(windows, "retailPrice"), source_of(linux, "retailPrice")))


def disk_price(store: PriceStore, disk_type: str, tier: str, region: str, currency: str = "USD") -> Price:
    """One managed disk per month: the meter `<tier> LRS Disk` of the disk type's product (not `Disk Mount`,
    which is a shared disk's, nor `Disk Operations`)."""
    product = DISK_PRODUCTS[disk_type]
    meter = _best([meter for meter in store.find(currency=currency, types=("Consumption",), product_name=product,
                                                  sku_name=f"{tier} LRS", arm_region_name=region)
                   if meter.meter_name == f"{tier} LRS Disk"])
    if meter is None:
        raise PriceNotFound(f"No {product} {tier} LRS price in {region} in the price store.")
    return Price(decimal_of(meter.retail_price), meter.currency_code, meter.unit_of_measure, "monthly", "payg",
                 f"{product} {tier} LRS, per disk per month", (source_of(meter, "retailPrice"),))


def basis_of(unit: str) -> Basis:
    """How a meter's unit adds up to a month: per hour (`1 Hour`, `1/Hour`) or per unit used in the month
    (`1/Month`, `1 GB/Month`, `1 GB`, `10K`, ...: the line's quantity is that many units a month)."""
    return "hourly" if "hour" in unit.lower() else "monthly"


def meter_price(store: PriceStore, region: str, *, service: str, product: str, sku: str, meter: str,
                tier: float = 0.0, currency: str = "USD", label: str = "") -> Price:
    """One consumption meter, named exactly as the Retail Prices API names it. A tiered meter is read at the tier
    whose `tierMinimumUnits` is given (Log Analytics ingestion: 0 GB is free, 5 GB and up is paid). When it is
    missing, the error names the service, product, SKU, meter and region."""
    found = _best([one for one in store.find(currency=currency, types=("Consumption",), service_name=service,
                                             product_name=product, sku_name=sku, meter_name=meter,
                                             arm_region_name=region)
                   if one.tier_minimum_units == tier])
    if found is None:
        raise PriceNotFound(f"No meter '{meter}' (service '{service}', product '{product}', SKU '{sku}'"
                            f"{f', tier from {tier:g}' if tier else ''}) in {region} in the price store.")
    return Price(decimal_of(found.retail_price), found.currency_code, found.unit_of_measure,
                 basis_of(found.unit_of_measure), "payg", label or f"{product}, {meter}",
                 (source_of(found, "retailPrice"),))
