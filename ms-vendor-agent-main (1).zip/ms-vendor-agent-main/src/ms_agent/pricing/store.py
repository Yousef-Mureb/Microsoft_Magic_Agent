"""The price store: Azure Retail Prices meters, as Microsoft gave them, with where and when they were read.

One table, `meters`, holds every field of an item of the Retail Prices API plus the meter's source
URL (a query that returns that meter again) and `fetched_at`. SQLAlchemy 2 keeps the schema the
same on SQLite (development and tests) and PostgreSQL (Azure): the URL in `MS_AGENT_PRICE_DB_URL`
decides, for example `sqlite:///prices.sqlite3` or `postgresql+psycopg://user:password@host:5432/prices`
(psycopg 3, installed; the table and its indexes are created on first use).

The skills read through the `PriceStore` interface only, so a test or another backend can stand in.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from typing import Any, Protocol

from sqlalchemy import Boolean, Float, Index, Integer, String, Text, create_engine, delete, func, insert, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column
from sqlalchemy.pool import StaticPool

from ms_agent.settings import Settings


class Base(DeclarativeBase):
    pass


class MeterTable(Base):
    """One item of the Retail Prices API. Column names are the API's field names in snake case."""

    __tablename__ = "meters"
    __table_args__ = (Index("ix_meters_sku_region_type", "arm_sku_name", "arm_region_name", "type"),
                      Index("ix_meters_product_region", "product_name", "arm_region_name"))

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    currency_code: Mapped[str] = mapped_column(String(8))
    tier_minimum_units: Mapped[float] = mapped_column(Float, default=0.0)
    retail_price: Mapped[float] = mapped_column(Float)
    unit_price: Mapped[float] = mapped_column(Float)
    arm_region_name: Mapped[str] = mapped_column(String(64), default="")
    location: Mapped[str] = mapped_column(String(128), default="")
    effective_start_date: Mapped[str] = mapped_column(String(32), default="")
    meter_id: Mapped[str] = mapped_column(String(64), default="")
    meter_name: Mapped[str] = mapped_column(String(256), default="")
    product_id: Mapped[str] = mapped_column(String(64), default="")
    sku_id: Mapped[str] = mapped_column(String(64), default="")
    product_name: Mapped[str] = mapped_column(String(256), default="")
    sku_name: Mapped[str] = mapped_column(String(256), default="")
    service_name: Mapped[str] = mapped_column(String(128), default="")
    service_id: Mapped[str] = mapped_column(String(64), default="")
    service_family: Mapped[str] = mapped_column(String(64), default="")
    unit_of_measure: Mapped[str] = mapped_column(String(64), default="")
    type: Mapped[str] = mapped_column(String(32), default="")
    is_primary_meter_region: Mapped[bool] = mapped_column(Boolean, default=True)
    arm_sku_name: Mapped[str] = mapped_column(String(256), default="")
    reservation_term: Mapped[str] = mapped_column(String(32), default="")
    savings_plan: Mapped[str] = mapped_column(Text, default="[]")
    source_url: Mapped[str] = mapped_column(Text, default="")
    fetched_at: Mapped[str] = mapped_column(String(32), default="")


# API field name -> column name.
FIELDS = {
    "currencyCode": "currency_code", "tierMinimumUnits": "tier_minimum_units", "retailPrice": "retail_price",
    "unitPrice": "unit_price", "armRegionName": "arm_region_name", "location": "location",
    "effectiveStartDate": "effective_start_date", "meterId": "meter_id", "meterName": "meter_name",
    "productId": "product_id", "skuId": "sku_id", "productName": "product_name", "skuName": "sku_name",
    "serviceName": "service_name", "serviceId": "service_id", "serviceFamily": "service_family",
    "unitOfMeasure": "unit_of_measure", "type": "type", "isPrimaryMeterRegion": "is_primary_meter_region",
    "armSkuName": "arm_sku_name", "reservationTerm": "reservation_term",
}


@dataclass(frozen=True)
class SavingsPlanPrice:
    term: str
    unit_price: float
    retail_price: float


@dataclass(frozen=True)
class Meter:
    """One stored meter, detached from the database."""

    currency_code: str
    retail_price: float
    unit_price: float
    arm_region_name: str
    effective_start_date: str
    meter_id: str
    meter_name: str
    product_name: str
    sku_name: str
    service_name: str
    service_family: str
    unit_of_measure: str
    type: str
    arm_sku_name: str
    source_url: str
    fetched_at: str
    location: str = ""
    product_id: str = ""
    sku_id: str = ""
    service_id: str = ""
    tier_minimum_units: float = 0.0
    is_primary_meter_region: bool = True
    reservation_term: str = ""
    savings_plan: tuple[SavingsPlanPrice, ...] = field(default_factory=tuple)

    def savings_plan_for(self, term: str) -> SavingsPlanPrice | None:
        return next((one for one in self.savings_plan if one.term == term), None)


def row_of(item: Mapping[str, Any], *, source_url: str, fetched_at: str) -> dict[str, Any]:
    """The table row of one API item."""
    row = {column: item.get(name) for name, column in FIELDS.items()}
    for column in ("arm_region_name", "location", "effective_start_date", "meter_id", "meter_name", "product_id",
                   "sku_id", "product_name", "sku_name", "service_name", "service_id", "service_family",
                   "unit_of_measure", "type", "arm_sku_name", "reservation_term"):
        row[column] = row[column] or ""
    row["tier_minimum_units"] = float(row["tier_minimum_units"] or 0.0)
    row["is_primary_meter_region"] = bool(True if row["is_primary_meter_region"] is None
                                          else row["is_primary_meter_region"])
    row["savings_plan"] = json.dumps(item.get("savingsPlan") or [])
    row["source_url"] = source_url
    row["fetched_at"] = fetched_at
    return row


def meter_of(row: MeterTable) -> Meter:
    plans = tuple(SavingsPlanPrice(term=str(one.get("term", "")), unit_price=float(one.get("unitPrice", 0.0)),
                                   retail_price=float(one.get("retailPrice", 0.0)))
                  for one in json.loads(row.savings_plan or "[]"))
    values = {column: getattr(row, column) for column in FIELDS.values()}
    return Meter(**values, source_url=row.source_url, fetched_at=row.fetched_at, savings_plan=plans)


class PriceStore(Protocol):
    """What the skills need from a price store."""

    def find(self, *, currency: str = "USD", types: Iterable[str] | None = None, limit: int | None = None,
             **equals: str) -> list[Meter]: ...

    def count(self) -> int: ...


class SqlPriceStore:
    """The price store on SQLAlchemy: SQLite or PostgreSQL by URL."""

    def __init__(self, url: str) -> None:
        options: dict[str, Any] = {}
        if url in ("sqlite://", "sqlite:///:memory:"):
            # One shared connection, or every session would see a new empty database.
            options = {"connect_args": {"check_same_thread": False}, "poolclass": StaticPool}
        self.engine = create_engine(url, **options)
        Base.metadata.create_all(self.engine)

    @classmethod
    def from_settings(cls, settings: Settings) -> SqlPriceStore:
        return cls(settings.ms_agent_price_db_url)

    def replace(self, items: Iterable[Mapping[str, Any]], *, scope: Mapping[str, str], currency: str,
                fetched_at: str, source_url_of: Any) -> int:
        """Replace, in one transaction, the meters of one scope (columns equal to values, one currency) with
        `items`. A refreshed scope holds exactly what the API gave today; a meter Microsoft retired goes."""
        rows = [row_of(item, source_url=source_url_of(item), fetched_at=fetched_at) for item in items]
        with self.engine.begin() as connection:
            condition = [getattr(MeterTable, column) == value for column, value in scope.items()]
            connection.execute(delete(MeterTable).where(MeterTable.currency_code == currency, *condition))
            if rows:
                connection.execute(insert(MeterTable), rows)
        return len(rows)

    def find(self, *, currency: str = "USD", types: Iterable[str] | None = None, limit: int | None = None,
             **equals: str) -> list[Meter]:
        """Meters whose columns equal the given values, newest `effectiveStartDate` first."""
        query = select(MeterTable).where(MeterTable.currency_code == currency)
        for column, value in equals.items():
            query = query.where(getattr(MeterTable, column) == value)
        if types is not None:
            query = query.where(MeterTable.type.in_(list(types)))
        query = query.order_by(MeterTable.effective_start_date.desc(), MeterTable.id)
        if limit is not None:
            query = query.limit(limit)
        with Session(self.engine) as session:
            return [meter_of(row) for row in session.scalars(query)]

    def count(self) -> int:
        with self.engine.connect() as connection:
            return int(connection.execute(select(func.count()).select_from(MeterTable)).scalar_one())
