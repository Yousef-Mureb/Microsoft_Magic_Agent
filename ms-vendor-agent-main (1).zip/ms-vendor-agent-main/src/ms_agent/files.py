"""Files the agent makes (the estimate workbook), kept for 24 hours.

MAGIC fetches a file the envelope names only from the agent's own origin, with the client key
(`A2aAgent.fetch` in the platform's `vendors.py`). So the link in an answer is always
`<public URL>/files/<id>` on the agent, which checks the key and serves the file from the store:

- `LocalFileStore`: a folder, in development (`MS_AGENT_FILES_DIR`).
- `BlobFileStore`: an Azure Blob Storage container, in Azure, reached by the managed identity. It also
  makes a 24-hour read-only SAS link (a user delegation SAS: the identity needs the role Storage Blob
  Delegator as well as Storage Blob Data Contributor), returned as `direct_url` for a person; MAGIC
  itself cannot use it, because it is on another host.
"""

from __future__ import annotations

import json
import re
import secrets
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Protocol

from ms_agent.settings import Settings

LIFETIME = timedelta(hours=24)
FILE_ID = re.compile(r"[A-Za-z0-9_-]{16,64}")


@dataclass(frozen=True)
class StoredFile:
    id: str
    name: str
    media_type: str
    size: int
    expires_at: str
    direct_url: str | None = None


class FileStore(Protocol):
    def put(self, name: str, media_type: str, data: bytes) -> StoredFile: ...

    def get(self, file_id: str) -> tuple[bytes, StoredFile] | None: ...


def _now() -> datetime:
    return datetime.now(tz=UTC)


def _stamp(moment: datetime) -> str:
    return moment.isoformat(timespec="seconds").replace("+00:00", "Z")


def _expired(stamp: str, now: datetime) -> bool:
    return datetime.fromisoformat(stamp.replace("Z", "+00:00")) <= now


def safe_name(name: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._ -]", "-", name).strip(" .")
    return cleaned[:120] or "file"


class LocalFileStore:
    """Files in a folder: `<id>.bin` and `<id>.json` (name, media type, expiry). Expired files are removed
    when a new one is stored."""

    def __init__(self, directory: Path, lifetime: timedelta = LIFETIME, clock: Any = _now) -> None:
        self.directory = directory
        self.lifetime = lifetime
        self.clock = clock

    def put(self, name: str, media_type: str, data: bytes) -> StoredFile:
        self.directory.mkdir(parents=True, exist_ok=True)
        self._sweep()
        stored = StoredFile(id=secrets.token_urlsafe(24), name=safe_name(name), media_type=media_type, size=len(data),
                            expires_at=_stamp(self.clock() + self.lifetime))
        (self.directory / f"{stored.id}.bin").write_bytes(data)
        (self.directory / f"{stored.id}.json").write_text(json.dumps(vars(stored)), encoding="utf-8")
        return stored

    def get(self, file_id: str) -> tuple[bytes, StoredFile] | None:
        if not FILE_ID.fullmatch(file_id):
            return None
        meta, body = self.directory / f"{file_id}.json", self.directory / f"{file_id}.bin"
        if not meta.is_file() or not body.is_file():
            return None
        stored = StoredFile(**json.loads(meta.read_text(encoding="utf-8")))
        if _expired(stored.expires_at, self.clock()):
            return None
        return body.read_bytes(), stored

    def _sweep(self) -> None:
        now = self.clock()
        for meta in self.directory.glob("*.json"):
            try:
                expires = json.loads(meta.read_text(encoding="utf-8"))["expires_at"]
            except (ValueError, KeyError, OSError):
                continue
            if _expired(expires, now):
                meta.unlink(missing_ok=True)
                meta.with_suffix(".bin").unlink(missing_ok=True)


class BlobFileStore:
    """Files in an Azure Blob Storage container, one blob per file, named by its id; the name, media type
    and expiry travel as blob metadata. A lifecycle rule on the container should delete blobs after a day;
    the agent refuses to serve an expired one either way."""

    def __init__(self, service: Any, container: str, lifetime: timedelta = LIFETIME, clock: Any = _now) -> None:
        # `service` is an `azure.storage.blob.BlobServiceClient` (a fake in the tests).
        self.service = service
        self.container = container
        self.lifetime = lifetime
        self.clock = clock

    @classmethod
    def from_settings(cls, settings: Settings) -> BlobFileStore:
        from azure.identity import DefaultAzureCredential
        from azure.storage.blob import BlobServiceClient

        if not settings.azure_storage_account_url:
            raise ValueError("Set AZURE_STORAGE_ACCOUNT_URL for MS_AGENT_FILES_BACKEND=blob.")
        credential = DefaultAzureCredential(managed_identity_client_id=settings.azure_client_id or None)
        return cls(BlobServiceClient(settings.azure_storage_account_url, credential=credential),
                   settings.azure_storage_container)

    def put(self, name: str, media_type: str, data: bytes) -> StoredFile:
        from azure.storage.blob import ContentSettings

        now = self.clock()
        expires = now + self.lifetime
        file_id = secrets.token_urlsafe(24)
        name = safe_name(name)
        blob = self.service.get_container_client(self.container).get_blob_client(file_id)
        blob.upload_blob(data, overwrite=False, metadata={"name": name, "expires_at": _stamp(expires)},
                         content_settings=ContentSettings(content_type=media_type,
                                                          content_disposition=f'attachment; filename="{name}"'))
        return StoredFile(id=file_id, name=name, media_type=media_type, size=len(data), expires_at=_stamp(expires),
                          direct_url=self._sas_url(blob.url, file_id, now, expires))

    def _sas_url(self, url: str, file_id: str, now: datetime, expires: datetime) -> str:
        from azure.storage.blob import BlobSasPermissions, generate_blob_sas

        key = self.service.get_user_delegation_key(key_start_time=now - timedelta(minutes=5), key_expiry_time=expires)
        token = generate_blob_sas(account_name=self.service.account_name, container_name=self.container,
                                  blob_name=file_id, user_delegation_key=key, permission=BlobSasPermissions(read=True),
                                  expiry=expires, start=now - timedelta(minutes=5))
        return f"{url}?{token}"

    def get(self, file_id: str) -> tuple[bytes, StoredFile] | None:
        from azure.core.exceptions import ResourceNotFoundError

        if not FILE_ID.fullmatch(file_id):
            return None
        blob = self.service.get_container_client(self.container).get_blob_client(file_id)
        try:
            properties = blob.get_blob_properties()
        except ResourceNotFoundError:
            return None
        metadata = properties.metadata or {}
        expires = metadata.get("expires_at", "")
        if not expires or _expired(expires, self.clock()):
            return None
        data = blob.download_blob().readall()
        stored = StoredFile(id=file_id, name=metadata.get("name", file_id),
                            media_type=properties.content_settings.content_type or "application/octet-stream",
                            size=len(data), expires_at=expires)
        return data, stored


def file_store_from_settings(settings: Settings) -> FileStore:
    if settings.ms_agent_files_backend == "blob":
        return BlobFileStore.from_settings(settings)
    return LocalFileStore(Path(settings.ms_agent_files_dir))
