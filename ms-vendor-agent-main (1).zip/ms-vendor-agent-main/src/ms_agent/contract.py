"""The `vendor-agent/1` contract: what comes in, what goes out.

In: a data part `{"skill": <skill id>, "request": {...}}`. Out: the envelope
`{"contract", "status", "warnings", "files", "result", "refusal", "usage", "request_id", "role"}`,
which MAGIC reads from the artifact named `result` of the finished task
(`magic3-platform/modules/tools/services/authority/src/vendors.py`, `_a2a_result`). A refusal is
an envelope with `status: "failed"` and a `refusal`, never an HTTP error: MAGIC shows the
refusal's words to the person and treats the answer as an error for the model.
"""

from __future__ import annotations

import time
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError

CONTRACT = "vendor-agent/1"

Status = Literal["complete", "partial", "failed"]


class Common(BaseModel):
    """What every skill request may carry. `request_id` and `role` are MAGIC's and are echoed.

    `extra="forbid"` makes the published schema say `additionalProperties: false`, as the Lenovo
    card does, so MAGIC's model learns the exact fields."""

    model_config = ConfigDict(extra="forbid")

    request_id: str | None = Field(default=None, max_length=128, description="MAGIC's random request number; echoed")
    role: str | None = Field(default=None, max_length=64, description="The role MAGIC asks this part for; echoed")


class Envelope(BaseModel):
    """The data part MAGIC sends: which skill, and its request."""

    model_config = ConfigDict(extra="forbid")

    skill: str = Field(min_length=1, max_length=64)
    request: dict[str, Any] = Field(default_factory=dict)


class Warning(BaseModel):
    code: str
    message: str


class Refusal(BaseModel):
    code: str
    message: str
    question: str | None = None


class Usage(BaseModel):
    """What the answer cost: model tokens and wall-clock seconds."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    seconds: float = 0.0


class Answer(BaseModel):
    """The envelope of one skill call, in the shape MAGIC reads."""

    contract: str = CONTRACT
    status: Status
    warnings: list[Warning] = Field(default_factory=list)
    files: list[dict[str, Any]] = Field(default_factory=list)
    result: dict[str, Any] | None = None
    refusal: Refusal | None = None
    usage: Usage | None = None
    request_id: str | None = None
    role: str | None = None

    def text(self) -> str:
        """One sentence for a person, used as the task's status message."""
        if self.refusal is not None:
            return self.refusal.message
        if isinstance(self.result, dict):
            for key in ("answer", "summary", "name"):
                if isinstance(self.result.get(key), str) and self.result[key].strip():
                    return self.result[key]
        return "Done."


class SkillError(Exception):
    """A refusal raised by a skill: the call fails with this code and message, and no result."""

    def __init__(self, code: str, message: str, *, question: str | None = None, usage: Usage | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.question = question
        # What the failed call still cost, when a model was asked before the refusal.
        self.usage = usage


class Outcome:
    """What a skill handler returns: a result, what it cost, and the files it made. A file is
    `{"url", "name", "media_type"}`, the shape MAGIC reads from the envelope's `files`."""

    __slots__ = ("result", "usage", "warnings", "status", "files")

    def __init__(self, result: dict[str, Any], *, usage: Usage | None = None,
                 warnings: list[Warning] | None = None, status: Status = "complete",
                 files: list[dict[str, Any]] | None = None) -> None:
        self.result = result
        self.usage = usage
        self.warnings = warnings or []
        self.status = status
        self.files = files or []


def echoed(request: Any) -> dict[str, str | None]:
    """`request_id` and `role` as sent, even when the rest of the request was refused."""
    given = request if isinstance(request, dict) else {}
    return {key: given[key] if isinstance(given.get(key), str) else None for key in ("request_id", "role")}


def refused(code: str, message: str, request: Any = None, *, question: str | None = None,
            usage: Usage | None = None) -> Answer:
    return Answer(status="failed", refusal=Refusal(code=code, message=message, question=question),
                  usage=usage, **echoed(request))


def completed(outcome: Outcome, request: Any = None) -> Answer:
    return Answer(status=outcome.status, result=outcome.result, warnings=outcome.warnings, usage=outcome.usage,
                  files=outcome.files, **echoed(request))


def validation_message(failure: ValidationError) -> str:
    """The first problem of a request, in one line a person can act on."""
    first = failure.errors()[0] if failure.errors() else {}
    where = ".".join(str(part) for part in first.get("loc", ())) or "request"
    return f"{where}: {first.get('msg', 'invalid')}"


class Clock:
    """Wall-clock seconds of one call, for the usage block and the log line."""

    def __init__(self) -> None:
        self.started = time.perf_counter()

    def seconds(self) -> float:
        return round(time.perf_counter() - self.started, 3)
