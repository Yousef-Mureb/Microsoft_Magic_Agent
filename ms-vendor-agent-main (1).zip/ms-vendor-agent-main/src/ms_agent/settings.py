"""All configuration, read from environment variables (and a local `.env` in development).

The names are documented in `.env.example`. Nothing here holds a real value.
"""

from __future__ import annotations

from pathlib import Path
from typing import Literal

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

# `data/` at the repository root, and at `/app/data` in the container (the package is `/app/src/ms_agent`).
DATA_DIR = Path(__file__).resolve().parents[2] / "data"


class Settings(BaseSettings):
    """Configuration of one running agent. Field names match the environment variable names,
    case-insensitively, so `MS_AGENT_API_KEYS` fills `ms_agent_api_keys`."""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # Comma-separated client keys accepted in the `x-api-key` header. Environment variable in
    # development; Azure Key Vault supplies them at a later step (see `auth.py`).
    ms_agent_api_keys: SecretStr = Field(default=SecretStr(""))
    # Public base address the agent card advertises. MAGIC requires the JSON-RPC endpoint to be
    # on the same host as the card, so both are derived from this one value.
    ms_agent_public_url: str = "http://localhost:8080"
    ms_agent_log_level: str = "INFO"

    # Azure OpenAI through the official `openai` SDK: endpoint and deployment names from the
    # environment; the key from the environment now, managed identity later (see `llm/client.py`).
    azure_openai_endpoint: str | None = None
    azure_openai_api_key: SecretStr | None = None
    azure_openai_api_version: str = "2024-10-21"
    azure_openai_chat_deployment: str | None = None
    azure_openai_embedding_deployment: str | None = None
    # Optional cap on generated tokens, sent as `max_completion_tokens` (never `max_tokens`, which
    # reasoning models refuse). For a reasoning model it includes the hidden reasoning tokens, so a
    # low value can leave the answer empty; unset means the model's own limit.
    azure_openai_max_completion_tokens: int | None = None

    # The Microsoft Learn MCP (Model Context Protocol) server that retrieves documentation passages.
    learn_mcp_url: str = "https://learn.microsoft.com/api/mcp"

    # The price store: SQLite in development and tests, PostgreSQL in Azure, same schema (`pricing/store.py`).
    ms_agent_price_db_url: str = "sqlite:///prices.sqlite3"
    # What the nightly ingestion pulls from the Azure Retail Prices API, comma-separated. Filter values are
    # case-sensitive: `uaenorth`, `Compute`. USD is Microsoft's list price; other currencies are for reference.
    ms_agent_price_regions: str = "uaenorth,uaecentral,westeurope,northeurope,eastus"
    ms_agent_price_families: str = "Compute,Storage,Networking,Databases"
    ms_agent_price_currencies: str = "USD"
    # Services ingested by serviceName in every region, after the families: the designs' baseline. Load Balancer
    # is ingested under armRegionName 'Global', where Microsoft publishes its meters.
    ms_agent_price_services: str = ("Application Gateway,Backup,Key Vault,Log Analytics,Microsoft Defender for Cloud,"
                                    "Azure Bastion,Azure Site Recovery,API Management")
    ms_agent_price_global_services: str = "Load Balancer"
    # VM size snapshots `vm_sizes_<region>.json` (`pricing/vm_catalog.py`), and the families sizing may choose.
    ms_agent_data_dir: Path = DATA_DIR
    ms_agent_vm_families: str = "D,E,F,B"

    # Files the agent makes (`files.py`): a local folder in development, Azure Blob Storage in Azure.
    ms_agent_files_backend: Literal["local", "blob"] = "local"
    ms_agent_files_dir: str = "files"
    azure_storage_account_url: str | None = None
    azure_storage_container: str = "estimates"
    # The user-assigned managed identity's client id, for Azure OpenAI and Blob Storage without keys.
    azure_client_id: str | None = None

    @property
    def price_regions(self) -> list[str]:
        return _listed(self.ms_agent_price_regions)

    @property
    def price_families(self) -> list[str]:
        return _listed(self.ms_agent_price_families)

    @property
    def price_services(self) -> list[str]:
        return _listed(self.ms_agent_price_services)

    @property
    def price_global_services(self) -> list[str]:
        return _listed(self.ms_agent_price_global_services)

    @property
    def price_currencies(self) -> list[str]:
        return [currency.upper() for currency in _listed(self.ms_agent_price_currencies)]

    @property
    def vm_families(self) -> list[str]:
        return [family.upper() for family in _listed(self.ms_agent_vm_families)]

    @property
    def api_keys(self) -> list[str]:
        """The client keys, without blanks."""
        raw = self.ms_agent_api_keys.get_secret_value()
        return [key.strip() for key in raw.split(",") if key.strip()]

    @property
    def model_configured(self) -> bool:
        """Whether a chat model can be built: endpoint and chat deployment are set. The key is optional: without
        it the agent signs in with the managed identity (`llm/client.py`)."""
        return bool(self.azure_openai_endpoint and self.azure_openai_chat_deployment)


def _listed(raw: str) -> list[str]:
    """A comma-separated setting as a list, without blanks."""
    return [item.strip() for item in raw.split(",") if item.strip()]
