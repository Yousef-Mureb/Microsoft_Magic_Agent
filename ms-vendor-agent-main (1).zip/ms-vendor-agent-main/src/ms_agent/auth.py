"""The client key check.

MAGIC sends the key in the header the agent card names (`x-api-key`) and, for good measure, as
`Authorization: Bearer <key>`; HTTP 401 means "the agent refused the key". Keys are loaded once
at start from `MS_AGENT_API_KEYS` (development). At a later step `KeyRing.from_settings` is where
Azure Key Vault supplies them instead; nothing else changes.
"""

from __future__ import annotations

import secrets

from fastapi import HTTPException, Request

from ms_agent.settings import Settings

HEADER = "x-api-key"


class KeyRing:
    """The keys the agent accepts. Comparison is constant-time."""

    def __init__(self, keys: list[str]) -> None:
        if not keys:
            raise ValueError("No client key is configured: set MS_AGENT_API_KEYS.")
        self._keys = [key.encode("utf-8") for key in keys]

    @classmethod
    def from_settings(cls, settings: Settings) -> KeyRing:
        # Extension point: read the keys from Azure Key Vault here when the agent runs in Azure.
        return cls(settings.api_keys)

    def accepts(self, given: str | None) -> bool:
        if not given:
            return False
        candidate = given.encode("utf-8")
        return any(secrets.compare_digest(candidate, key) for key in self._keys)

    def presented(self, request: Request) -> str | None:
        """The key as the request carries it: the header first, then the bearer token."""
        header = request.headers.get(HEADER)
        if header:
            return header.strip()
        authorization = request.headers.get("authorization", "")
        scheme, _, token = authorization.partition(" ")
        if scheme.lower() == "bearer" and token.strip():
            return token.strip()
        return None

    def require(self, request: Request) -> None:
        """Raise 401 unless the request carries an accepted key."""
        if not self.accepts(self.presented(request)):
            raise HTTPException(status_code=401, detail={"error": "unauthorized",
                                                         "message": f"Send a valid client key in {HEADER}."},
                                headers={"WWW-Authenticate": "ApiKey"})
