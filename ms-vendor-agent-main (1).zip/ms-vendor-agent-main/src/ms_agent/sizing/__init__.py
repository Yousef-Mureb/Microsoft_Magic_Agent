"""Sizing: virtual machine sizes and disks for workloads, and the priced estimate. Code only, no model."""
