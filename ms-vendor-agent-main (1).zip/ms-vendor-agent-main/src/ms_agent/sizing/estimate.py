"""An estimate: priced lines, totals per pricing model, assumptions and sources.

A line is one thing billed: a virtual machine's compute, its Windows licence, or a set of disks.
Each line has a unit price per pricing model (a `Price` with its provenance, or None where the model
has no price) and its monthly cost:

- hourly price × hours per month × quantity (pay-as-you-go, savings plans, the Windows licence);
- monthly price × quantity (managed disks; and meters per unit used, the quantity being the units a month);
- term price ÷ months of the term × quantity (reservations, paid whatever the hours).

Each monthly figure is rounded to the cent, as the workbook's `ROUND(..., 2)` does, so the totals
of the workbook and of this module are the same numbers. Yearly is monthly × 12.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP, Decimal
from typing import Any

from ms_agent.pricing.lookup import LABELS, Price, Source

CENT = Decimal("0.01")
COMMITMENTS = ("payg", "ri_1y", "ri_3y", "sp_1y", "sp_3y")
SHORT_LABELS = {"payg": "PAYG", "ri_1y": "1y RI", "ri_3y": "3y RI", "sp_1y": "1y SP", "sp_3y": "3y SP", "ahb": "AHB"}


def cents(value: Decimal) -> Decimal:
    return value.quantize(CENT, rounding=ROUND_HALF_UP)


def monthly_of(price: Price, hours: Decimal, quantity: int | Decimal) -> Decimal:
    """One line's monthly cost under one price, to the cent."""
    if price.basis == "hourly":
        return cents(price.value * hours * quantity)
    if price.basis == "monthly":
        return cents(price.value * quantity)
    if price.basis == "term":
        return cents(price.value / price.term_months * quantity)
    raise ValueError(f"A price per {price.unit} has no monthly cost.")


@dataclass
class Line:
    workload: str
    service: str
    sku: str
    description: str
    region: str
    quantity: int | Decimal  # machines, disks, or units of the meter a month (GB, 10K operations)
    hours: Decimal
    prices: dict[str, Price | None]

    def monthly(self, model: str) -> Decimal | None:
        price = self.prices.get(model)
        return None if price is None else monthly_of(price, self.hours, self.quantity)

    def yearly(self, model: str) -> Decimal | None:
        monthly = self.monthly(model)
        return None if monthly is None else monthly * 12

    def as_dict(self, models: list[str]) -> dict[str, Any]:
        by_model: dict[str, Any] = {}
        for model in models:
            price = self.prices.get(model)
            if price is None:
                by_model[model] = None
                continue
            monthly = monthly_of(price, self.hours, self.quantity)
            by_model[model] = price.as_dict() | {"monthly": float(monthly), "yearly": float(monthly * 12)}
        quantity = self.quantity if isinstance(self.quantity, int) else float(self.quantity)
        return {"workload": self.workload, "service": self.service, "sku": self.sku,
                "description": self.description, "region": self.region, "quantity": quantity,
                "hours_per_month": float(self.hours), "by_model": by_model}


@dataclass
class Estimate:
    region: str
    currency: str
    models: list[str]
    headline: str
    lines: list[Line] = field(default_factory=list)
    assumptions: list[str] = field(default_factory=list)
    fetched_at: str = ""
    # What the design draws but the estimate does not price, by name (a VPN Gateway, ExpressRoute).
    not_priced: list[str] = field(default_factory=list)

    def total(self, model: str) -> Decimal:
        """The monthly total of the lines that have a price under the model."""
        return sum((monthly for line in self.lines if (monthly := line.monthly(model)) is not None), Decimal("0"))

    def missing(self, model: str) -> int:
        return sum(line.prices.get(model) is None for line in self.lines)

    def sources(self) -> list[Source]:
        seen: dict[tuple[str, str], Source] = {}
        for line in self.lines:
            for price in line.prices.values():
                for source in price.sources if price else ():
                    seen.setdefault((source.url, source.field), source)
        return list(seen.values())

    def totals(self) -> dict[str, dict[str, Any]]:
        return {model: {"label": LABELS[model], "monthly": float(self.total(model)),
                        "yearly": float(self.total(model) * 12), "currency": self.currency,
                        "complete": self.missing(model) == 0, "lines_without_price": self.missing(model)}
                for model in self.models}
