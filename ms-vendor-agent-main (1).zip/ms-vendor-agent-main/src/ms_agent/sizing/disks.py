"""Managed disks: the tier for a size, and its monthly list price.

A managed disk is billed by its tier, the smallest one that holds the size asked. Sizes are GiB,
as Azure sells them. Only the disk itself is priced: Standard SSD and Standard HDD transactions,
snapshots and bursting are billed apart and are named in the estimate's assumptions.
"""

from __future__ import annotations

from typing import Literal

DiskType = Literal["premium_ssd", "standard_ssd", "standard_hdd"]

_SIZES = (4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32767)
_NUMBERS = (1, 2, 3, 4, 6, 10, 15, 20, 30, 40, 50, 60, 70, 80)
TIERS: dict[str, tuple[tuple[str, int], ...]] = {
    "premium_ssd": tuple((f"P{number}", size) for number, size in zip(_NUMBERS, _SIZES, strict=True)),
    "standard_ssd": tuple((f"E{number}", size) for number, size in zip(_NUMBERS, _SIZES, strict=True)),
    # Standard HDD starts at S4 (32 GiB).
    "standard_hdd": tuple((f"S{number}", size) for number, size in zip(_NUMBERS[3:], _SIZES[3:], strict=True)),
}
NAMES = {"premium_ssd": "Premium SSD", "standard_ssd": "Standard SSD", "standard_hdd": "Standard HDD"}


def tier_for(disk_type: str, size_gib: int) -> tuple[str, int]:
    """The smallest tier of the type that holds `size_gib`, and its size."""
    for tier, size in TIERS[disk_type]:
        if size >= size_gib:
            return tier, size
    raise ValueError(f"No {NAMES[disk_type]} disk holds {size_gib} GiB; the largest is {TIERS[disk_type][-1][1]} GiB.")
