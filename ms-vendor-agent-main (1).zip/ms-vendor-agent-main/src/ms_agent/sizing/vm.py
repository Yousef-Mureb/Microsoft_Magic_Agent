"""Choosing a virtual machine size: the cheapest that meets vCPU and memory, the newest generation on a tie.

The candidates are the catalog's sizes of the allowed families (default D, E, F, B) with at least the
vCPU and memory asked. Arm64 sizes (`D4ps_v6`: Windows and most x64 software do not run on them) and
constrained-core sizes (`E8-4s_v5`: the parent's price with fewer cores, for per-core licensing) are
left out, with the reason. They are ranked by: a price under every pricing model before a size with
gaps (a B-series size has no reservation in UAE North, which would leave the reservation totals
incomplete), then the monthly cost of one machine under the leading pricing model, then the newest
generation (v7, v6, then v5), then fewer vCPU and less memory. A size the price store cannot price
under the leading model in the region is excluded. Code only, no model.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from decimal import Decimal

from ms_agent.pricing.vm_catalog import VmCatalog, VmSize

ALTERNATIVES = 3
# The answer lists at most this many excluded sizes, with a count of the rest.
EXCLUDED_SHOWN = 10


class NoSize(LookupError):
    """No size meets the workload; the message says why."""


@dataclass(frozen=True)
class Ranked:
    size: VmSize
    current_generation: bool
    monthly: Decimal
    rank: int
    reason: str


@dataclass
class Choice:
    chosen: Ranked
    alternatives: list[Ranked]
    excluded: list[dict[str, str]] = field(default_factory=list)


def _spec(size: VmSize) -> str:
    return f"{size.vcpu} vCPU, {size.memory_gib:g} GiB"


def _summarised(excluded: list[dict[str, str]]) -> list[dict[str, str]]:
    if len(excluded) <= EXCLUDED_SHOWN:
        return excluded
    rest = len(excluded) - EXCLUDED_SHOWN
    return excluded[:EXCLUDED_SHOWN] + [{"size": f"{rest} more", "reason": "excluded for the same reasons"}]


def choose(catalog: VmCatalog, *, vcpu: int, memory_gib: float, families: list[str],
           monthly: Callable[[VmSize], Decimal | None], label: str, currency: str,
           gaps: Callable[[VmSize], list[str]] | None = None) -> Choice:
    """The size to use and the next `ALTERNATIVES`, each with the reason for its rank. `monthly` prices one
    machine of a size per month under the leading pricing model, or None when the store cannot. `gaps` names
    the other pricing models a size has no price for."""
    gaps = gaps or (lambda size: [])
    fitting = [size for size in catalog.sizes
               if size.family in families and size.vcpu >= vcpu and size.memory_gib >= memory_gib]
    if not fitting:
        raise NoSize(f"No size of the families {', '.join(families)} in the {catalog.region} catalog has at least "
                     f"{vcpu} vCPU and {memory_gib:g} GiB.")
    priced: list[tuple[VmSize, bool, Decimal, list[str]]] = []
    excluded: list[dict[str, str]] = []
    for size in fitting:
        if size.arm64:
            excluded.append({"size": size.name, "reason": "Arm64: Windows and most x64 software do not run on it"})
            continue
        if size.constrained_cores:
            excluded.append({"size": size.name, "reason": "constrained cores: the parent size's price with fewer "
                                                          "active cores, for per-core licensing"})
            continue
        cost = monthly(size)
        if cost is None:
            excluded.append({"size": size.name, "reason": f"no {label.lower()} price in {catalog.region}"})
        else:
            priced.append((size, catalog.current_generation(size), cost, gaps(size)))
    if not priced:
        raise NoSize(f"None of the {len(fitting)} sizes that fit is an x64 size with a {label.lower()} price in "
                     f"{catalog.region}.")
    priced.sort(key=lambda one: (bool(one[3]), one[2], -one[0].generation, one[0].vcpu, one[0].memory_gib,
                                 one[0].name))
    first_size, first_current, first_cost, first_gaps = priced[0]
    complete = "" if first_gaps else " priced under every pricing model"
    tied = [one for one in priced[1:] if one[2] == first_cost and bool(one[3]) == bool(first_gaps)]
    reason = (f"Cheapest size{complete} with at least {vcpu} vCPU and {memory_gib:g} GiB in the families "
              f"{', '.join(families)}: {_spec(first_size)}, generation v{first_size.generation}, {first_cost:.2f} "
              f"{currency} a month per machine at {label.lower()}.")
    if tied:
        reason += f" {len(tied)} other size(s) cost the same; the newest generation is preferred."
    if first_gaps:
        reason += f" No {', '.join(first_gaps)} price in {catalog.region}."
    ranked = [Ranked(first_size, first_current, first_cost, 1, reason)]
    for rank, (size, current, cost, missing) in enumerate(priced[1:ALTERNATIVES + 1], start=2):
        difference = cost - first_cost
        percent = (difference / first_cost * 100) if first_cost else Decimal("0")
        words = [f"Rank {rank}: {_spec(size)}, generation v{size.generation}, {cost:.2f} {currency} a month per "
                 "machine"]
        if difference > 0:
            words.append(f"{difference:.2f} {currency} ({percent:.1f} %) more than {first_size.short_name}")
        elif difference < 0:
            words.append(f"{-difference:.2f} {currency} cheaper than {first_size.short_name}, but it has no "
                         f"{', '.join(missing)} price in {catalog.region}, so the estimate could not compare every "
                         "pricing model")
        elif size.generation < first_size.generation:
            words.append(f"the same cost as {first_size.short_name}, an older generation")
        else:
            words.append(f"the same cost as {first_size.short_name}, more vCPU or memory than needed")
        if missing and difference >= 0:
            words.append(f"no {', '.join(missing)} price in {catalog.region}")
        if size.family == "B":
            words.append("burstable B-series")
        ranked.append(Ranked(size, current, cost, rank, "; ".join(words) + "."))
    return Choice(chosen=ranked[0], alternatives=ranked[1:], excluded=_summarised(excluded))
