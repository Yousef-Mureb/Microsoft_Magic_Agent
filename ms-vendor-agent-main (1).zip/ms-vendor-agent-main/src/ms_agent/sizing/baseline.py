"""The services every design carries, priced from the Retail Prices API: the front door chosen by traffic, Key
Vault, Log Analytics, Defender for Servers Plan 2, Azure Bastion, Azure Backup and, with a DR region, Azure Site
Recovery and the replica disks.

Each is an estimate line priced from one exact meter (service, product, SKU, meter, as the API names them), with
its source URL, `effectiveStartDate` and `fetched_at`. Where a quantity is assumed (gigabytes of logs, Key Vault
operations, capacity units), the assumption is stated on the line and on the Assumptions sheet. These services are
not covered by reservations or savings plans, so a line has the same price in every column. A meter the store
does not hold is named on its line and in the gaps, never "no matching meters".
"""

from __future__ import annotations

import math
from collections.abc import Callable
from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP, Decimal
from typing import Any

from ms_agent.pricing.lookup import Price, PriceNotFound, disk_price, meter_price
from ms_agent.pricing.store import PriceStore
from ms_agent.sizing.disks import NAMES
from ms_agent.sizing.estimate import Line
from ms_agent.sizing.workloads import SizedWorkload

HOURS = Decimal("730")
DAYS_A_MONTH = HOURS / 24  # 30.42
BACKUP_BAND_GIB = 500  # Azure Backup charges an instance per started 500 GB (pricing page, stage 0)
SHARED = "(shared)"
# Application Gateway WAF v2 capacity units charged every hour when the request does not say: a pilot's load.
DEFAULT_GATEWAY_CAPACITY_UNITS = 2


@dataclass(frozen=True)
class Quantities:
    """The assumed quantities, all stated on the Assumptions sheet."""

    log_gb_per_vm_day: Decimal = Decimal("0.5")
    key_vault_operations: int = 100_000
    gateway_capacity_units: int = 2  # DEFAULT_GATEWAY_CAPACITY_UNITS; a request input of design_propose
    load_balancer_gb: int = 100
    backup_storage_factor: Decimal = Decimal("1.5")  # 30 daily recovery points, GRS, of the provisioned disk size


@dataclass
class Baseline:
    lines: list[Line] = field(default_factory=list)
    items: list[dict[str, Any]] = field(default_factory=list)  # solution items, with how they are drawn
    assumptions: list[str] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)


def _two(value: Decimal) -> Decimal:
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


class _Builder:
    def __init__(self, store: PriceStore, models: list[str], currency: str) -> None:
        self.store, self.models, self.currency = store, models, currency
        self.out = Baseline()

    def price(self, get: Callable[[], Price]) -> Price | None:
        try:
            return get()
        except PriceNotFound as failure:
            self.out.missing.append(str(failure))
            return None

    def line(self, workload: str, service: str, sku: str, description: str, region: str, quantity: int | Decimal,
             price: Price | None, hours: Decimal = HOURS) -> Line:
        made = Line(workload, service, sku, description, region, quantity, hours, dict.fromkeys(self.models, price))
        self.out.lines.append(made)
        return made

    def meter(self, region: str, service: str, product: str, sku: str, meter: str, tier: float = 0.0) -> Price | None:
        return self.price(lambda: meter_price(self.store, region, service=service, product=product, sku=sku,
                                              meter=meter, tier=tier, currency=self.currency))


def baseline(store: PriceStore, workloads: list[SizedWorkload], *, region: str, dr_region: str | None,
             front: str | None, tcp: bool, models: list[str], currency: str = "USD",
             quantities: Quantities | None = None) -> Baseline:
    """The design's service lines. `front`: `app_gateway` or `api_management` for HTTP workloads, None without
    any; `tcp`: a Standard Load Balancer for non-HTTP traffic from outside."""
    quantities = quantities or Quantities()
    build = _Builder(store, models, currency)
    out = build.out
    machines = sum(one.spec.count for one in workloads)

    if front == "app_gateway":
        fixed = build.meter(region, "Application Gateway", "Application Gateway WAF v2", "Standard",
                            "Standard Fixed Cost")
        units = build.meter(region, "Application Gateway", "Application Gateway WAF v2", "Standard",
                            "Standard Capacity Units")
        build.line(SHARED, "Application Gateway", "WAF v2", "Application Gateway WAF v2, fixed cost per gateway hour",
                   region, 1, fixed)
        capacity = quantities.gateway_capacity_units
        build.line(SHARED, "Application Gateway", "WAF v2 capacity units",
                   f"Application Gateway WAF v2 capacity units: {capacity} every hour, assumed (request input "
                   f"gateway_capacity_units; default {DEFAULT_GATEWAY_CAPACITY_UNITS}, for a pilot)", region,
                   capacity, units)
        out.assumptions.append(f"Application Gateway WAF v2: the fixed cost plus {capacity} capacity units every "
                               f"hour (request input gateway_capacity_units; default {DEFAULT_GATEWAY_CAPACITY_UNITS}, "
                               "for a pilot). More traffic, connections or WAF rules use more capacity units; size it "
                               "from the expected load for production.")
        out.items.append({"role": "network", "service": "Azure Application Gateway", "name": "Application Gateway "
                          "WAF v2", "item": "WAF v2, zone-redundant, in front of the HTTP workloads", "priced": True,
                          "kind": "app_gateway", "placement": "front", "detail": "WAF v2, zone-redundant"})
    elif front == "api_management":
        unit = build.meter(region, "API Management", "API Management", "Standard v2", "Standard v2 Unit")
        build.line(SHARED, "API Management", "Standard v2", "API Management Standard v2, 1 unit", region, 1, unit)
        out.assumptions.append("API Management Standard v2, one unit; zone redundancy in API Management needs a "
                               "Premium tier, priced separately if required.")
        out.items.append({"role": "network", "service": "Azure API Management", "name": "API Management",
                          "item": "Standard v2, 1 unit, publishing the APIs to third parties", "priced": True,
                          "kind": "api_management", "placement": "front", "detail": "Standard v2, 1 unit"})
    if tcp:
        rules = build.meter("Global", "Load Balancer", "Load Balancer", "Standard",
                            "Standard Included LB Rules and Outbound Rules")
        processed = build.meter("Global", "Load Balancer", "Load Balancer", "Standard", "Standard Data Processed")
        build.line(SHARED, "Load Balancer", "Standard", "Standard Load Balancer, first 5 rules (Microsoft publishes "
                   "these meters under 'Global')", region, 1, rules)
        build.line(SHARED, "Load Balancer", "Standard data processed",
                   f"Standard Load Balancer, {quantities.load_balancer_gb} GB processed a month assumed", region,
                   quantities.load_balancer_gb, processed)
        out.assumptions.append(f"Standard Load Balancer: up to 5 rules, {quantities.load_balancer_gb} GB processed a "
                               "month.")
        out.items.append({"role": "network", "service": "Azure Load Balancer", "name": "Standard Load Balancer",
                          "item": "Standard, zone-redundant, for the non-HTTP traffic", "priced": True,
                          "kind": "load_balancer", "placement": "front", "detail": "Standard, zone-redundant"})

    operations = quantities.key_vault_operations
    build.line(SHARED, "Key Vault", "Standard operations", f"Key Vault Standard: {operations:,} operations a month "
               "assumed (the price is per 10,000)", region, operations // 10_000,
               build.meter(region, "Key Vault", "Key Vault", "Standard", "Operations"))
    out.assumptions.append(f"Key Vault Standard: {operations:,} operations a month; keys and certificates are not "
                           "priced.")
    out.items.append({"role": "security", "service": "Azure Key Vault", "name": "Key Vault", "item": "Standard, "
                      "secrets and certificates of the workloads", "priced": True, "kind": "key_vault",
                      "placement": "shared", "detail": "Standard"})

    gigabytes = _two(machines * quantities.log_gb_per_vm_day * DAYS_A_MONTH)
    build.line(SHARED, "Log Analytics", "Analytics Logs ingestion",
               f"Log Analytics, {gigabytes} GB a month assumed ({quantities.log_gb_per_vm_day} GB a day for each of "
               f"the {machines} VMs)", region, gigabytes,
               build.meter(region, "Log Analytics", "Log Analytics", "Analytics Logs", "Analytics Logs Data Ingestion",
                           tier=5.0))
    out.assumptions.append(f"Log Analytics: {quantities.log_gb_per_vm_day} GB of logs a day per VM, Analytics Logs, "
                           "the default retention included; the first 5 GB a month free per billing account is not "
                           "deducted.")
    out.items.append({"role": "monitoring", "service": "Azure Monitor Log Analytics", "name": "Log Analytics",
                      "item": f"one workspace, {gigabytes} GB a month", "priced": True, "kind": "log_analytics",
                      "placement": "shared", "detail": "workspace"})

    defender = build.meter(region, "Microsoft Defender for Cloud", "Microsoft Defender for Servers", "Standard P2",
                           "Standard P2 Node")
    for one in workloads:
        build.line(one.spec.name, "Microsoft Defender for Cloud", "Servers Plan 2",
                   f"Defender for Servers Plan 2, per server hour, {one.spec.count} servers", region, one.spec.count,
                   defender, hours=Decimal(repr(float(one.spec.hours_per_month))))
    out.items.append({"role": "security", "service": "Microsoft Defender for Cloud", "name": "Defender for Cloud",
                      "item": f"Defender for Servers Plan 2 on the {machines} VMs", "priced": True, "kind": "defender",
                      "placement": "shared", "detail": "Servers Plan 2"})

    build.line(SHARED, "Azure Bastion", "Basic", "Azure Bastion Basic, per gateway hour (outbound data beyond the "
               "free 5 GB a month not included)", region, 1,
               build.meter(region, "Azure Bastion", "Azure Bastion", "Basic", "Basic Gateway"))
    out.items.append({"role": "network", "service": "Azure Bastion", "name": "Azure Bastion", "item": "Basic, "
                      "administrator access without public IP addresses on the VMs", "priced": True,
                      "kind": "bastion", "placement": "management", "detail": "Basic"})

    instance = build.meter(region, "Backup", "Backup", "Azure VM", "Azure VM Protected Instance")
    stored = build.meter(region, "Backup", "Backup", "Standard", "Standard GRS Data Stored")
    protected_total = 0
    for one in workloads:
        size = one.disk_gib_per_machine
        bands = max(1, math.ceil(size / BACKUP_BAND_GIB))
        protected_total += size * one.spec.count
        build.line(one.spec.name, "Backup", "Azure VM protected instance",
                   f"Azure Backup, {one.spec.count} VMs of {size} GiB of disks: {bands} protected-instance unit(s) "
                   f"each (one per started {BACKUP_BAND_GIB} GB)", region, one.spec.count * bands, instance)
    backup_gb = _two(protected_total * quantities.backup_storage_factor)
    build.line(SHARED, "Backup", "GRS storage", f"Azure Backup storage, GRS: {backup_gb} GB a month assumed "
               f"({quantities.backup_storage_factor} × the {protected_total} GiB of protected disks)", region,
               backup_gb, stored)
    out.assumptions.append(f"Azure Backup: daily backup of every VM; the protected size is the provisioned size of its "
                           f"disks; one protected-instance unit per started {BACKUP_BAND_GIB} GB (an instance of "
                           "50 GB or less is priced as the 50–500 GB band, which is conservative); backup storage "
                           f"GRS, {quantities.backup_storage_factor} × the protected size (30 daily recovery points).")
    out.items.append({"role": "backup", "service": "Azure Backup", "name": "Recovery Services vault",
                      "item": f"daily backup of the {machines} VMs, GRS storage", "priced": True,
                      "kind": "recovery_vault", "placement": "shared", "detail": f"Azure Backup, {machines} VMs"})

    if dr_region:
        build.line(SHARED, "Azure Site Recovery", "VM replicated to Azure",
                   f"Azure Site Recovery, {machines} VMs replicated to {dr_region}", dr_region, machines,
                   build.meter(dr_region, "Azure Site Recovery", "Azure Site Recovery", "Azure",
                               "VM Replicated to Azure"))
        for one in workloads:
            for disk in one.disks:
                tier = str(disk["tier"])
                price = build.price(lambda disk=disk, tier=tier: disk_price(store, str(disk["type"]), tier, dr_region,
                                                                             currency))
                build.line(one.spec.name, "Managed Disks", f"{tier} LRS replica",
                           f"Replica of the {disk['role']} disk in {dr_region}: {NAMES[str(disk['type'])]} {tier}",
                           dr_region, one.spec.count * int(disk["count_per_machine"]), price)
        out.assumptions.append(f"Disaster recovery to {dr_region}: Azure Site Recovery per protected VM and the "
                               "replica disks, same tiers, priced there; the recovery VMs are billed only while "
                               "they run after a failover or a test and are not priced; the cache storage account in "
                               "the primary region is not priced.")
        out.items.append({"role": "dr", "service": "Azure Site Recovery", "name": "Azure Site Recovery",
                          "item": f"replication of the {machines} VMs to {dr_region}", "region": dr_region,
                          "priced": True, "kind": "site_recovery", "placement": "dr",
                          "detail": f"{machines} VMs replicated"})
    return out
