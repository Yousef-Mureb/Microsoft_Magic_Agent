"""From workloads to sizes and a priced estimate: what `sizing_calc` and `design_propose` share.

For each workload: the size (`sizing/vm.py`, ranked on the leading pricing model), its lines and its
disks' lines. The estimate's columns are the five commitments (pay-as-you-go, 1- and 3-year
reservations, 1- and 3-year savings plans), plus Azure Hybrid Benefit where it applies: when a
Windows machine is priced with its licence, the AHB column shows pay-as-you-go with the licence
brought by the customer. With `ahb` true, every Windows machine is priced at the Linux meter in every
column, and that is said on each line and in the assumptions.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from decimal import Decimal

from ms_agent.contract import Warning
from ms_agent.pricing.lookup import (
    LABELS,
    LIST_PRICE_NOTICE,
    Price,
    PriceNotFound,
    disk_price,
    price_for,
    windows_licence,
)
from ms_agent.pricing.store import PriceStore
from ms_agent.pricing.vm_catalog import VmCatalog, VmSize
from ms_agent.sizing.disks import NAMES, tier_for
from ms_agent.sizing.estimate import COMMITMENTS, Estimate, Line, monthly_of
from ms_agent.sizing.vm import Choice, NoSize, choose


@dataclass(frozen=True)
class DiskSpec:
    type: str
    size_gb: int
    count: int = 1


@dataclass(frozen=True)
class WorkloadSpec:
    name: str
    vcpu: int
    memory_gb: float
    os: str = "linux"
    count: int = 1
    hours_per_month: float = 730
    disks: tuple[DiskSpec, ...] = ()
    # `http` (reached through the front door), `tcp` (through a load balancer), `internal` (not reached from outside)
    traffic: str = "internal"
    # B-series (burstable) sizes are chosen only for `dev_test`.
    environment: str = "production"
    # None: Premium SSD P10 (128 GiB) for Linux, P15 (256 GiB) for Windows.
    os_disk: DiskSpec | None = None

    @property
    def os_disk_or_default(self) -> DiskSpec:
        return self.os_disk or DiskSpec("premium_ssd", 256 if self.os == "windows" else 128)


@dataclass
class SizedWorkload:
    spec: WorkloadSpec
    choice: Choice
    disks: list[dict[str, object]] = field(default_factory=list)

    @property
    def disk_gib_per_machine(self) -> int:
        """The provisioned size of one machine's disks, OS disk included: what Azure Backup protects."""
        return sum(int(disk["tier_gib"]) * int(disk["count_per_machine"]) for disk in self.disks)


@dataclass
class Sizing:
    estimate: Estimate
    workloads: list[SizedWorkload]
    warnings: list[Warning]
    catalog: VmCatalog


Prices = dict[str, Price | None]


class CachedStore:
    """The price store's answers, kept for one sizing: each size is priced under six models from the same
    few meters, and the real catalog has hundreds of candidate sizes."""

    def __init__(self, store: PriceStore) -> None:
        self._store = store
        self._found: dict[tuple, list] = {}

    def find(self, *, currency: str = "USD", types: tuple[str, ...] | None = None, limit: int | None = None,
             **equals: str):
        key = (currency, tuple(types) if types else None, limit, tuple(sorted(equals.items())))
        if key not in self._found:
            self._found[key] = self._store.find(currency=currency, types=types, limit=limit, **equals)
        return self._found[key]

    def count(self) -> int:
        return self._store.count()


def _found(get: Callable[[], Price]) -> Price | None:
    try:
        return get()
    except PriceNotFound:
        return None


def machine_prices(store: PriceStore, size: str, region: str, os: str, ahb: bool, models: list[str],
                   currency: str) -> list[tuple[str, Prices]]:
    """The priced parts of one machine: its compute, and for Windows without AHB its licence."""
    def get(os_name: str, model: str) -> Price | None:
        return _found(lambda: price_for(store, size, region, os_name, model, currency))  # type: ignore[arg-type]

    compute: Prices = {}
    for model in models:
        if model == "ahb" or (model == "payg" and os == "windows" and ahb):
            # Azure Hybrid Benefit is the Linux meter; a Linux machine in the AHB column pays pay-as-you-go.
            compute[model] = get("windows", "ahb") if os == "windows" else get("linux", "payg")
        elif model == "payg":
            compute[model] = get("linux", "payg")
        else:
            compute[model] = get(os, model)
    parts: list[tuple[str, Prices]] = [("compute", compute)]
    if os == "windows" and not ahb:
        licence = _found(lambda: windows_licence(store, size, region, currency))
        prices: Prices = {model: licence for model in models if model != "ahb"}
        if "ahb" in models:
            covered = compute.get("ahb")
            prices["ahb"] = None if covered is None else Price(
                Decimal("0"), covered.currency, covered.unit, "hourly", "ahb",
                "Windows Server licence covered by Azure Hybrid Benefit", covered.sources)
        parts.append(("windows_licence", prices))
    return parts


def per_machine(parts: list[tuple[str, Prices]], model: str, hours: Decimal) -> Decimal | None:
    total = Decimal("0")
    for _, prices in parts:
        price = prices.get(model)
        if price is None:
            return None
        total += monthly_of(price, hours, 1)
    return total


def _describe(component: str, size: VmSize, os: str, ahb: bool) -> tuple[str, str]:
    if component == "windows_licence":
        return ("Virtual Machines (Windows Server licence)",
                f"Windows Server licence for {size.short_name}: the Windows meter minus the Linux meter, per hour")
    if os == "linux":
        return ("Virtual Machines",
                f"{size.short_name} Linux virtual machine ({size.vcpu} vCPU, {size.memory_gib:g} GiB)")
    if ahb:
        return ("Virtual Machines", f"{size.short_name} Windows Server with Azure Hybrid Benefit, priced at the Linux "
                                    f"meter ({size.vcpu} vCPU, {size.memory_gib:g} GiB)")
    return ("Virtual Machines", f"{size.short_name} Windows Server compute, priced at the Linux meter; the licence is "
                                f"the next line ({size.vcpu} vCPU, {size.memory_gib:g} GiB)")


def assumptions_for(estimate: Estimate, catalog: VmCatalog, workloads: list[WorkloadSpec], ahb: bool) -> list[str]:
    hours = sorted({spec.hours_per_month for spec in workloads})
    windows = any(spec.os == "windows" for spec in workloads)
    lines = [
        f"{LIST_PRICE_NOTICE} Fetched on {estimate.fetched_at[:10] or 'an unknown date'}; each price's "
        "effectiveStartDate is on the Sources sheet.",
        f"Hours per month as given ({', '.join(f'{one:g}' for one in hours)}); 730 means always on.",
        "Reservations are paid for the whole term whatever the hours: the monthly figure is the term price divided "
        "by 12 or 36 months.",
        "Savings plans are priced at the hourly savings plan rate for the hours given; the hourly commitment must "
        "be sized to match.",
        "Managed disks are priced per disk per month by tier (the smallest tier that holds the size asked). Disk "
        "transactions of Standard SSD and Standard HDD, snapshots and bursting are billed separately and not "
        "included.",
        "Every machine has an OS disk: Premium SSD P10 (128 GiB) for Linux, P15 (256 GiB) for Windows, unless "
        "another is given.",
        "B-series (burstable) sizes are chosen only for workloads marked dev_test.",
        "Only the virtual machines, their disks and the services listed are priced: public IP addresses, bandwidth "
        "and support are not included.",
        "Software other than Windows Server (for example SQL Server) is not included.",
    ]
    if windows and ahb:
        lines.append("Azure Hybrid Benefit is applied to every Windows machine: each is priced at the Linux meter for "
                     "the same size and region. It requires eligible Windows Server licences with Software Assurance "
                     "or subscriptions.")
    elif windows:
        lines.append("Reservations and savings plans cover compute only: each Windows machine also pays the Windows "
                     "Server licence per hour (the Windows meter minus the Linux meter). The AHB column shows "
                     "pay-as-you-go with Azure Hybrid Benefit, the licence brought by the customer.")
    lines.append(f"VM specifications come from `{catalog.source or 'az vm list-skus'}` for {catalog.region}, read on "
                 f"{catalog.generated or 'an unknown date'}. Arm64 and constrained-core sizes are not chosen "
                 "automatically.")
    if estimate.currency != "USD":
        lines.append(f"Prices in {estimate.currency} are given by Microsoft for reference; the list price is in USD.")
    return lines


def size_workloads(store: PriceStore, catalog: VmCatalog, workloads: list[WorkloadSpec], *, region: str,
                   headline: str, ahb: bool, families: list[str], currency: str = "USD") -> Sizing:
    """Sizes, lines, assumptions and warnings for the workloads. Raises `NoSize` when a workload cannot be
    sized and `ValueError` for a disk larger than any tier."""
    store = CachedStore(store)
    windows = any(spec.os == "windows" for spec in workloads)
    models = list(COMMITMENTS) + (["ahb"] if windows and not ahb else [])
    estimate = Estimate(region=region, currency=currency, models=models, headline=headline)
    warnings: list[Warning] = []
    sized: list[SizedWorkload] = []
    for spec in workloads:
        hours = Decimal(repr(float(spec.hours_per_month)))
        parts_of: dict[str, list[tuple[str, Prices]]] = {}

        def monthly(size: VmSize, spec: WorkloadSpec = spec, hours: Decimal = hours,
                    parts_of: dict = parts_of) -> Decimal | None:
            parts_of[size.name] = machine_prices(store, size.name, region, spec.os, ahb, models, currency)
            return per_machine(parts_of[size.name], headline, hours)

        def gaps(size: VmSize, parts_of: dict = parts_of) -> list[str]:
            return [LABELS[model].lower() for model in models
                    if any(prices.get(model) is None for _, prices in parts_of[size.name])]

        # B-series (burstable) only for dev/test: a production workload's CPU is not a burst.
        allowed = families if spec.environment == "dev_test" else [one for one in families if one != "B"]
        if not allowed:
            raise NoSize(f"{spec.name}: B-series sizes are chosen only for workloads marked dev_test; allow other "
                         "families for a production workload.")
        choice = choose(catalog, vcpu=spec.vcpu, memory_gib=spec.memory_gb, families=allowed, monthly=monthly,
                        label=LABELS[headline], currency=currency, gaps=gaps)
        size = choice.chosen.size
        for component, prices in parts_of[size.name]:
            service, description = _describe(component, size, spec.os, ahb)
            estimate.lines.append(Line(spec.name, service, size.name, description, region, spec.count, hours, prices))
        if size.family == "B":
            warnings.append(Warning(code="burstable_size",
                                    message=f"{spec.name}: {size.short_name} is a burstable B-series size, suited to "
                                            "a low average CPU load (the workload is marked dev_test)."))
        disks = []
        for role, disk in (("os", spec.os_disk_or_default), *(("data", one) for one in spec.disks)):
            tier, tier_gib = tier_for(disk.type, disk.size_gb)
            price = _found(lambda disk=disk, tier=tier: disk_price(store, disk.type, tier, region, currency))
            if price is None:
                warnings.append(Warning(code="price_missing",
                                        message=f"{spec.name}: no {NAMES[disk.type]} {tier} LRS Disk meter in "
                                                f"{region}."))
            if disk.type == "premium_ssd" and not size.premium_disk:
                warnings.append(Warning(code="premium_disk_unsupported",
                                        message=f"{spec.name}: {size.short_name} does not support Premium SSD."))
            what = "OS disk" if role == "os" else f"data disk, {disk.count} per machine"
            estimate.lines.append(Line(spec.name, "Managed Disks", f"{tier} LRS",
                                       f"{NAMES[disk.type]} {tier} ({tier_gib} GiB) LRS managed disk, {what}", region,
                                       disk.count * spec.count, hours, dict.fromkeys(models, price)))
            disks.append({"role": role, "type": disk.type, "size_gb": disk.size_gb, "tier": tier,
                          "tier_gib": tier_gib, "count_per_machine": disk.count})
        sized.append(SizedWorkload(spec, choice, disks))
    fetched = [source.fetched_at for source in estimate.sources()]
    estimate.fetched_at = min(fetched) if fetched else ""
    estimate.assumptions = assumptions_for(estimate, catalog, workloads, ahb)
    for model in models:
        if estimate.missing(model):
            warnings.append(Warning(code="price_missing",
                                    message=f"{estimate.missing(model)} line(s) have no {LABELS[model].lower()} price "
                                            f"in {region}; that total leaves them out."))
    return Sizing(estimate, sized, warnings, catalog)
