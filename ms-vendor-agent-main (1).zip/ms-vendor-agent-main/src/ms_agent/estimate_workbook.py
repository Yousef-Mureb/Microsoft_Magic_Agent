"""The estimate as an Excel workbook a presales engineer can edit and send.

Sheets: Summary (totals per pricing model side by side, and the workloads), Lines (one row per billed
line, a unit price, unit, monthly and yearly figure per pricing model), Assumptions, Sources (every
meter read, with its URL, effectiveStartDate and fetch date) and Disclaimer.

Every monthly figure on Lines and every total on Summary is a formula, so changing a quantity or the
hours recalculates the workbook. openpyxl writes formulas without their values, and a reader that does
not calculate (MAGIC's document reader takes the cells' stored values) would see blanks; so each
formula's value, computed here exactly as the formula computes it, is stored next to it. Excel also
recalculates everything when the file opens.
"""

from __future__ import annotations

import io
import re
import zipfile
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from ms_agent.pricing.lookup import LABELS, LIST_PRICE_NOTICE
from ms_agent.sizing.estimate import SHORT_LABELS, Estimate, monthly_of
from ms_agent.sizing.workloads import SizedWorkload

SHEETS = ("Summary", "Lines", "Assumptions", "Sources", "Disclaimer")
MEDIA_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
FIXED = ("Workload", "Service", "SKU", "Description", "Region", "Quantity", "Hours per month")
PER_MODEL = ("unit price", "unit", "monthly", "yearly")
MONEY = "#,##0.00"
RATE = "0.0000000"
BOLD = Font(bold=True)
HEADER_FILL = PatternFill("solid", fgColor="DDEBF7")
NOT_PRICED = "n/a"


def disclaimer_of(estimate: Estimate) -> str:
    return f"List prices, not your agreement price; fetched on {estimate.fetched_at[:10] or 'an unknown date'}."


class _Cached:
    """The value of each formula cell, by sheet and coordinate."""

    def __init__(self) -> None:
        self.values: dict[str, dict[str, Decimal]] = {}

    def put(self, sheet: Worksheet, coordinate: str, formula: str, value: Decimal) -> None:
        sheet[coordinate] = formula
        self.values.setdefault(sheet.title, {})[coordinate] = value


def _header(sheet: Worksheet, row: int, titles: list[str]) -> None:
    for column, title in enumerate(titles, start=1):
        cell = sheet.cell(row=row, column=column, value=title)
        cell.font, cell.fill = BOLD, HEADER_FILL
        cell.alignment = Alignment(wrap_text=True, vertical="top")


def _model_columns(index: int) -> dict[str, str]:
    start = len(FIXED) + 1 + index * len(PER_MODEL)
    return {name: get_column_letter(start + offset) for offset, name in enumerate(PER_MODEL)}


def _lines_sheet(sheet: Worksheet, estimate: Estimate, cached: _Cached) -> int:
    titles = list(FIXED) + [f"{SHORT_LABELS[model]} {name}" for model in estimate.models for name in PER_MODEL]
    _header(sheet, 1, titles)
    for row, line in enumerate(estimate.lines, start=2):
        values = (line.workload, line.service, line.sku, line.description, line.region,
                  line.quantity if isinstance(line.quantity, int) else float(line.quantity),
                  float(line.hours))
        for column, value in enumerate(values, start=1):
            sheet.cell(row=row, column=column, value=value)
        for index, model in enumerate(estimate.models):
            columns = _model_columns(index)
            price = line.prices.get(model)
            if price is None:
                for name in PER_MODEL:
                    sheet[f"{columns[name]}{row}"] = NOT_PRICED if name != "unit" else ""
                continue
            unit_cell = f"{columns['unit price']}{row}"
            sheet[unit_cell] = float(price.value)
            sheet[unit_cell].number_format = RATE
            sheet[f"{columns['unit']}{row}"] = f"{price.unit} (whole term)" if price.basis == "term" else price.unit
            if price.basis == "hourly":
                formula = f"=ROUND({unit_cell}*G{row}*F{row},2)"
            elif price.basis == "monthly":
                formula = f"=ROUND({unit_cell}*F{row},2)"
            else:
                formula = f"=ROUND({unit_cell}/{price.term_months}*F{row},2)"
            monthly = monthly_of(price, line.hours, line.quantity)
            cached.put(sheet, f"{columns['monthly']}{row}", formula, monthly)
            cached.put(sheet, f"{columns['yearly']}{row}", f"={columns['monthly']}{row}*12", monthly * 12)
            sheet[f"{columns['monthly']}{row}"].number_format = MONEY
            sheet[f"{columns['yearly']}{row}"].number_format = MONEY
    widths = [18, 26, 18, 60, 12, 10, 10] + [14, 14, 14, 14] * len(estimate.models)
    for column, width in enumerate(widths, start=1):
        sheet.column_dimensions[get_column_letter(column)].width = width
    sheet.freeze_panes = "H2"
    return len(estimate.lines) + 1


def _summary_sheet(sheet: Worksheet, estimate: Estimate, workloads: list[SizedWorkload], last: int,
                   cached: _Cached) -> None:
    sheet["A1"] = f"Azure estimate, {estimate.region}, {estimate.currency}"
    sheet["A1"].font = Font(bold=True, size=14)
    sheet["A2"] = disclaimer_of(estimate)
    sheet["A2"].font = Font(italic=True)
    _header(sheet, 4, ["Pricing model"] + [SHORT_LABELS[model] for model in estimate.models])
    sheet["A5"], sheet["A6"], sheet["A7"], sheet["A8"] = "Monthly", "Yearly", "Lines without a price", "Meaning"
    for index, model in enumerate(estimate.models):
        column = get_column_letter(index + 2)
        lines = _model_columns(index)
        monthly = estimate.total(model)
        cached.put(sheet, f"{column}5", f"=SUM(Lines!{lines['monthly']}2:{lines['monthly']}{last})", monthly)
        cached.put(sheet, f"{column}6", f"=SUM(Lines!{lines['yearly']}2:{lines['yearly']}{last})", monthly * 12)
        sheet[f"{column}5"].number_format = sheet[f"{column}6"].number_format = MONEY
        sheet[f"{column}7"] = estimate.missing(model)
        sheet[f"{column}8"] = LABELS[model]
        sheet[f"{column}8"].alignment = Alignment(wrap_text=True, vertical="top")
        sheet.column_dimensions[column].width = 16
    sheet.column_dimensions["A"].width = 24
    headline = get_column_letter(estimate.models.index(estimate.headline) + 2)
    sheet["A10"], sheet["B10"] = "Leading pricing model", LABELS[estimate.headline]
    sheet["A11"], sheet["A12"] = "Monthly", "Yearly"
    cached.put(sheet, "B11", f"={headline}5", estimate.total(estimate.headline))
    cached.put(sheet, "B12", f"={headline}6", estimate.total(estimate.headline) * 12)
    sheet["B11"].number_format = sheet["B12"].number_format = MONEY
    for cell in ("A10", "A11", "A12"):
        sheet[cell].font = BOLD
    _header(sheet, 14, ["Workload", "Size", "vCPU", "Memory GiB", "OS", "Machines", "Hours per month", "Why"])
    for row, sized in enumerate(workloads, start=15):
        size = sized.choice.chosen.size
        values = (sized.spec.name, size.name, size.vcpu, size.memory_gib, sized.spec.os, sized.spec.count,
                  sized.spec.hours_per_month, sized.choice.chosen.reason)
        for column, value in enumerate(values, start=1):
            sheet.cell(row=row, column=column, value=value)
    if estimate.not_priced:
        row = 15 + len(workloads) + 1
        _header(sheet, row, ["Drawn, not priced"])
        for offset, text in enumerate(estimate.not_priced, start=1):
            sheet.cell(row=row + offset, column=1, value=text)


def _list_sheet(sheet: Worksheet, title: str, items: list[str]) -> None:
    _header(sheet, 1, ["#", title])
    for row, text in enumerate(items, start=2):
        sheet.cell(row=row, column=1, value=row - 1)
        sheet.cell(row=row, column=2, value=text).alignment = Alignment(wrap_text=True, vertical="top")
    sheet.column_dimensions["A"].width = 5
    sheet.column_dimensions["B"].width = 120


def _sources_sheet(sheet: Worksheet, estimate: Estimate) -> None:
    _header(sheet, 1, ["Meter", "Product", "Type", "Field read", "effectiveStartDate", "Fetched at", "Source URL"])
    for row, source in enumerate(estimate.sources(), start=2):
        values = (source.meter_name, source.product_name, source.type, source.field, source.effective_start_date,
                  source.fetched_at, source.url)
        for column, value in enumerate(values, start=1):
            sheet.cell(row=row, column=column, value=value)
        sheet.cell(row=row, column=7).hyperlink = source.url
    for column, width in zip("ABCDEFG", (22, 38, 14, 32, 22, 22, 80), strict=True):
        sheet.column_dimensions[column].width = width


def _with_cached_values(data: bytes, cached: _Cached) -> bytes:
    """The saved workbook with each formula's value written in its empty `<v/>` (openpyxl names the sheets'
    parts `sheet1.xml`, `sheet2.xml`, ... in the order of SHEETS)."""
    source = zipfile.ZipFile(io.BytesIO(data))
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as target:
        for info in source.infolist():
            content = source.read(info.filename)
            match = re.fullmatch(r"xl/worksheets/sheet(\d+)\.xml", info.filename)
            values = cached.values.get(SHEETS[int(match.group(1)) - 1], {}) if match else {}
            if values:
                text = content.decode("utf-8")
                for coordinate, value in values.items():
                    text = re.sub(rf'(<c r="{coordinate}"[^>]*><f>[^<]*</f>)<v\s*/>', rf"\g<1><v>{value}</v>", text,
                                  count=1)
                content = text.encode("utf-8")
            target.writestr(info, content)
    return out.getvalue()


def build_workbook(estimate: Estimate, workloads: list[SizedWorkload], *, made_by: str = "") -> bytes:
    """The .xlsx file of the estimate."""
    workbook = Workbook()
    summary = workbook.active
    summary.title = SHEETS[0]
    lines, assumptions, sources, disclaimer = (workbook.create_sheet(title) for title in SHEETS[1:])
    cached = _Cached()
    last = _lines_sheet(lines, estimate, cached)
    _summary_sheet(summary, estimate, workloads, last, cached)
    _list_sheet(assumptions, "Assumption", estimate.assumptions)
    _sources_sheet(sources, estimate)
    made = datetime.now(tz=UTC).date().isoformat()
    _list_sheet(disclaimer, "Disclaimer", [
        disclaimer_of(estimate),
        LIST_PRICE_NOTICE + " Taxes are not included. Microsoft changes prices; check them again before quoting.",
        f"Made by {made_by or 'the Microsoft vendor agent'} on {made}. Quantities and hours on the Lines sheet "
        "can be edited; the totals follow.",
    ])
    workbook.calculation.fullCalcOnLoad = True
    buffer = io.BytesIO()
    workbook.save(buffer)
    return _with_cached_values(buffer.getvalue(), cached)


def summary_rows(estimate: Estimate) -> list[dict[str, Any]]:
    """The Summary's totals as rows, for an answer that shows them without opening the file."""
    return [{"pricing_model": model, "label": LABELS[model], "monthly": float(estimate.total(model)),
             "yearly": float(estimate.total(model) * 12), "lines_without_price": estimate.missing(model)}
            for model in estimate.models]
