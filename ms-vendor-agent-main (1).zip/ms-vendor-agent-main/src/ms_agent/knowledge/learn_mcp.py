"""A small client for the Microsoft Learn MCP (Model Context Protocol) server.

The server at `https://learn.microsoft.com/api/mcp` speaks MCP `2025-06-18` over Streamable
HTTP: one `POST` per JSON-RPC message, answered either as JSON or as server-sent events; an
`initialize` call gives a session id that later calls carry in `Mcp-Session-Id`. Its tools are
`microsoft_docs_search` (up to ten passages: `title`, `content`, `contentUrl`),
`microsoft_docs_fetch` (one page as Markdown) and `microsoft_code_sample_search`.
Only the first two are used here. No key is needed.
"""

from __future__ import annotations

import json
import uuid
from typing import Any

import httpx

from ms_agent import __version__

PROTOCOL_VERSION = "2025-06-18"
SEARCH_TOOL = "microsoft_docs_search"
FETCH_TOOL = "microsoft_docs_fetch"


class LearnMcpError(Exception):
    """The Learn server did not answer as MCP says."""


def events_to_json(text: str) -> Any:
    """The JSON of a server-sent events body: the last `data:` payload that is a JSON-RPC message."""
    payloads: list[str] = []
    data: list[str] = []
    for line in text.replace("\r\n", "\n").split("\n"):
        if line.startswith("data:"):
            data.append(line[5:].lstrip())
        elif not line.strip() and data:
            payloads.append("\n".join(data))
            data = []
    if data:
        payloads.append("\n".join(data))
    for payload in reversed(payloads):
        try:
            message = json.loads(payload)
        except ValueError:
            continue
        if isinstance(message, dict) and ("result" in message or "error" in message):
            return message
    raise LearnMcpError("The Learn server's event stream held no JSON-RPC answer.")


class LearnMcpClient:
    def __init__(self, url: str, *, timeout: float = 30.0, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self._url = url
        self._client = httpx.AsyncClient(timeout=timeout, transport=transport, follow_redirects=False)
        self._session: str | None = None

    async def close(self) -> None:
        await self._client.aclose()

    async def _post(self, body: dict[str, Any]) -> httpx.Response:
        headers = {"content-type": "application/json", "accept": "application/json, text/event-stream",
                   "mcp-protocol-version": PROTOCOL_VERSION}
        if self._session:
            headers["mcp-session-id"] = self._session
        try:
            return await self._client.post(self._url, json=body, headers=headers)
        except httpx.HTTPError as failure:
            raise LearnMcpError(f"The Learn server could not be reached ({type(failure).__name__}).") from None

    async def _rpc(self, method: str, params: dict[str, Any] | None = None) -> Any:
        body = {"jsonrpc": "2.0", "id": uuid.uuid4().hex, "method": method, "params": params or {}}
        answer = await self._post(body)
        if answer.status_code == 404 and self._session:
            # The session expired: open a new one and ask once more.
            self._session = None
            await self._initialize()
            answer = await self._post(body)
        if answer.status_code >= 300:
            raise LearnMcpError(f"The Learn server answered HTTP {answer.status_code}.")
        content_type = answer.headers.get("content-type", "")
        try:
            message = events_to_json(answer.text) if content_type.startswith("text/event-stream") else answer.json()
        except ValueError:
            raise LearnMcpError("The Learn server answered something that is not JSON.") from None
        if not isinstance(message, dict):
            raise LearnMcpError("The Learn server answered something that is not JSON-RPC.")
        if isinstance(message.get("error"), dict):
            raise LearnMcpError(f"The Learn server answered an error: {message['error'].get('message')}")
        return message.get("result")

    async def _initialize(self) -> None:
        body = {"jsonrpc": "2.0", "id": uuid.uuid4().hex, "method": "initialize",
                "params": {"protocolVersion": PROTOCOL_VERSION, "capabilities": {},
                           "clientInfo": {"name": "ms-vendor-agent", "version": __version__}}}
        answer = await self._post(body)
        if answer.status_code >= 300:
            raise LearnMcpError(f"The Learn server refused to initialize (HTTP {answer.status_code}).")
        self._session = answer.headers.get("mcp-session-id") or None
        # The notification needs no answer; HTTP 202 is the usual reply.
        await self._post({"jsonrpc": "2.0", "method": "notifications/initialized"})

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        if self._session is None:
            await self._initialize()
        result = await self._rpc("tools/call", {"name": name, "arguments": arguments})
        if not isinstance(result, dict):
            raise LearnMcpError("The Learn server answered the tool call without a result.")
        if result.get("isError"):
            raise LearnMcpError("The Learn server reported an error for the tool call.")
        return result

    async def search(self, query: str) -> list[dict[str, Any]]:
        """The passages of `microsoft_docs_search`: dictionaries with `title`, `content`, `contentUrl`."""
        result = await self.call_tool(SEARCH_TOOL, {"query": query})
        structured = result.get("structuredContent")
        if isinstance(structured, dict) and isinstance(structured.get("results"), list):
            return [item for item in structured["results"] if isinstance(item, dict)]
        for part in result.get("content") or []:
            if isinstance(part, dict) and part.get("type") == "text":
                try:
                    parsed = json.loads(part.get("text") or "")
                except ValueError:
                    continue
                if isinstance(parsed, dict) and isinstance(parsed.get("results"), list):
                    return [item for item in parsed["results"] if isinstance(item, dict)]
        return []

    async def fetch(self, url: str) -> str:
        """One documentation page as Markdown, by `microsoft_docs_fetch`."""
        result = await self.call_tool(FETCH_TOOL, {"url": url})
        for part in result.get("content") or []:
            if isinstance(part, dict) and part.get("type") == "text" and isinstance(part.get("text"), str):
                return part["text"]
        return ""
