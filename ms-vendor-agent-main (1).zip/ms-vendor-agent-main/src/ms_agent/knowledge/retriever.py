"""The retriever interface: `retrieve(question) -> [passages]`.

Step 1 has one implementation, the Microsoft Learn MCP server. Step 2 adds Azure AI Search over
Mindware's own Microsoft knowledge; see the extension point at the end of this file.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Protocol
from urllib.parse import urlsplit, urlunsplit

from ms_agent.knowledge.learn_mcp import LearnMcpClient
from ms_agent.knowledge.sources import allowed_source

# A locale segment such as `en-us` at the start of a Learn path; the same page without it is the same page.
LOCALE = re.compile(r"[a-z]{2}-[a-z]{2}", re.IGNORECASE)


@dataclass(frozen=True)
class Passage:
    """One piece of documentation a citation can point at."""

    url: str
    title: str
    text: str


class Retriever(Protocol):
    async def retrieve(self, question: str, *, limit: int = 8) -> list[Passage]: ...


def canonical(url: str) -> str:
    """One spelling of a documentation address, so a citation matches the passage it came from:
    lower-case host, no fragment, no `en-us` locale segment, no trailing slash."""
    parts = urlsplit(url.strip())
    segments = [segment for segment in parts.path.split("/") if segment]
    if segments and LOCALE.fullmatch(segments[0]):
        segments = segments[1:]
    path = "/" + "/".join(segments)
    return urlunsplit((parts.scheme.lower() or "https", parts.netloc.lower(), path.rstrip("/"), parts.query, ""))


class LearnRetriever:
    """Passages from the live Microsoft Learn documentation search."""

    def __init__(self, client: LearnMcpClient) -> None:
        self._client = client

    async def retrieve(self, question: str, *, limit: int = 8) -> list[Passage]:
        found = await self._client.search(question)
        passages: list[Passage] = []
        seen: set[tuple[str, str]] = set()
        for item in found:
            url = item.get("contentUrl") or item.get("url") or ""
            text = (item.get("content") or "").strip()
            if not url or not text or not allowed_source(url):
                continue  # forum answers and other pages that may not be evidence never reach the model
            key = (canonical(url), text[:200])
            if key in seen:
                continue
            seen.add(key)
            passages.append(Passage(url=url, title=(item.get("title") or url).strip(), text=text))
            if len(passages) >= limit:
                break
        return passages


# Extension point, step 2: an `AzureSearchRetriever` with the same `retrieve` signature over
# Mindware's indexed Microsoft knowledge, and a `CompositeRetriever` that asks both and merges
# by canonical URL. `advice_explain` sees only the `Retriever` protocol and does not change.
