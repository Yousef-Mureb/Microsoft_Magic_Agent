"""Where the answers come from: Microsoft documentation, retrieved per question."""
