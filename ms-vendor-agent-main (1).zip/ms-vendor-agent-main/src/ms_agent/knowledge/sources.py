"""Which pages may be evidence in an answer.

Allowed: Microsoft Learn documentation (`learn.microsoft.com`, but not the Microsoft Q&A forum under
`/answers/`, where anyone can post), Azure pricing and product pages (`azure.microsoft.com`), and Microsoft's
product, licensing and Product Terms pages (`www.microsoft.com`), and Microsoft's own announcements
(`news.microsoft.com`, e.g. a new region). Everything else is dropped before the model sees it, and again if the
model cites it anyway: forums and community sites. Product pages on `www.microsoft.com` and the news site go
beyond the brief's list; they are first-party Microsoft pages the golden questions expect (PROGRESS.md, 3a.5).
"""

from __future__ import annotations

import re
from urllib.parse import urlsplit

URL = re.compile(r"https?://[^\s)\]>\"']+", re.IGNORECASE)


def allowed_source(url: str) -> bool:
    parts = urlsplit(url.strip())
    host = parts.netloc.lower().split(":")[0]
    path = parts.path.lower()
    if host == "learn.microsoft.com":
        return "/answers/" not in path + "/" and not path.rstrip("/").endswith("/answers")
    if host == "azure.microsoft.com":
        return True
    return host in ("www.microsoft.com", "microsoft.com", "news.microsoft.com")


def forum(url: str) -> bool:
    """A Microsoft Q&A forum page."""
    parts = urlsplit(url.strip())
    return parts.netloc.lower() == "learn.microsoft.com" and "/answers" in parts.path.lower()


def urls_in(text: str) -> list[str]:
    return URL.findall(text)
