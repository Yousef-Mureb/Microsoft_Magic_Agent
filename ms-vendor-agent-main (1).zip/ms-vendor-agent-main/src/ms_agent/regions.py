"""Azure region facts: availability zones, restricted access, the paired region.

Read from Microsoft Learn through its MCP server (`microsoft_docs_fetch`) by `scripts/refresh_regions.py`
and kept as data in `data/azure_regions.json`, with the source URLs and the time they were read:

- https://learn.microsoft.com/azure/reliability/regions-list (zones, pair, location, access)
- https://learn.microsoft.com/azure/reliability/regions-paired (the pairs, cross-checked)

The parsers read the pages' first table (the "All" tab). A region marked with the restricted-access icon
needs an access request before a subscription can use it; a zone count marked "coming soon" is kept with
that note.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from functools import cache
from pathlib import Path
from typing import Any

REGIONS_LIST_URL = "https://learn.microsoft.com/azure/reliability/regions-list"
REGION_PAIRS_URL = "https://learn.microsoft.com/azure/reliability/regions-paired"
ACCESS_REQUEST_URL = "https://learn.microsoft.com/troubleshoot/azure/general/region-access-request-process"
RESTRICTED_ICON = "icon-region-restricted"
COMING_SOON_ICON = "icon-region-coming-soon"
ICON = re.compile(r"!\[[^\]]*\]\([^)]*\)")


class RegionDataError(ValueError):
    """A page did not have the table the parser expects."""


def _cell(text: str) -> tuple[str, bool, bool]:
    """A table cell without its icons, and whether it carried the restricted or the coming-soon icon."""
    return (ICON.sub("", text).strip(), RESTRICTED_ICON in text, COMING_SOON_ICON in text)


def _first_table(markdown: str, header: str) -> list[list[str]]:
    # Learn answers with \r\n; a copy saved on Windows may have \r\r\n. Blank lines are not table rows.
    lines = [line for line in re.split(r"[\r\n]+", markdown) if line.strip()]
    start = next((index for index, line in enumerate(lines) if line.strip().startswith(header)), None)
    if start is None:
        raise RegionDataError(f"No table with the header {header!r}.")
    rows = []
    for line in lines[start + 2:]:  # the header and the |---| line
        if not line.strip().startswith("|"):
            break
        rows.append(line.strip().strip("|").split("|"))
    return rows


def parse_regions_list(markdown: str) -> dict[str, dict[str, Any]]:
    """Every region of the regions list, by programmatic name."""
    regions = {}
    for row in _first_table(markdown, "| Region | Availability zones | Paired region |"):
        if len(row) < 6:
            continue
        name, restricted, soon = _cell(row[0])
        zones_text, _, zones_soon = _cell(row[1])
        pair, pair_restricted, _ = _cell(row[2])
        programmatic = _cell(row[5])[0]
        regions[programmatic] = {
            "display_name": name,
            "availability_zones": int(zones_text) if zones_text.isdigit() else 0,
            "zones_note": "marked coming soon on the page" if zones_soon else "",
            "restricted_access": restricted,
            "coming_soon": soon,
            "paired_region_name": "" if pair in ("", "N/A") else pair,
            "paired_region_restricted": pair_restricted,
            "physical_location": _cell(row[3])[0],
            "geography": _cell(row[4])[0],
        }
    if not regions:
        raise RegionDataError("The regions list table is empty.")
    return regions


def parse_region_pairs(markdown: str) -> dict[str, str]:
    """Region display name -> paired region display name, from the region pairs page."""
    pairs = {}
    for row in _first_table(markdown, "| Region | Paired region |"):
        if len(row) >= 2:
            pairs[_cell(row[0])[0]] = _cell(row[1])[0]
    if not pairs:
        raise RegionDataError("The region pairs table is empty.")
    return pairs


def region_data(regions_list: str, region_pairs: str, wanted: list[str], *, read_at: str) -> dict[str, Any]:
    """The stored document for the wanted regions. The pair must be the same on both pages."""
    listed = parse_regions_list(regions_list)
    pairs = parse_region_pairs(region_pairs)
    by_display = {facts["display_name"]: name for name, facts in listed.items()}
    chosen = {}
    for name in wanted:
        if name not in listed:
            raise RegionDataError(f"{name} is not in the regions list.")
        facts = dict(listed[name])
        paired = pairs.get(facts["display_name"], "")
        if paired != facts["paired_region_name"]:
            raise RegionDataError(f"{name}: the regions list pairs it with {facts['paired_region_name']!r}, the "
                                  f"region pairs page with {paired!r}.")
        facts["paired_region"] = by_display.get(paired, "")
        chosen[name] = facts
    return {"sources": [{"url": REGIONS_LIST_URL, "read_at": read_at},
                        {"url": REGION_PAIRS_URL, "read_at": read_at}],
            "read_via": "Microsoft Learn MCP server, microsoft_docs_fetch",
            "regions": chosen}


@dataclass(frozen=True)
class Region:
    name: str
    display_name: str
    availability_zones: int
    zones_note: str
    restricted_access: bool
    paired_region: str
    paired_region_restricted: bool
    physical_location: str
    geography: str

    def zones_text(self) -> str:
        if self.availability_zones == 0:
            return "no availability zones"
        numbers = [str(one) for one in range(1, self.availability_zones + 1)]
        listed = ", ".join(numbers[:-1]) + " and " + numbers[-1] if len(numbers) > 1 else numbers[0]
        return f"across availability zones {listed}" + (f" ({self.zones_note})" if self.zones_note else "")


@dataclass(frozen=True)
class RegionFacts:
    regions: dict[str, Region]
    sources: tuple[dict[str, str], ...]

    def get(self, name: str) -> Region | None:
        return self.regions.get(name)


@cache
def load_regions(directory: Path) -> RegionFacts:
    given = json.loads((directory / "azure_regions.json").read_text(encoding="utf-8"))
    regions = {name: Region(name=name, display_name=facts["display_name"],
                            availability_zones=int(facts["availability_zones"]), zones_note=facts.get("zones_note", ""),
                            restricted_access=bool(facts["restricted_access"]), paired_region=facts["paired_region"],
                            paired_region_restricted=bool(facts["paired_region_restricted"]),
                            physical_location=facts.get("physical_location", ""), geography=facts.get("geography", ""))
               for name, facts in given["regions"].items()}
    return RegionFacts(regions=regions, sources=tuple(given["sources"]))
