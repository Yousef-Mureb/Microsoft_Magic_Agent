"""A design drawn and stored: the SVG and the PNG in the file store, their links, a caption and a legend."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ms_agent.contract import Warning
from ms_agent.diagram.model import FigureDesign
from ms_agent.diagram.png import render_png
from ms_agent.diagram.svg import render
from ms_agent.skills.base import Services

SVG_TYPE, PNG_TYPE = "image/svg+xml", "image/png"
AVAILABILITY = {"single_zone": "in one zone", "zone_redundant": "across availability zones",
                "with_dr": "across availability zones, with a disaster recovery region"}


@dataclass
class Figure:
    svg: str
    png: bytes | None
    caption: str
    legend: list[dict[str, str]]
    files: list[dict[str, Any]] = field(default_factory=list)
    warnings: list[Warning] = field(default_factory=list)

    def result(self) -> dict[str, Any]:
        return {"caption": self.caption, "legend": self.legend,
                "diagram": {"svg": next((one["url"] for one in self.files if one["media_type"] == SVG_TYPE), None),
                            "png": next((one["url"] for one in self.files if one["media_type"] == PNG_TYPE), None)}}


def caption_of(design: FigureDesign) -> str:
    where = design.region_name or design.region
    dr = f"; disaster recovery to {design.dr_region_name or design.dr_region}" if design.dr_region else ""
    machines = sum(one.count for one in design.components if one.kind == "vm" and one.placement != "dr")
    return (f"Azure architecture in {where}, {AVAILABILITY[design.availability]}{dr}: {machines} virtual machines "
            f"and {len({one.kind for one in design.components if one.kind != 'vm'})} other services, drawn with "
            "Microsoft's Azure architecture icons.")


def legend_of(design: FigureDesign) -> list[dict[str, str]]:
    seen: dict[tuple[str, str], dict[str, str]] = {}
    for one in design.components:
        seen.setdefault((one.kind, one.name), {"icon": one.kind, "service": one.name, "detail": one.detail,
                                               "where": one.placement})
    return list(seen.values())


def make_figure(services: Services, design: FigureDesign, *, title: str) -> Figure:
    """Draw the design; store the SVG and the PNG when there is a file store. A PNG that cannot be rendered is a
    warning; the SVG is the diagram."""
    svg = render(design)
    figure = Figure(svg=svg, png=None, caption=caption_of(design), legend=legend_of(design))
    try:
        figure.png = render_png(svg)
    except Exception as failure:  # the SVG stands without its PNG copy
        figure.warnings.append(Warning(code="png_not_rendered",
                                       message=f"The PNG copy could not be rendered ({type(failure).__name__})."))
    if services.files is None:
        figure.warnings.append(Warning(code="diagram_not_stored",
                                       message="No file store is configured; the diagram is not linked."))
        return figure
    stored = services.files.put(f"{title}.svg", SVG_TYPE, svg.encode("utf-8"))
    figure.files.append(services.file_link(stored))
    if figure.png is not None:
        figure.files.append(services.file_link(services.files.put(f"{title}.png", PNG_TYPE, figure.png)))
    return figure
