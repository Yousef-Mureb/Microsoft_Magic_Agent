# Source of the icons

The SVG files in this folder are Microsoft's, unmodified, with their original file names. Only the
icons the diagrams use are kept. `originals.json` holds each file's path in Microsoft's zip and
its SHA-256 as read from the zip; `tests/test_icons.py` checks every file against it.
`scripts/fetch_icons.py` downloads them again.

## Azure Architecture Icons — `azure/`

- Page: https://learn.microsoft.com/azure/architecture/icons/ (last updated 2026-10-09)
- Version: **V24** (the page's latest update: July 2026)
- Download: https://arch-center.azureedge.net/icons/Azure_Public_Service_Icons_V24.zip
  (1,033,184 bytes, `Last-Modified: Wed, 08 Jul 2026 22:21:41 GMT`,
  SHA-256 `921594ccd1bf3d9c0a1bd7b6d924e050551a59342f2b353bb74bdcf761c35141`)
- Downloaded: 2026-10-27 (UAE time; `originals.json` records the UTC time)
- The zip also holds `Azure_Icons_FAQ.pdf` and `Microsoft_Terms_of_Use.pdf` (not kept here).

## Microsoft Entra architecture icons — `entra/`

- Page: https://learn.microsoft.com/entra/architecture/architecture-icons
- Version: October 2023
- Download: https://download.microsoft.com/download/3/1/a/31a56038-856a-4489-88e4-ee5a1c4352be/Microsoft%20Entra%20architecture%20icons%20-%20Oct%202023.zip
  (SHA-256 `4e07536706a2d092e6524e5417e2c861333fdbdb41c36f78d44dfa07ccc5eedc`)
- Kept: `Microsoft Entra ID color icon.svg` (the Azure set has no plain Microsoft Entra ID icon).
- The zip also holds a branding playbook and `Microsoft Terms of Use.docx` (not kept here).

## Microsoft 365

The Microsoft 365 page (https://learn.microsoft.com/microsoft-365/solutions/architecture-icons-templates)
publishes Visio and PowerPoint templates only, no SVG set; none is used.

## Terms, as the pages state them

"Microsoft permits the use of these icons in architectural diagrams, training materials, or
documentation. You can copy, distribute, and display the icons only for the permitted use unless
granted explicit permission by Microsoft. Microsoft reserves all other rights." (Azure page; the
Entra page says the same.)

General guidelines on the Azure page:

- Do: use the icon to illustrate how products can work together; include the product name
  somewhere close to the icon; use the icons as they would appear within Azure.
- Don't: crop, flip, or rotate icons; distort or change icon shape in any way; use Microsoft
  product icons to represent your product or service.

The diagrams follow them: each icon is drawn whole, at its own aspect ratio, unrotated and in its
own colours, with the service name next to it. When an icon is inlined into a diagram, only the
`id`s inside it are renamed (prefixed per use, so two copies do not share a gradient); the drawing
is unchanged.
