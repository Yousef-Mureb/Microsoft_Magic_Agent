"""The `design` object a diagram is drawn from.

`design_propose` returns it (as `result.design`), and `design_figure` takes it back. It holds what
the drawing needs and nothing else: no prices, so no field name MAGIC refuses to send (MAGIC refuses
any field whose name contains "price", among other words, at any depth).
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from ms_agent.diagram.icons import ICONS

Placement = Literal["outside", "front", "app", "data", "management", "shared", "dr"]
Availability = Literal["single_zone", "zone_redundant", "with_dr"]


class Component(BaseModel):
    """One thing drawn: an official icon, the service's name, and what it is (size, count, zones)."""

    model_config = ConfigDict(extra="forbid")

    kind: str = Field(min_length=1, max_length=40, description=f"Icon: one of {', '.join(sorted(ICONS))}")
    name: str = Field(min_length=1, max_length=80, description="Service name, e.g. 'Application Gateway WAF v2'")
    detail: str = Field(default="", max_length=120, description="e.g. '2 × D4as_v6, zones 1–2'")
    placement: Placement = Field(description="outside (users, customer network), front (entry subnet), app, "
                                             "data, management (Bastion), shared (side band), dr (DR region)")
    zones: list[int] = Field(default_factory=list, max_length=4, description="Availability zones used, e.g. [1, 2]")
    size: str = Field(default="", max_length=60, description="For machines: the size, e.g. 'D4as_v6'")
    count: int = Field(default=0, ge=0, le=1000, description="For machines: how many, spread over the zones")
    web: bool = Field(default=False, description="Reached from outside through a front door")
    entry: str = Field(default="", max_length=40, description="The front door's kind it is reached through, e.g. "
                                                              "'app_gateway', 'load_balancer'; empty: any")


class FigureDesign(BaseModel):
    model_config = ConfigDict(extra="forbid")

    region: str = Field(pattern=r"^[a-z0-9]+$", max_length=40)
    region_name: str = Field(default="", max_length=60, description="e.g. 'UAE North'")
    availability: Availability = "single_zone"
    zones: int = Field(default=0, ge=0, le=4, description="Availability zones drawn as columns; 0 = none")
    dr_region: str | None = Field(default=None, pattern=r"^[a-z0-9]+$", max_length=40)
    dr_region_name: str = Field(default="", max_length=60)
    components: list[Component] = Field(min_length=1, max_length=60)


def zones_label(zones: list[int]) -> str:
    """`[1, 2]` -> "zones 1–2"; `[1, 2, 3]` -> "zones 1–3"; `[2]` -> "zone 2"; `[1, 3]` -> "zones 1, 3"."""
    if not zones:
        return ""
    if len(zones) == 1:
        return f"zone {zones[0]}"
    ordered = sorted(zones)
    if ordered == list(range(ordered[0], ordered[-1] + 1)):
        return f"zones {ordered[0]}–{ordered[-1]}"
    return "zones " + ", ".join(str(one) for one in ordered)
