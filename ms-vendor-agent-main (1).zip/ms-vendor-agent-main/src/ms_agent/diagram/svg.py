"""Draw a design as an SVG architecture diagram, deterministically, with Microsoft's icons.

The layout follows Microsoft's reference architectures:

    users / customer network      +-- Azure subscription · UAE North (uaenorth) -----------------+
            |                     |  +-- Virtual network ----------------------+  Shared services |
            +-------------------> |  |  Front-end subnet:  Application Gateway |  Key Vault        |
                                  |  |  Application subnet: zone 1 | zone 2 |..|  Log Analytics    |
                                  |  |  Data subnet:        zone 1 | zone 2 |..|  Defender, Backup |
                                  |  |  AzureBastionSubnet: Bastion            |  Entra ID         |
                                  |  +-----------------------------------------+                   |
                                  +-------------------------------------------------------------+
                                  +-- DR region · UAE Central (uaecentral) ----------------------+

Each node is the official icon, the service name and its detail. The icons are inlined whole, at
their own aspect ratio, unrotated and in their own colours; only the `id`s inside each copy are
prefixed, so two copies do not share a gradient. Nothing is fetched or run: no external reference,
no script, no style element.
"""

from __future__ import annotations

import re
import textwrap
import xml.etree.ElementTree as ElementTree
from dataclasses import dataclass, field
from xml.sax.saxutils import escape

from ms_agent.diagram.icons import icon_svg
from ms_agent.diagram.model import Component, FigureDesign, zones_label

SVG_NS = "http://www.w3.org/2000/svg"
XLINK_NS = "http://www.w3.org/1999/xlink"
ElementTree.register_namespace("", SVG_NS)
ElementTree.register_namespace("xlink", XLINK_NS)

FONT = "Segoe UI, DejaVu Sans, Arial, sans-serif"
ICON = 40
NODE_WIDTH = 160
NAME_CHARS, DETAIL_CHARS = 22, 26
LINE = 14
GAP = 18
MARGIN = 20
OUTSIDE_WIDTH = 190
SHARED_WIDTH = 200
ROW_LABEL = 26
COLOURS = {"region": "#0078D4", "vnet": "#2E7D32", "subnet": "#5C6BC0", "zone": "#8A8886", "dr": "#A4262C",
           "shared": "#605E5C", "arrow": "#323130", "text": "#201F1E", "muted": "#605E5C"}
ROWS = (("front", "Front-end subnet"), ("app", "Application subnet"), ("data", "Data subnet"),
        ("management", "AzureBastionSubnet"))


@dataclass
class Node:
    component: Component
    x: float
    y: float
    detail: str
    key: str = ""

    @property
    def height(self) -> float:
        return node_height(self.component, self.detail)

    @property
    def centre(self) -> float:
        return self.x + NODE_WIDTH / 2


@dataclass
class Canvas:
    parts: list[str] = field(default_factory=list)
    icon_uses: int = 0

    def add(self, text: str) -> None:
        self.parts.append(text)


def _lines(text: str, width: int) -> list[str]:
    return textwrap.wrap(text, width=width, break_long_words=True) or ([] if not text else [text])


def node_height(component: Component, detail: str) -> float:
    return ICON + 6 + LINE * (len(_lines(component.name, NAME_CHARS)) + len(_lines(detail, DETAIL_CHARS))) + 6


def inline_icon(kind: str, x: float, y: float, size: float, prefix: str) -> str:
    """The icon's own SVG, placed at (x, y) with the given size; every `id` and every reference to one is
    prefixed. The drawing inside is not changed."""
    root = ElementTree.fromstring(re.sub(r"^\s*<\?xml[^>]*\?>", "", icon_svg(kind)))
    for node in root.iter():
        if "id" in node.attrib:
            node.attrib["id"] = f"{prefix}-{node.attrib['id']}"
        for name, value in list(node.attrib.items()):
            if "url(#" in value:
                node.attrib[name] = value.replace("url(#", f"url(#{prefix}-")
            elif name in ("href", f"{{{XLINK_NS}}}href") and value.startswith("#"):
                node.attrib[name] = f"#{prefix}-{value[1:]}"
    if "viewBox" not in root.attrib and {"width", "height"} <= root.attrib.keys():
        root.attrib["viewBox"] = f"0 0 {root.attrib['width']} {root.attrib['height']}"
    root.attrib.update({"x": f"{x:g}", "y": f"{y:g}", "width": f"{size:g}", "height": f"{size:g}"})
    return ElementTree.tostring(root, encoding="unicode")


def _text(canvas: Canvas, x: float, y: float, text: str, *, size: int = 12, weight: str = "normal",
          anchor: str = "middle", colour: str = COLOURS["text"]) -> None:
    canvas.add(f'<text x="{x:g}" y="{y:g}" font-family="{FONT}" font-size="{size}" font-weight="{weight}" '
               f'text-anchor="{anchor}" fill="{colour}">{escape(text)}</text>')


def _box(canvas: Canvas, x: float, y: float, width: float, height: float, colour: str, *, dashed: bool = False,
         fill: str = "none", radius: int = 6) -> None:
    dash = ' stroke-dasharray="6 4"' if dashed else ""
    canvas.add(f'<rect x="{x:g}" y="{y:g}" width="{width:g}" height="{height:g}" rx="{radius}" fill="{fill}" '
               f'stroke="{colour}" stroke-width="1.5"{dash}/>')


def _draw_node(canvas: Canvas, node: Node) -> None:
    canvas.icon_uses += 1
    left = node.centre - ICON / 2
    canvas.add(inline_icon(node.component.kind, left, node.y, ICON, f"i{canvas.icon_uses}"))
    y = node.y + ICON + 6 + 11
    for line in _lines(node.component.name, NAME_CHARS):
        _text(canvas, node.centre, y, line, weight="600")
        y += LINE
    for line in _lines(node.detail, DETAIL_CHARS):
        _text(canvas, node.centre, y, line, size=11, colour=COLOURS["muted"])
        y += LINE


def _arrow(canvas: Canvas, x1: float, y1: float, x2: float, y2: float, *, dashed: bool = False,
           label: str = "") -> None:
    dash = ' stroke-dasharray="5 4"' if dashed else ""
    canvas.add(f'<path d="M{x1:g},{y1:g} L{x2:g},{y2:g}" fill="none" stroke="{COLOURS["arrow"]}" stroke-width="1.4"'
               f'{dash} marker-end="url(#arrow)"/>')
    if label:
        _text(canvas, (x1 + x2) / 2 + 6, (y1 + y2) / 2 - 4, label, size=10, anchor="start", colour=COLOURS["muted"])


def _per_zone(component: Component, zones: list[int]) -> dict[int, int]:
    """How many machines of a component go in each zone: spread in turn, as the design places them."""
    counts = dict.fromkeys(zones, 0)
    for index in range(component.count or len(zones)):
        counts[zones[index % len(zones)]] += 1
    return counts


def _detail(component: Component) -> str:
    if component.detail:
        return component.detail
    if component.size:
        return f"{component.count} × {component.size}" + (f", {zones_label(component.zones)}"
                                                          if component.zones else "")
    return ""


def render(design: FigureDesign) -> str:
    """The diagram as SVG text."""
    canvas = Canvas()
    by_place: dict[str, list[Component]] = {}
    for component in design.components:
        by_place.setdefault(component.placement, []).append(component)
    zones = list(range(1, design.zones + 1)) if design.zones else []

    region_x = MARGIN + OUTSIDE_WIDTH + 40
    vnet_x = region_x + 20
    rows = [(place, label) for place, label in ROWS if by_place.get(place)]
    zoned = {"app", "data"} if zones else set()
    widest = max([len(by_place.get(place, [])) for place, _ in rows if place not in zoned] + [1])
    column_width = NODE_WIDTH + GAP
    zone_columns = max(len(zones), 1)
    vnet_inner = max(widest * column_width, zone_columns * column_width + 20) + GAP
    vnet_width = vnet_inner + 20
    shared_x = vnet_x + vnet_width + 20
    region_width = vnet_width + 40 + (SHARED_WIDTH + 20 if by_place.get("shared") else 0)

    nodes: list[Node] = []
    y = MARGIN + 60  # region title, then the VNet title
    vnet_y = y
    y += 34
    row_boxes: list[tuple[str, float, float]] = []
    zone_band: tuple[float, float] | None = None
    for place, label in rows:
        top = y
        y += ROW_LABEL
        components = by_place[place]
        if place in zoned:
            y += 14  # room for the zone column's label
            heights = dict.fromkeys(zones, 0.0)
            for component in components:
                spread = component.zones or zones[:1]
                for zone, count in _per_zone(component, spread).items():
                    if not count:
                        continue
                    detail = f"{count} × {component.size}" if component.size else _detail(component)
                    x = vnet_x + 20 + (zone - 1) * column_width + GAP / 2
                    node = Node(component, x, y + heights[zone], detail, key=f"{component.name}#{zone}")
                    nodes.append(node)
                    heights[zone] += node.height + 10
            y += max(heights.values()) + 4
            zone_band = (zone_band[0], y) if zone_band else (top + ROW_LABEL - 4, y)
        else:
            start = vnet_x + 20 + (vnet_inner - len(components) * column_width) / 2 + GAP / 2
            tallest = 0.0
            for index, component in enumerate(components):
                node = Node(component, start + index * column_width, y, _detail(component), key=component.name)
                nodes.append(node)
                tallest = max(tallest, node.height)
            y += tallest + 8
        row_boxes.append((label, top, y - top))
        y += 12
    vnet_height = y - vnet_y + 6

    shared = by_place.get("shared", [])
    shared_nodes = []
    shared_y = vnet_y + 34
    for component in shared:
        node = Node(component, shared_x + (SHARED_WIDTH - NODE_WIDTH) / 2, shared_y, _detail(component),
                    key=component.name)
        shared_nodes.append(node)
        shared_y += node.height + 12
    region_bottom = max(vnet_y + vnet_height, shared_y) + 20
    region_y = MARGIN
    region_height = region_bottom - region_y

    dr = by_place.get("dr", [])
    dr_y = region_bottom + 50
    dr_nodes = []
    dr_height = 0.0
    if dr:
        start = region_x + 20
        tallest = 0.0
        for index, component in enumerate(dr):
            node = Node(component, start + index * column_width, dr_y + 44, _detail(component), key=component.name)
            dr_nodes.append(node)
            tallest = max(tallest, node.height)
        dr_height = 44 + tallest + 16

    outside = by_place.get("outside", [])
    outside_nodes = []
    outside_y = vnet_y + 40
    for component in outside:
        node = Node(component, MARGIN + (OUTSIDE_WIDTH - NODE_WIDTH) / 2, outside_y, _detail(component),
                    key=component.name)
        outside_nodes.append(node)
        outside_y += node.height + 30

    width = region_x + max(region_width, len(dr) * column_width + 40) + MARGIN
    height = (dr_y + dr_height if dr else region_bottom) + MARGIN

    canvas.add(f'<svg xmlns="{SVG_NS}" width="{width:g}" height="{height:g}" viewBox="0 0 {width:g} {height:g}">')
    canvas.add('<defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" '
               f'orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{COLOURS["arrow"]}"/></marker></defs>')
    canvas.add(f'<rect x="0" y="0" width="{width:g}" height="{height:g}" fill="#FFFFFF"/>')

    region_label = f"Azure subscription · {design.region_name or design.region} ({design.region})"
    _box(canvas, region_x, region_y, region_width, region_height, COLOURS["region"], fill="#F3F9FD")
    canvas.icon_uses += 1
    canvas.add(inline_icon("subscription", region_x + 10, region_y + 8, 22, f"i{canvas.icon_uses}"))
    _text(canvas, region_x + 38, region_y + 24, region_label, size=14, weight="600", anchor="start",
          colour=COLOURS["region"])

    _box(canvas, vnet_x, vnet_y, vnet_width, vnet_height, COLOURS["vnet"], fill="#FFFFFF")
    canvas.icon_uses += 1
    canvas.add(inline_icon("vnet", vnet_x + 10, vnet_y + 6, 22, f"i{canvas.icon_uses}"))
    _text(canvas, vnet_x + 38, vnet_y + 22, "Virtual network", size=13, weight="600", anchor="start",
          colour=COLOURS["vnet"])
    for label, top, height in row_boxes:
        _box(canvas, vnet_x + 10, top, vnet_width - 20, height, COLOURS["subnet"], dashed=True, radius=4)
        canvas.icon_uses += 1
        canvas.add(inline_icon("subnet", vnet_x + 16, top + 4, 16, f"i{canvas.icon_uses}"))
        _text(canvas, vnet_x + 38, top + 17, label, size=11, weight="600", anchor="start", colour=COLOURS["subnet"])
    if zone_band and zones:
        for zone in zones:
            x = vnet_x + 20 + (zone - 1) * column_width + 2
            _box(canvas, x, zone_band[0], column_width - 4, zone_band[1] - zone_band[0], COLOURS["zone"],
                 dashed=True, radius=4)
            _text(canvas, x + 6, zone_band[0] + 12, f"Availability zone {zone}", size=10, anchor="start",
                  colour=COLOURS["zone"])

    if shared:
        _box(canvas, shared_x, vnet_y, SHARED_WIDTH, shared_y - vnet_y + 6, COLOURS["shared"], dashed=True)
        _text(canvas, shared_x + SHARED_WIDTH / 2, vnet_y + 22, "Shared services", size=13, weight="600",
              colour=COLOURS["shared"])
    if dr:
        dr_label = f"Disaster recovery region · {design.dr_region_name or design.dr_region} ({design.dr_region})"
        _box(canvas, region_x, dr_y, max(region_width, len(dr) * column_width + 40), dr_height, COLOURS["dr"],
             dashed=True, fill="#FDF6F6")
        _text(canvas, region_x + 14, dr_y + 24, dr_label, size=14, weight="600", anchor="start", colour=COLOURS["dr"])
        _arrow(canvas, region_x + region_width / 2, region_bottom, region_x + region_width / 2, dr_y, dashed=True,
               label="replication")

    for node in nodes + shared_nodes + dr_nodes + outside_nodes:
        _draw_node(canvas, node)

    fronts = [node for node in nodes if node.component.placement == "front"]
    web_targets = [node for node in nodes if node.component.placement in ("app", "data") and node.component.web]
    for source in outside_nodes:
        is_customer_network = source.component.kind == "on_premises"
        gateways = [node for node in fronts if node.component.kind in ("vpn_gateway", "expressroute")]
        targets = gateways if is_customer_network and gateways else \
            [node for node in fronts if node not in gateways] or web_targets
        for target in targets:
            _arrow(canvas, source.centre + ICON / 2 + 6, source.y + ICON / 2, target.centre - ICON / 2 - 4,
                   target.y + ICON / 2)
    for front in fronts:
        if front.component.kind in ("vpn_gateway", "expressroute"):
            for target in [node for node in nodes if node.component.placement == "app"]:
                _arrow(canvas, front.centre, front.y + front.height, target.centre, target.y, dashed=True)
            continue
        for target in web_targets:
            if target.component.entry in ("", front.component.kind):
                _arrow(canvas, front.centre, front.y + front.height, target.centre, target.y)
    canvas.add("</svg>")
    return "".join(canvas.parts)
