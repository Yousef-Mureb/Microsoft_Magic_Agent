"""The diagram as PNG, for documents: rendered from the SVG by resvg (the `resvg-py` package).

resvg-py installs from wheels on Windows and Linux (x86_64 and arm64), with no system library; it
needs a font for the text: Segoe UI on Windows, DejaVu Sans in the container (the Dockerfile installs
`fonts-dejavu-core`, as the slim image has no font).
"""

from __future__ import annotations

import resvg_py

ZOOM = 2.0  # twice the SVG's size, sharp enough for a document page


def render_png(svg: str, *, zoom: float = ZOOM) -> bytes:
    return bytes(resvg_py.svg_to_bytes(svg_string=svg, zoom=zoom, background="#ffffff"))
