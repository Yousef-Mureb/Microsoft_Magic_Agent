"""Architecture diagrams drawn by code from a design, with Microsoft's official icons."""
