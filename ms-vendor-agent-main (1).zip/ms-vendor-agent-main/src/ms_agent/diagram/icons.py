"""Our names for the services a diagram draws, mapped to Microsoft's official icons.

The SVG files are Microsoft's, unmodified: the Azure Architecture Icons (V24) in `icons/azure/` and
the Microsoft Entra architecture icons (October 2023) in `icons/entra/`, with their original file
names. `icons/SOURCE.md` says where and when they were downloaded and on what terms;
`icons/originals.json` holds each file's SHA-256 as read from Microsoft's zip, and the tests check
the files against it. `scripts/fetch_icons.py` downloads them again.
"""

from __future__ import annotations

from functools import cache
from pathlib import Path

ICON_DIR = Path(__file__).resolve().parent / "icons"

# Our name -> the icon file, relative to ICON_DIR.
ICONS: dict[str, str] = {
    "vm": "azure/10021-icon-service-Virtual-Machine.svg",
    "vmss": "azure/10034-icon-service-VM-Scale-Sets.svg",
    "disk": "azure/10032-icon-service-Disks.svg",
    "vnet": "azure/10061-icon-service-Virtual-Networks.svg",
    "subnet": "azure/02742-icon-service-Subnet.svg",
    "nsg": "azure/10067-icon-service-Network-Security-Groups.svg",
    "app_gateway": "azure/10076-icon-service-Application-Gateways.svg",
    "waf": "azure/10362-icon-service-Web-Application-Firewall-Policies(WAF).svg",
    "load_balancer": "azure/10062-icon-service-Load-Balancers.svg",
    "front_door": "azure/10073-icon-service-Front-Door-and-CDN-Profiles.svg",
    "api_management": "azure/10042-icon-service-API-Management-Services.svg",
    "container_apps": "azure/02989-icon-service-Container-Apps-Environments.svg",
    "app_service": "azure/10035-icon-service-App-Services.svg",
    "aks": "azure/10023-icon-service-Kubernetes-Services.svg",
    "sql_db": "azure/10130-icon-service-SQL-Database.svg",
    "sql_mi": "azure/10136-icon-service-SQL-Managed-Instance.svg",
    "postgres": "azure/10131-icon-service-Azure-Database-PostgreSQL-Server.svg",
    "storage": "azure/10086-icon-service-Storage-Accounts.svg",
    "key_vault": "azure/10245-icon-service-Key-Vaults.svg",
    "log_analytics": "azure/00009-icon-service-Log-Analytics-Workspaces.svg",
    "monitor": "azure/00001-icon-service-Monitor.svg",
    "defender": "azure/10241-icon-service-Microsoft-Defender-for-Cloud.svg",
    "bastion": "azure/02422-icon-service-Bastions.svg",
    "backup_vault": "azure/02361-icon-service-Backup-Vault.svg",
    "recovery_vault": "azure/00017-icon-service-Recovery-Services-Vaults.svg",
    # Azure Site Recovery has no icon of its own; it lives in a Recovery Services vault.
    "site_recovery": "azure/00017-icon-service-Recovery-Services-Vaults.svg",
    "vpn_gateway": "azure/10063-icon-service-Virtual-Network-Gateways.svg",
    "expressroute": "azure/10079-icon-service-ExpressRoute-Circuits.svg",
    "firewall": "azure/10084-icon-service-Firewalls.svg",
    "entra_id": "entra/Microsoft Entra ID color icon.svg",
    "openai": "azure/03438-icon-service-Azure-OpenAI.svg",
    "foundry": "azure/035746832-icon-service-AI-Foundry.svg",
    "ai_search": "azure/10044-icon-service-Cognitive-Search.svg",
    "iot_hub": "azure/10182-icon-service-IoT-Hub.svg",
    "digital_twins": "azure/01030-icon-service-Digital-Twins.svg",
    "users": "azure/10230-icon-service-Users.svg",
    # The customer's side of a VPN or ExpressRoute connection.
    "on_premises": "azure/10077-icon-service-Local-Network-Gateways.svg",
    "subscription": "azure/10002-icon-service-Subscriptions.svg",
}


def icon_path(name: str) -> Path:
    return ICON_DIR / ICONS[name]


@cache
def icon_svg(name: str) -> str:
    """The icon's SVG text, as Microsoft published it."""
    return icon_path(name).read_bytes().decode("utf-8-sig")
